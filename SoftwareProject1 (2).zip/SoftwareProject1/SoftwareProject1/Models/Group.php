<?php
include_once 'config.php';
class Group implements JsonSerializable {
    private $groupID;
    private $groupName;
    private $students = [];
    private $messages = [];

    public function load($row) {
        $this->setGroupID($row['group_id'] ?? null);
        $this->setGroupName($row['group_name'] ?? null);
        $this->setStudents($row['students'] ?? []);
        $this->setMessages($row['messages'] ?? []);
    }

    public function setGroupID($groupID) { $this->groupID = $groupID; }
    public function getGroupID() { return $this->groupID; }

    public function setGroupName($groupName) { $this->groupName = $groupName; }
    public function getGroupName() { return $this->groupName; }

    public function setStudents($students) {
        $this->students = is_array($students) ? $students : [$students];
    }
    public function getStudents() { return $this->students; }

    public function setMessages($messages) {
        $this->messages = is_array($messages) ? $messages : [$messages];
    }
    public function getMessages() { return $this->messages; }

    public function addStudent($student) { $this->students[] = $student; }
    public function studentDelete($index) {
        if (isset($this->students[$index])) {
            unset($this->students[$index]);
            $this->students = array_values($this->students);
            return true;
        }
        return false;
    }

    public function addMessage($message) { $this->messages[] = $message; }

    public function jsonSerialize(): mixed {
        return [
            'group_id' => $this->groupID,
            'group_name' => $this->groupName,
            'students' => $this->students,
            'messages' => $this->messages
        ];
    }

    public function createGroup($groupName, $creatorID, $friendIDs = []) {
        $conn = $this->connectDB();

        $stmt = $conn->prepare("INSERT INTO GROUPTABLE (group_name) VALUES (?)");
        if (!$stmt) { 
            error_log("GROUPTABLE prepare failed: " . $conn->error);
            return false; 
        }
        $stmt->bind_param("s", $groupName);
        if (!$stmt->execute()) { 
            error_log("GROUPTABLE execute failed: " . $stmt->error);
            return false; 
        }
        $groupID = $stmt->insert_id;
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO GROUP_ASSIGNMENT (group_id, user_id, join_date) VALUES (?, ?, NOW())");
        if (!$stmt) { 
            error_log("GROUP_ASSIGNMENT prepare failed: " . $conn->error);
            return false; 
        }
        $stmt->bind_param("ii", $groupID, $creatorID);
        if (!$stmt->execute()) { 
            error_log("GROUP_ASSIGNMENT execute failed: " . $stmt->error);
            return false; 
        }
        $stmt->close();

        if (!empty($friendIDs) && is_array($friendIDs)) {
            $stmt = $conn->prepare("INSERT INTO GROUP_ASSIGNMENT (group_id, user_id, join_date) VALUES (?, ?, NOW())");
            if (!$stmt) { 
                error_log("GROUP_ASSIGNMENT friends prepare failed: " . $conn->error);
                return false; 
            }
            foreach ($friendIDs as $fid) {
                $stmt->bind_param("ii", $groupID, $fid);
                if (!$stmt->execute()) {
                    error_log("GROUP_ASSIGNMENT friends execute failed for user $fid: " . $stmt->error);
                }
            }
            $stmt->close();
        }

        $conn->close();
        return $groupID;
    }

    public function getAllGroups() {
        $conn = $this->connectDB();
        $groups = [];

        $sql = "SELECT group_id, group_name FROM GROUPTABLE";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $t = new Group();
                $t->setGroupID($row['group_id']);
                $t->setGroupName($row['group_name']);
                $groups[] = $t;
            }
        }

        $conn->close();
        return $groups;
    }

        public function getAllGroupsByUser($userID) {
        $conn = $this->connectDB();
        $groups = [];

        $sql = "SELECT g.group_id, g.group_name 
                FROM GROUPTABLE g
                JOIN GROUP_ASSIGNMENT ga ON g.group_id = ga.group_id
                WHERE ga.user_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) return $groups;

        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $group = new Group();
            $group->setGroupID($row['group_id']);
            $group->setGroupName($row['group_name']);

            $stmtMembers = $conn->prepare("SELECT u.user_ID, u.username 
                                        FROM GROUP_ASSIGNMENT ga 
                                        JOIN USER u ON ga.user_id = u.user_ID
                                        WHERE ga.group_id = ?");
            $stmtMembers->bind_param("i", $row['group_id']);
            $stmtMembers->execute();
            $resMembers = $stmtMembers->get_result();
            $members = [];
            while ($m = $resMembers->fetch_assoc()) {
                $members[] = $m;
            }
            $group->setStudents($members);
            $groups[] = $group;
            $stmtMembers->close();
        }

        $stmt->close();
        $conn->close();
        return $groups;
    }

    public function getGroup($groupID) {
    $conn = $this->connectDB();
    $group = null;

    $stmt = $conn->prepare("SELECT group_id, group_name FROM GROUPTABLE WHERE group_id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $groupID);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $group = new Group();
            $group->setGroupID($row['group_id']);
            $group->setGroupName($row['group_name']);

            $stmt2 = $conn->prepare("
                SELECT u.user_ID, u.username
                FROM GROUP_ASSIGNMENT ga
                JOIN USER u ON ga.user_id = u.user_ID
                WHERE ga.group_id = ?
            ");
            if ($stmt2) {
                $stmt2->bind_param("i", $groupID);
                $stmt2->execute();
                $res2 = $stmt2->get_result();
                $students = [];
                while ($r = $res2->fetch_assoc()) {
                    $students[] = ['user_id' => $r['user_ID'], 'username' => $r['username']];
                }
                $group->setStudents($students);
                $stmt2->close();
            }
        }
        $stmt->close();
    }

    $conn->close();
    return $group;
}

    public function getUserGroups($userID) {
    $conn = $this->connectDB();
    $groups = [];

    $stmt = $conn->prepare("
        SELECT g.group_id, g.group_name
        FROM GROUPTABLE g
        JOIN GROUP_ASSIGNMENT ga ON g.group_id = ga.group_id
        WHERE ga.user_id = ?
    ");
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $g = new Group();
        $g->setGroupID($row['group_id']);
        $g->setGroupName($row['group_name']);
        $groups[] = $g;
    }

    $stmt->close();
    $conn->close();

    return $groups;
}

public function getGroupMembers($groupID) {
    $conn = $this->connectDB();
    $members = [];

    $stmt = $conn->prepare("
        SELECT u.user_ID, u.username
        FROM USER u
        JOIN GROUP_ASSIGNMENT ga ON u.user_ID = ga.user_id
        WHERE ga.group_id = ?
    ");
    $stmt->bind_param("i", $groupID);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $members[] = [
            'user_ID' => $row['user_ID'],
            'username' => $row['username']
        ];
    }

    $stmt->close();
    $conn->close();

    return $members;
}

    private function connectDB() {
        $host = DB_HOST;
        $user = DB_USER;
        $pass = DB_PASS;
        $dbname = DB_NAME;

        $conn = new mysqli($host, $user, $pass, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }
}
?>