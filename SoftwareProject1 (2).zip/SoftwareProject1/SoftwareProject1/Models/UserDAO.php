<?php
include_once 'User.php';
include_once __DIR__ . '/../config.php';

class UserDAO {

    private function getConnection() {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            return null;
        }
        return $mysqli;
    }

    /* -------------------------
     *       GET ALL USERS
     * -------------------------- */
    public function getAllUsers() {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("SELECT * FROM USER");
        $stmt->execute();
        $result = $stmt->get_result();

        $users = [];
        while ($row = $result->fetch_assoc()) {
            $user = new User();
            $user->load($row);
            $users[] = $user;
        }

        $stmt->close();
        $connection->close();
        return $users;
    }

    /* -------------------------
     *       GET ONE USER
     * -------------------------- */
    public function getUser($id) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("SELECT * FROM USER WHERE user_ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = null;

        if ($row = $result->fetch_assoc()) {
            $user = new User();
            $user->load($row);
        }

        $stmt->close();
        $connection->close();
        return $user;
    }

    /* -------------------------
     *       ADD NEW USER
     * -------------------------- */
    public function addUser($user) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("
        INSERT INTO USER (username, email, password, accessLvl, userDesc, uafs_id)
        VALUES (?, ?, ?, ?, ?, ?)
        ");

        $username = $user->getUsername();
        $email    = $user->getEmail();
        $password = $user->getPassword();
        $access   = $user->getAccessLevel();
        $desc     = $user->getDescription();
        $uafsID   = $user->getUafsID();

        $stmt->bind_param("ssssss", $username, $email, $password, $access, $desc, $uafsID);
        $stmt->execute();

        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *       DELETE USER
     * -------------------------- */
    public function deleteUser($user) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("DELETE FROM USER WHERE user_ID = ?");
        $stmt->bind_param("i", $user->getUserID());
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *   CHANGE ACCESS LEVEL
     * -------------------------- */
    public function changeAccessLevel($id) {
        $user = $this->getUser($id);
        $newLevel = ($user->getAccessLevel() === "user") ? "moderator" : "user";

        $connection = $this->getConnection();
        $stmt = $connection->prepare("UPDATE USER SET accessLvl = ? WHERE user_ID = ?");
        $stmt->bind_param("si", $newLevel, $id);
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *       BAN / UNBAN USERS
     * -------------------------- */
    public function banUser($id) {
        $file = fopen("./blacklist.txt", "a");
        fwrite($file, $id . "\n");
        fclose($file);
    }

    public function unbanUser($id) {
        $lines = file("./blacklist.txt");
        $newLines = [];

        foreach ($lines as $line) {
            if (trim($line) != $id) {
                $newLines[] = $line;
            }
        }

        file_put_contents("./blacklist.txt", implode("", $newLines));
    }

    public function checkBlacklist($id) {
        $lines = file("./blacklist.txt");
        foreach ($lines as $index => $line) {
            if (trim($line) == $id) {
                return $index;
            }
        }
        return -1;
    }

    /* -------------------------
     *       GET USER BY USERNAME
     * -------------------------- */
    public function getUserByUsername($username) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("SELECT * FROM USER WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $stmt->close();
        $connection->close();
        return $row;
    }

    /* -------------------------
     *       UPDATE BIO
     * -------------------------- */
    public function updateDescription($userID, $description) {
        $connection = $this->getConnection();
        $description = substr($description, 0, 1000); // enforce max length

        $stmt = $connection->prepare("UPDATE USER SET userDesc = ? WHERE user_ID = ?");
        $stmt->bind_param("si", $description, $userID);
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *    UPDATE PROFILE PIC
     * -------------------------- */
    public function updateProfilePicture($userID, $path) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("UPDATE USER SET profile_pic = ? WHERE user_ID = ?");
        $stmt->bind_param("si", $path, $userID);
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *       UPDATE BIRTHDAY
     * -------------------------- */
    public function updateBirthday($userID, $birthday) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("UPDATE USER SET birthday = ? WHERE user_ID = ?");
        $stmt->bind_param("si", $birthday, $userID);
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }

    /* -------------------------
     *   GET ALL USER BIRTHDAYS
     * -------------------------- */
    public function getAllUserBirthdays() {
        $connection = $this->getConnection();
        if ($connection === null) return [];

        $stmt = $connection->prepare("
        SELECT user_ID, username, birthday
        FROM USER
        WHERE birthday IS NOT NULL AND birthday != ''
        ");

        $stmt->execute();
        $result = $stmt->get_result();

        $birthdays = [];
        while ($row = $result->fetch_assoc()) {
            $birthdays[] = [
                "user_ID"  => $row["user_ID"],
                "username" => $row["username"],
                "birthday" => $row["birthday"]
            ];
        }

        $stmt->close();
        $connection->close();

        return $birthdays;
    }

    /* -------------------------
     *       GET ALL MODERATORS
     * -------------------------- */
    public function getAllModerators() {
        $connection = $this->getConnection();
        if ($connection === null) return [];

        $stmt = $connection->prepare("
        SELECT user_ID
        FROM USER
        WHERE LOWER(accessLvl) = 'moderator'
        ");
        $stmt->execute();

        $result = $stmt->get_result();
        $mods = [];

        while ($row = $result->fetch_assoc()) {
            $mods[] = $row; // returns ["user_ID" => X]
        }

        $stmt->close();
        $connection->close();

        return $mods;
    }

}
?>
