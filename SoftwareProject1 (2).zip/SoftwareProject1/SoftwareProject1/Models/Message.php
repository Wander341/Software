<?php
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
class Message implements jsonSerializable{
    public int $message_id;
    public ?int $user_id;
    public ?string $time_sent;
    public ?string $message_text;
    public ?int $thread_id;
    public mixed $group_id;

    public function __construct(array $row) {
        $this->message_id = (int) $row['message_id'];
        $this->user_id = isset($row['user_id']) ? (int) $row['user_id'] : null;
        $this->time_sent = $row['time_sent'] ?? null;
        $this->message_text = $row['message_text'] ?? null;
        $this->thread_id = isset($row['thread_id']) ? (int) $row['thread_id'] : null;
        $this->group_id = $row['group_id'] ?? null;
    }

    public function load($row){
        $this->setMessageID($row["message_id"]??null);
        $this->setTimeSent($row["time_sent"]??null);
        $this->setUserID($row["user_id"]??null);
        $this->setMessageText($row["message_text"]??null);
    }

    public function getMessageID(): int {
        return $this->messageID;
    }

    public function setMessageID(int $messageID): void {
        $this->messageID = $messageID;
    }

    public function getTimeSent(): DateTime {
        return $this->timeSent;
    }

    public function setTimeSent(DateTime $timeSent): void {
        $this->timeSent = $timeSent;
    }

    public function getUserID(): int {
        return $this->userID;
    }

    public function setUsername(int $user_name): void {
        $this->user_name = $user_name;
    }

    public function getMessageText(): string {
        return $this->messageText;
    }

    public function setMessageText(string $messageText): void {
        $this->messageText = $messageText;
    }

    public function getIsPinned(): bool {
        return $this->isPinned;
    }

    public function setIsPinned(bool $isPinned): void {
        $this->isPinned = $isPinned;
    }
    public function jsonSerialize(): array {
        return [
            'messageID'   => $this->messageID,
            'timeSent'    => $this->timeSent->format(DateTime::ATOM),
            'userID'      => $this->userID,
            'messageText' => $this->messageText,
            'isPinned'    => $this->isPinned
        ];
    }

}
?>