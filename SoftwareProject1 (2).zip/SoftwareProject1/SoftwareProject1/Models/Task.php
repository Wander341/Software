<?php
class Task implements JsonSerializable {
    private $taskID;
    private $taskName;
    private $taskDescription;
    private $dueDate;
    private $dateAssigned;

    private $status;
    public function load($row) {
        $this->setTaskID($row['task_id']);
        $this->setTaskName($row['task_name']);
        $this->setTaskDescription($row['task_desc']);
        $this->setDueDate($row['due_date']);
        $this->setDateAssigned($row['date_assigned'] ?? null);
        $this->setStatus($row['status']);
    }

    public function setTaskID($taskID) {
        $this->taskID = $taskID;
    }

    public function setTaskName($taskName) {
        $this->taskName = $taskName;
    }

    public function setTaskDescription($taskDescription) {
        $this->taskDescription = $taskDescription;
    }

    public function setDueDate($dueDate) {
        $this->dueDate = $dueDate;
    }

    public function setDateAssigned($dateAssigned) {
        $this->dateAssigned = $dateAssigned;
    }
    public function setStatus($status) {
        $this->status = $status;
    }

    public function getTaskID() {
        return $this->taskID;
    }

    public function getTaskName() {
        return $this->taskName;
    }

    public function getTaskDescription() {
        return $this->taskDescription;
    }

    public function getDueDate() {
        return $this->dueDate;
    }

    public function getDateAssigned() {
        return $this->dateAssigned;
    }
    public function getStatus() {
        return $this->status;
    }

    public function jsonSerialize(): mixed {
        return array(
            'task_id' => $this->taskID,
            'task_name' => $this->taskName,
            'task_description' => $this->taskDescription,
            'due_date' => $this->dueDate,
            'date_assigned' => $this->dateAssigned,
            'status' => $this->status
        );
    }
}
?>