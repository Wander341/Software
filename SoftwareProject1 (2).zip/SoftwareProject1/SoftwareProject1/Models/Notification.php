<?php
class Notification implements JsonSerializable {
    
    private $notifID;
    private $notifName;
    private $notifType;
    private $timeSent;

    public function load($row) {
        $this->setNotifID($row['notif_id']);
        $this->setNotifName($row['notif_name']);
        $this->setNotifType($row['notif_type']);
        $this->setTimeSent($row['time_sent']);
    }

    public function setNotifID($notifID) {
        $this->notifID = $notifID;
    }

    public function setNotifName($notifName) {
        $this->notifName = $notifName;
    }

    public function setNotifType($notifType) {
        $this->notifType = $notifType;
    }

    public function setTimeSent($timeSent) {
        $this->timeSent = $timeSent;
    }

    public function getNotifID() {
        return $this->notifID;
    }

    public function getNotifName() {
        return $this->notifName;
    }

    public function getNotifType() {
        return $this->notifType;
    }

    public function getTimeSent() {
        return $this->timeSent;
    }

    public function jsonSerialize(): mixed {
        return array(
            'notif_id' => $this->notifID,
            'notif_name' => $this->notifName,
            'notif_type' => $this->notifType,
            'time_sent' => $this->timeSent
        );
    }
}
?>