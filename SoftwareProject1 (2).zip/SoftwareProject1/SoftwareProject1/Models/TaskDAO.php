<?php
include_once 'Task.php';
include_once 'User.php';
include_once 'UserDAO.php';
include_once 'config.php';

class TaskDAO {

    public function getConnection(){
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            $mysqli = null;
        }
        return $mysqli;
    }

    public function addTask($taskName, $taskDescription, $dueDate, $userIDs = [], $groupName, $dateAssigned) {
        $connection = $this->getConnection();
        if (!$connection) return null;

        $status = "In Progress";

        $stmt1 = $connection->prepare("
            INSERT INTO TASK (task_name, task_desc, due_date, date_assigned, group_name, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt1->bind_param("ssssss", $taskName, $taskDescription, $dueDate, $dateAssigned, $groupName, $status);
        $stmt1->execute();

        $taskID = $stmt1->insert_id;
        $stmt1->close();

        // Assign users
        foreach ($userIDs as $userID) {
            $stmt2 = $connection->prepare("INSERT INTO TASK_ASSIGNMENT (task_id, user_id) VALUES (?, ?)");
            $stmt2->bind_param("ii", $taskID, $userID);
            $stmt2->execute();
            $stmt2->close();
        }

        //sends notification to all assigned users
        $stmtNotif = $connection->prepare("
            INSERT INTO NOTIFICATION (notif_name, notif_type, time_sent)
            VALUES (?, 'task', NOW())
        ");
        $stmtNotif->bind_param("s", $taskName);
        $stmtNotif->execute();
        $notifID = $stmtNotif->insert_id;
        $stmtNotif->close();

        $stmtAssign = $connection->prepare("
            INSERT INTO NOTIF_ASSIGNMENT (notif_id, user_id)
            VALUES (?, ?)
        ");

        foreach ($userIDs as $uid) {
            $stmtAssign->bind_param("ii", $notifID, $uid);
            $stmtAssign->execute();
        }

        $stmtAssign->close();
        $connection->close();

        return $taskID;
    }

    public function getAllTasks($userIDs = []) {
        if (empty($userIDs)) {
            return [];
        }
        $connection = $this->getConnection();
        $placeholders = implode(',', array_fill(0, count($userIDs), '?'));
        $types = str_repeat('i', count($userIDs));

        $query = "
            SELECT DISTINCT t.task_id, t.task_name, t.task_desc, 
                            DATE_FORMAT(t.due_date, '%M %e, %Y %l:%i %p') AS due_date,
                            DATE_FORMAT(t.date_assigned, '%M %e, %Y %l:%i %p') AS date_assigned,
                            t.group_name, t.status
            FROM TASK t
            INNER JOIN TASK_ASSIGNMENT ta ON t.task_id = ta.task_id
            WHERE ta.user_id IN ($placeholders)
        ";

        $stmt = $connection->prepare($query);
        $stmt->bind_param($types, ...$userIDs);
        $stmt->execute();

        $result = $stmt->get_result();
        $tasks = [];

        while ($row = $result->fetch_assoc()) {
            $tasks[] = $row;
        }

        $stmt->close();
        return $tasks;
    }

    public function getTask($taskID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("
            SELECT t.*, 
                   DATE_FORMAT(t.due_date, '%M %e, %Y %l:%i %p') AS due_date,
                   DATE_FORMAT(t.date_assigned, '%M %e, %Y %l:%i %p') AS date_assigned
            FROM TASK t
            WHERE task_id = ?
        ");
        $stmt->bind_param("i", $taskID);
        $stmt->execute();
        $result = $stmt->get_result();
        $task = $result->fetch_assoc();
        $stmt->close();

        return $task;
    }

    public function deleteTask($taskID) {
        $connection = $this->getConnection();
        $stmt1 = $connection->prepare("DELETE FROM TASK_ASSIGNMENT WHERE task_id = ?");
        $stmt1->bind_param("i", $taskID);
        $stmt1->execute();
        $stmt1->close();

        $stmt2 = $connection->prepare("DELETE FROM TASK WHERE task_id = ?");
        $stmt2->bind_param("i", $taskID);
        $stmt2->execute();
        $stmt2->close();
    }

    public function addUserToTask($userID, $taskID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("INSERT INTO TASK_ASSIGNMENT (task_id, user_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $taskID, $userID);
        $stmt->execute();
        $stmt->close();
    }

    public function removeUserFromTask($userID, $taskID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("DELETE FROM TASK_ASSIGNMENT WHERE task_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $taskID, $userID);
        $stmt->execute();
        $stmt->close();
    }

    public function updateTask($taskID, $taskName, $taskDescription, $dueDate, $status) {
        $connection = $this->getConnection();

        $stmt1 = $connection->prepare("
            UPDATE TASK 
            SET task_name = ?, task_desc = ?, due_date = ?, status = ?
            WHERE task_id = ?
        ");
        $stmt1->bind_param("ssssi", $taskName, $taskDescription, $dueDate, $status, $taskID);
        $stmt1->execute();
        $stmt1->close();

        return $taskID;
    }
}
?>
