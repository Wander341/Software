<?php
include_once 'Friend.php';
include_once 'config.php';

class FriendDAO {
    public function getConnection() {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            $mysqli = null;
        }
        return $mysqli;
    }

    public function getFriendsList($userID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("
            SELECT DISTINCT 
                CASE 
                    WHEN user_id = ? THEN friend_id 
                    ELSE user_id 
                END AS friend_id
            FROM Friendships
            WHERE (user_id = ? OR friend_id = ?)
            AND status = 'active'
        ");
        if (!$stmt) {
            die("Prepare failed: " . $connection->error);
        }

        $stmt->bind_param("iii", $userID, $userID, $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        $friends = [];
        while ($row = $result->fetch_assoc()) {
            $friends[] = intval($row['friend_id']);
        }

        $stmt->close();
        $connection->close();

        return $friends;
    }

    public function getAllFriendships($userID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("SELECT * FROM Friendships WHERE user_id = ? OR friend_id = ?");
        if (!$stmt) {
            die("Prepare failed: " . $connection->error);
        }

        $stmt->bind_param("ii", $userID, $userID);
        $stmt->execute();
        $result = $stmt->get_result();

        $friends = [];
        while ($row = $result->fetch_assoc()) {
            $friend = new Friend();
            $friend->load($row);
            $friends[] = $friend;
        }

        $stmt->close();
        $connection->close();

        return $friends;
    }

    public function addFriend($userID, $friendID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("INSERT INTO Friendships (user_id, friend_id, status) VALUES (?, ?, 'pending')");
        if (!$stmt) {
            die("Prepare failed: " . $connection->error);
        }

        $stmt->bind_param("ii", $userID, $friendID);
        $stmt->execute();
        $stmt->close();

        //sends the friend reequest receiver a notification
        $stmtUser = $connection->prepare("SELECT username FROM USER WHERE user_id = ?");
        $stmtUser->bind_param("i", $userID);
        $stmtUser->execute();
        $result = $stmtUser->get_result();
        $row = $result->fetch_assoc();
        $senderName = $row["username"] ?? "Someone";
        $stmtUser->close();

        $notifName = "Friend Request from " . $senderName;

        $stmtNotif = $connection->prepare("
            INSERT INTO NOTIFICATION (notif_name, notif_type, time_sent)
            VALUES (?, 'friend', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s'))
        ");
        $stmtNotif->bind_param("s", $notifName);
        $stmtNotif->execute();

        $notifID = $stmtNotif->insert_id;
        $stmtNotif->close();

        $stmtAssign = $connection->prepare("
            INSERT INTO NOTIF_ASSIGNMENT (notif_id, user_id)
            VALUES (?, ?)
        ");
        $stmtAssign->bind_param("ii", $notifID, $friendID);
        $stmtAssign->execute();
        $stmtAssign->close();
        $connection->close();
    }

    public function acceptFriend($userID, $friendID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("UPDATE Friendships SET status = 'active' WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        if (!$stmt) {
            die("Prepare failed: " . $connection->error);
        }

        $stmt->bind_param("iiii", $userID, $friendID, $friendID, $userID);
        $stmt->execute();
        $stmt->close();
        $connection->close();
    }
}
?>