<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title data-translate="events.title">Existing Events</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.event-row { cursor:pointer; transition:0.15s; }
.event-row:hover { background:#eef6ff; }
.register-btn.active { background:#28a745 !important; color:white; }
.unregister-btn.active { background:#dc3545 !important; color:white; }
</style>

<?php include './Styles/Stylesheet.php'; ?>
</head>

<body>
<?php include 'Navbar.php'; ?>

<div class="container my-4">

<div class="d-flex justify-content-end mb-3">
<a href="start.php?action=EventCreationForm&node_id=0"
class="btn btn-primary rounded-pill px-4"
data-translate="events.addEvent">
+ Add Event
</a>
</div>

<form method="POST">

<div class="table-responsive">
<table class="table table-sm table-bordered">
<thead class="table-primary">
<tr>
<th data-translate="events.select">Select</th>
<th data-translate="events.event">Event</th>
<th data-translate="events.description">Description</th>
<th data-translate="events.location">Location</th>
<th data-translate="events.time">Time</th>
<th data-translate="events.creator">Creator</th>
<th data-translate="events.rsvp">RSVP</th>
</tr>
</thead>

<tbody class="small">
<?php foreach ($data['events'] as $event): ?>
<?php
$rsvp = json_decode($event["rsvp"], true);
$isRegistered = in_array($data['userID'], $rsvp);
?>
<tr class="event-row"
onclick="window.location='start.php?action=ExistingEvents&event_id=<?= $event['event_id'] ?>'">

<td onclick="event.stopPropagation();">
<input type="checkbox" name="selected_events[]" value="<?= $event['event_id'] ?>">
</td>

<td><?= htmlspecialchars($event['event_name']) ?></td>
<td><?= htmlspecialchars($event['event_desc']) ?></td>
<td><?= htmlspecialchars($event['full_location']) ?></td>

<td>
<?= date("m/d/Y g:iA", strtotime($event['start_time'])) ?> -
<?= date("g:iA", strtotime($event['end_time'])) ?>
</td>

<td><?= htmlspecialchars($event['creator_ID']) ?></td>

<td onclick="event.stopPropagation();">
<form method="POST">
<input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">

<button name="action_type"
value="toggle_rsvp"
class="btn <?= $isRegistered ? 'btn-danger unregister-btn active' : 'btn-success register-btn active' ?>"
data-translate="<?= $isRegistered ? 'events.unregister' : 'events.register' ?>">
<?= $isRegistered ? "Unregister" : "Register" ?>
</button>

</form>
</td>

</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div class="d-flex justify-content-center mt-3 gap-2">

<button type="submit" name="action_type" value="rsvp_selected"
class="btn btn-success rounded-pill px-4"
data-translate="events.viewRSVP">
View RSVP
</button>

<button type="submit" name="action_type" value="delete_selected"
class="btn btn-danger rounded-pill px-4"
onclick="return confirm('Delete selected events?')"
data-translate="events.deleteSelected">
Delete Selected
</button>

</div>

</form>

<?php include 'Scripts.php'; ?>

<script>
/* ============================================================
 * UNIVERSAL TRANSLATION ENGINE (Same used in MapView/Home)
 * ============================================================ */

const translations = {
    "events.title": {
        en: "Existing Events",
        es: "Eventos Existentes",
        fr: "Événements Existants"
    },
    "events.addEvent": {
        en: "+ Add Event",
        es: "+ Agregar Evento",
        fr: "+ Ajouter un Événement"
    },
    "events.select": { en:"Select", es:"Seleccionar", fr:"Sélectionner" },
    "events.event": { en:"Event", es:"Evento", fr:"Événement" },
    "events.description": { en:"Description", es:"Descripción", fr:"Description" },
    "events.location": { en:"Location", es:"Ubicación", fr:"Emplacement" },
    "events.time": { en:"Time", es:"Hora", fr:"Heure" },
    "events.creator": { en:"Creator", es:"Creador", fr:"Créateur" },
    "events.rsvp": { en:"RSVP", es:"RSVP", fr:"RSVP" },
    "events.register": { en:"Register", es:"Registrar", fr:"S'inscrire" },
    "events.unregister": { en:"Unregister", es:"Cancelar Registro", fr:"Se désinscrire" },
    "events.viewRSVP": { en:"View RSVP", es:"Ver RSVP", fr:"Voir RSVP" },
    "events.deleteSelected": {
        en:"Delete Selected",
        es:"Eliminar Seleccionados",
        fr:"Supprimer la sélection"
    }
};

let lang = localStorage.getItem("language") || "en";

function translatePage() {
    document.querySelectorAll("[data-translate]").forEach(el => {
        const key = el.getAttribute("data-translate");
        if (translations[key] && translations[key][lang]) {
            el.textContent = translations[key][lang];
        }
    });
}

translatePage();
</script>

</body>
</html>
