<?php
if (!isset($calendarItems)) {
    $calendarItems = [];
}

include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Models/EventDAO.php";
include_once "./Models/Event.php";
include_once "./config.php";

/*
 * |--------------------------------------------------------------------------
 * | LOAD USER BIRTHDAYS (privacy-safe)
 * |--------------------------------------------------------------------------
 */
$userDAO = new UserDAO();
$userBirthdays = $userDAO->getAllUserBirthdays();
$currentUserID = $_SESSION['user']['user_ID'];

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

foreach ($userBirthdays as $bd) {

    $userID = $bd["user_ID"];
    $birthday = $bd["birthday"];
    if (!$birthday || $birthday === "0000-00-00") continue;

    $isVisible = ($userID == $currentUserID);

    if (!$isVisible) {
        $stmt = $conn->prepare("
        SELECT * FROM Friendships
        WHERE
        ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))
        AND status = 'active'
        ");
        $stmt->bind_param("iiii", $currentUserID, $userID, $userID, $currentUserID);
        $stmt->execute();
        $isVisible = $stmt->get_result()->num_rows > 0;
        $stmt->close();
    }

    if (!$isVisible) continue;

    $monthDay = substr($birthday, 5);
    $calendarItems[] = [
        "id"    => "birthday_" . $userID,
        "title" => "🎂 " . $bd["username"] . "'s Birthday",
        "start" => date("Y") . "-" . $monthDay,
        "color" => "#ff9ecd",
        "display" => "list-item"
    ];
}

/*
 * |--------------------------------------------------------------------------
 * | HOLIDAY CALCULATION
 * |--------------------------------------------------------------------------
 */

function computeEasterDate($year) {
    $a = $year % 19;
    $b = intdiv($year, 100);
    $c = $year % 100;
    $d = intdiv($b, 4);
    $e = $b % 4;
    $f = intdiv($b + 8, 25);
    $g = intdiv($b - $f + 1, 3);
    $h = (19*$a + $b - $d - $g + 15) % 30;
    $i = intdiv($c, 4);
    $k = $c % 4;
    $l = (32 + 2*$e + 2*$i - $h - $k) % 7;
    $m = intdiv($a + 11*$h + 22*$l, 451);
    $month = intdiv($h + $l - 7*$m + 114, 31);
    $day = (($h + $l - 7*$m + 114) % 31) + 1;
    return sprintf("%04d-%02d-%02d", $year, $month, $day);
}

$yearStart = date("Y") - 2;
$yearEnd   = date("Y") + 2;

for ($year = $yearStart; $year <= $yearEnd; $year++) {

    $easter       = computeEasterDate($year);
    $memorialDay  = date("Y-m-d", strtotime("last Monday of May $year"));
    $thanksgiving = date("Y-m-d", strtotime("fourth Thursday of November $year"));
    $fathersDay   = date("Y-m-d", strtotime("third Sunday of June $year"));
    $mothersDay   = date("Y-m-d", strtotime("second Sunday of May $year"));

    $holidays = [
        ["id" => "ny$year", "title" => "🎉 New Year's Day",   "date" => "$year-01-01"],
        ["id" => "vd$year", "title" => "❤️ Valentine's Day",  "date" => "$year-02-14"],
        ["id" => "jt$year", "title" => "🎗 Juneteenth",        "date" => "$year-06-19"],
        ["id" => "id$year", "title" => "🎆 Independence Day", "date" => "$year-07-04"],
        ["id" => "cd$year", "title" => "🎄 Christmas",        "date" => "$year-12-25"],
        ["id" => "md$year", "title" => "🌸 Mother's Day",    "date" => $mothersDay],
        ["id" => "es$year", "title" => "🐣 Easter",          "date" => $easter],
        ["id" => "mm$year", "title" => "🇺🇸 Memorial Day",   "date" => $memorialDay],
        ["id" => "tg$year", "title" => "🦃 Thanksgiving",    "date" => $thanksgiving],
        ["id" => "fd$year", "title" => "👨‍👧 Father's Day",  "date" => $fathersDay],
    ];

    foreach ($holidays as $h) {
        $calendarItems[] = [
            "id"    => "holiday_" . $h["id"],
            "title" => $h["title"], // translated later in JS
            "start" => $h["date"],
            "color" => "#8c52ff",
            "display" => "list-item"
        ];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title data-translate="cal.title">My Calendar</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/bootstrap5@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.19/index.global.min.css" rel="stylesheet">

<?php include './Styles/Stylesheet.php'; ?>

<style>
#calendar {
max-width: 900px;
margin: 50px auto;
}
.fc-daygrid-event {
    margin-top: 18px !important;
}
</style>
</head>

<body>

<?php include 'Navbar.php'; ?>

<div id="calendar"></div>

<!-- ADD EVENT MODAL -->
<div class="modal fade" id="addEventModal" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">

<div class="modal-header">
<h5 class="modal-title" data-translate="cal.addEvent">Add Event</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<div class="mb-3">
<label data-translate="cal.date">Date</label>
<input type="text" id="eventDate" class="form-control" readonly>
</div>

<div class="mb-3">
<label data-translate="cal.eventName">Event Name</label>
<input type="text" id="eventName" class="form-control">
</div>

<div class="mb-3">
<label data-translate="cal.description">Description</label>
<textarea id="eventDesc" class="form-control"></textarea>
</div>

<div class="row">
<div class="col">
<label data-translate="cal.startTime">Start Time</label>
<input type="time" id="startTime" class="form-control">
</div>

<div class="col">
<label data-translate="cal.endTime">End Time</label>
<input type="time" id="endTime" class="form-control">
</div>
</div>

<div class="mb-3 mt-3">
<label data-translate="cal.location">Location</label>
<input type="text" id="location" class="form-control">
</div>

</div>

<div class="modal-footer">
<button class="btn btn-secondary" data-bs-dismiss="modal" data-translate="cal.cancel">Cancel</button>
<button class="btn btn-primary" id="saveEventBtn" data-translate="cal.save">Save Event</button>
</div>

</div>
</div>
</div>

<!-- Hidden form -->
<form id="calendarEventForm" method="POST" action="start.php?action=EventCreationForm" style="display:none;">
<input type="hidden" name="event_name">
<input type="hidden" name="event_desc">
<input type="hidden" name="event_date">
<input type="hidden" name="start_time">
<input type="hidden" name="end_time">
<input type="hidden" name="location">
<input type="hidden" name="node_id" value="0">
</form>

<?php include 'Scripts.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/bootstrap5@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@6.1.19/index.global.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    var calendarEl = document.getElementById("calendar");

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        themeSystem: "bootstrap5",

        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay"
        },

        selectable: true,

        eventClick: function(info) {
            const id = info.event.id;

            if (String(id).startsWith("holiday_")) {
                alert(translateHoliday(info.event.title));
                return;
            }

            if (String(id).startsWith("birthday_")) {
                alert(info.event.title);
                return;
            }

            window.location.href = "start.php?action=RSVPView&event_id=" + id;
        },

        dateClick: function(info) {
            document.getElementById("eventDate").value = info.dateStr;
            new bootstrap.Modal(document.getElementById('addEventModal')).show();
        },

        events: <?php echo json_encode($calendarItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>
    });

    calendar.render();

    document.getElementById("saveEventBtn").onclick = function () {
        let form = document.getElementById("calendarEventForm");

        form.event_name.value = document.getElementById("eventName").value;
        form.event_desc.value = document.getElementById("eventDesc").value;
        form.event_date.value = document.getElementById("eventDate").value;
        form.start_time.value = document.getElementById("startTime").value;
        form.end_time.value = document.getElementById("endTime").value;
        form.location.value = document.getElementById("location").value;

        form.submit();
    };

});
</script>

<!-- TRANSLATION ENGINE -->
<script>
const translations = {
    "cal.title":      { en:"My Calendar", es:"Mi Calendario", fr:"Mon Calendrier" },
    "cal.addEvent":   { en:"Add Event", es:"Agregar Evento", fr:"Ajouter un Événement" },
    "cal.cancel":     { en:"Cancel", es:"Cancelar", fr:"Annuler" },
    "cal.save":       { en:"Save Event", es:"Guardar Evento", fr:"Enregistrer l'Événement" },
    "cal.date":       { en:"Date", es:"Fecha", fr:"Date" },
    "cal.eventName":  { en:"Event Name", es:"Nombre del Evento", fr:"Nom de l'Événement" },
    "cal.description":{ en:"Description", es:"Descripción", fr:"Description" },
    "cal.startTime":  { en:"Start Time", es:"Hora de Inicio", fr:"Heure de Début" },
    "cal.endTime":    { en:"End Time", es:"Hora de Fin", fr:"Heure de Fin" },
    "cal.location":   { en:"Location", es:"Ubicación", fr:"Lieu" }
};

// TRANSLATED HOLIDAYS
const holidayTranslations = {
    "🎉 New Year's Day": {
        es:"🎉 Año Nuevo",
        fr:"🎉 Jour de l'An"
    },
    "❤️ Valentine's Day": {
        es:"❤️ Día de San Valentín",
        fr:"❤️ Saint-Valentin"
    },
    "🎗 Juneteenth": {
        es:"🎗 Día de la Liberación",
        fr:"🎗 Commémoration du Juneteenth"
    },
    "🎆 Independence Day": {
        es:"🎆 Día de la Independencia",
        fr:"🎆 Fête de l'Indépendance"
    },
    "🎄 Christmas": {
        es:"🎄 Navidad",
        fr:"🎄 Noël"
    },
    "🌸 Mother's Day": {
        es:"🌸 Día de la Madre",
        fr:"🌸 Fête des Mères"
    },
    "🐣 Easter": {
        es:"🐣 Pascua",
        fr:"🐣 Pâques"
    },
    "🇺🇸 Memorial Day": {
        es:"🇺🇸 Día de los Caídos",
        fr:"🇺🇸 Jour du Souvenir"
    },
    "🦃 Thanksgiving": {
        es:"🦃 Día de Acción de Gracias",
        fr:"🦃 Action de Grâce"
    },
    "👨‍👧 Father's Day": {
        es:"👨‍👧 Día del Padre",
        fr:"👨‍👧 Fête des Pères"
    }
};

function translateHoliday(text) {
    const lang = localStorage.getItem("language") || "en";
    if (lang === "en") return text;
    return holidayTranslations[text]?.[lang] || text;
}

function translateUI() {
    const lang = localStorage.getItem("language") || "en";

    document.querySelectorAll("[data-translate]").forEach(el => {
        const key = el.dataset.translate;
        if (translations[key] && translations[key][lang]) {
            el.textContent = translations[key][lang];
        }
    });
}

document.addEventListener("DOMContentLoaded", translateUI);
</script>

</body>
</html>
