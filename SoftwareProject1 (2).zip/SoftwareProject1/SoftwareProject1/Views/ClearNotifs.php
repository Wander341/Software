<?php
session_start();
include_once '../Models/NotificationDAO.php';

if(isset($_SESSION['user']['accessLvl'])) {
    $userId = $_SESSION['user']['user_ID'];
}else {
    header("start.php?action=Login");
}

header('Content-Type: application/json');

if (!$userId) {
    echo json_encode(['success' => false, 'error' => 'No user ID in session']);
    exit;
}

$notifDAO = new NotificationDAO();
$notifDAO->clearNotifications($userId);

echo json_encode(['success' => true]);
?>