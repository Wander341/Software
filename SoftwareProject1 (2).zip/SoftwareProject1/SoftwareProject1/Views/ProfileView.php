<?php
include_once 'config.php';
include_once 'Models/UserDAO.php';
include_once 'Models/NotificationDAO.php';

$userDAO = new UserDAO();
$notifDAO = new NotificationDAO();

$userID = $_SESSION['user']['user_ID'];
$data = [];

/* --------------------------
 *   UPDATE BIO
 * -------------------------- */
if (isset($_POST['updateDesc'])) {
  $userDAO->updateDescription($userID, $_POST['userDesc']);
  $data['success'] = "Description updated.";
}

/* --------------------------
 *   UPDATE BIRTHDAY
 * -------------------------- */
if (isset($_POST['updateBirthday'])) {
  $birthday = $_POST['birthday'];
  $userDAO->updateBirthday($userID, $birthday);
  $data['success'] = "Birthday updated.";
}

/* --------------------------
 *   UPDATE PROFILE PICTURE
 * -------------------------- */
if (isset($_FILES['profilepic']) && $_FILES['profilepic']['error'] === 0) {
  $filename = "uploads/profile_" . $userID . "_" . time() . ".png";
  move_uploaded_file($_FILES['profilepic']['tmp_name'], $filename);
  $userDAO->updateProfilePicture($userID, $filename);
  $data['success'] = "Profile picture updated.";
}

/* --------------------------
 *   REQUEST MODERATOR ACCESS
 * -------------------------- */
if (isset($_POST['requestModerator'])) {
  if (method_exists($userDAO, "getAllModerators")) {
    $mods = $userDAO->getAllModerators();
    foreach ($mods as $m) {
      $notifDAO->createNotification(
        "User #$userID has requested moderator access.",
        "moderator_request",
        [$m['user_ID']]
      );
    }
    $data['success'] = "Your request has been sent to all moderators.";
  } else {
    $data['error'] = "Moderator system not available.";
  }
}

/* --------------------------
 *   LOAD USER DATA
 * -------------------------- */
$data['user'] = $userDAO->getUser($userID);

$birthday = $data['user']->getBirthday();
$data['birthdayFormatted'] = $birthday ? date("F j, Y", strtotime($birthday)) : "Not set";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title data-translate="profile.title">Profile</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="./Styles/profile.css">
<?php include './Styles/Stylesheet.php'; ?>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<style>
.btn-large { font-size: 1.05rem; padding: 12px; }
</style>
</head>
<body>

<?php include 'Navbar.php'; ?>

<div class="container">
<div class="row justify-content-center">

<!-- LEFT SIDEBAR -->
<div class="col-lg-3 col-md-4 pt-4">
<div class="p-4 border rounded shadow-sm profile-sidebar">

<!-- PROFILE PIC -->
<form action="start.php?action=ProfileView" method="POST" enctype="multipart/form-data" id="profilePicForm" class="text-center mb-3">
<div class="position-relative d-inline-block">
<img src="<?= htmlspecialchars($data['user']->getProfilePic()) ?>" class="img-fluid rounded-circle mb-2" style="width:150px;height:150px;object-fit:cover;">
<label for="profilepicInput" class="position-absolute bottom-0 end-0 bg-white rounded-circle p-1 shadow" style="cursor:pointer;">
<i class="fas fa-pencil-alt"></i>
</label>
<input type="file" name="profilepic" id="profilepicInput" style="display:none;" onchange="document.getElementById('profilePicForm').submit();">
</div>
</form>

<!-- USERNAME -->
<h4 class="text-center mb-3" data-translate="profile.usernameLabel">
<?= htmlspecialchars($data['user']->getUsername()) ?>#<?= htmlspecialchars($data['user']->getUserID()) ?>
</h4>

<!-- NAV BUTTONS -->
<div class="d-grid gap-2 pt-2">
<form action="start.php?action=ProfileView" method="POST">
<button class="btn btn-primary btn-large w-100" data-translate="profile.btnProfile">Profile</button>
</form>

<form action="start.php?action=TaskView" method="POST">
<button class="btn btn-primary btn-large w-100" data-translate="profile.btnTasks">Tasks</button>
</form>

<form action="start.php?action=CalendarView" method="POST">
<button class="btn btn-primary btn-large w-100" data-translate="profile.btnCalendar">Calendar</button>
</form>

<form action="start.php?action=FriendRequest" method="POST">
<button class="btn btn-primary btn-large w-100" data-translate="profile.btnFriends">Add Friends</button>
</form>
</div>

<!-- FRIENDS DROPDOWN -->
<div class="mt-3">
<button type="button" class="btn btn-secondary w-100 btn-large" onclick="toggleFriends()" data-translate="profile.friendsHeader">Friends</button>

<div id="friendsDropdown" class="mt-2" style="display:none;">
<?php
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$stmt = $conn->prepare("
SELECT u.username
FROM Friendships f
JOIN USER u ON u.user_ID = f.friend_id
WHERE f.user_id = ? AND f.status = 'active'
");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

echo "<ul class='list-unstyled ps-3'>";
while ($row = $result->fetch_assoc()) {
  echo "<li>" . htmlspecialchars($row['username']) . "</li>";
}
echo "</ul>";

$stmt->close();
$conn->close();
?>
</div>
</div>

<!-- REQUEST MODERATOR -->
<?php if (strtolower($_SESSION['user']['accessLvl']) !== "moderator"): ?>
<form action="start.php?action=ProfileView" method="POST" class="mt-3">
<input type="hidden" name="requestModerator" value="1">
<button type="submit" class="btn btn-warning w-100 btn-large" data-translate="profile.requestMod">
Request Moderator Access
</button>
</form>
<?php else: ?>
<form action="start.php?action=ModeratorView" method="POST" class="mt-3">
<button type="submit" class="btn btn-warning w-100 btn-large" data-translate="profile.goModPage">
Moderator Page
</button>
</form>
<?php endif; ?>

</div>
</div>


<!-- RIGHT PANEL – PROFILE INFO -->
<div class="col-lg-6 col-md-8">
<div class="profile-container p-4 border rounded shadow-sm">

<h2 class="mb-3" data-translate="profile.header">User Profile</h2>

<!-- ALERTS -->
<?php if (!empty($data['error'])): ?>
<div class="alert alert-danger" data-translate="profile.error"><?= htmlspecialchars($data['error']); ?></div>
<?php endif; ?>

<?php if (!empty($data['success'])): ?>
<div class="alert alert-success" data-translate="profile.success"><?= htmlspecialchars($data['success']); ?></div>
<?php endif; ?>

<!-- USER DETAILS -->
<div class="mb-3">

<div class="row mb-2">
<div class="col-4 text-secondary" data-translate="profile.labelUsername">Username:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getUsername()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary" data-translate="profile.labelEmail">Email:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getEmail()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary" data-translate="profile.labelAccess">Access Level:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getAccessLevel()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary" data-translate="profile.labelUAFSID">UAFS ID:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getUafsID()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary" data-translate="profile.labelBirthday">Birthday:</div>
<div class="col-8"><?= htmlspecialchars($data['birthdayFormatted']); ?></div>
</div>

<!-- UPDATE BIRTHDAY -->
<form action="start.php?action=ProfileView" method="POST" class="mb-3">
<label class="form-label fw-bold" data-translate="profile.updateBirthday">Update Birthday</label>
<input type="date" name="birthday" class="form-control mb-2"
value="<?= htmlspecialchars($data['user']->getBirthday()) ?>">
<input type="hidden" name="updateBirthday" value="1">
<button class="btn btn-primary btn-sm" data-translate="profile.saveBirthday">Save Birthday</button>
</form>

</div>

<!-- ABOUT ME -->
<h5 class="fw-bold mt-4" data-translate="profile.about">About Me</h5>

<div class="p-3 mb-3 border rounded bg-light">
<?php if ($data['user']->getDescription()): ?>
<p><?= nl2br(htmlspecialchars($data['user']->getDescription())); ?></p>
<?php else: ?>
<p class="text-muted fst-italic" data-translate="profile.noBio">No bio written yet.</p>
<?php endif; ?>
</div>

<form action="start.php?action=ProfileView" method="POST">
<label for="userDesc" class="form-label" data-translate="profile.editBio">Edit Bio</label>
<textarea name="userDesc" id="userDesc" rows="5" class="form-control mb-2" data-translate-placeholder="profile.bioPlaceholder"><?= htmlspecialchars($data['user']->getDescription()); ?></textarea>
<input type="hidden" name="updateDesc" value="1">
<button type="submit" class="btn btn-primary" data-translate="profile.saveChanges">Save Changes</button>
</form>

<!-- LOGOUT -->
<form action="start.php?action=Logout" method="POST" class="mt-4">
<button class="btn btn-outline-danger btn-large" data-translate="profile.logout">Logout</button>
</form>

</div>
</div>

</div>
</div>

<script>
function toggleFriends() {
  const box = document.getElementById('friendsDropdown');
  box.style.display = box.style.display === 'none' ? 'block' : 'none';
}
</script>

<!-- UNIVERSAL TRANSLATION ENGINE -->
<script>
const translations = {
  "profile.title": { en:"Profile", es:"Perfil", fr:"Profil" },
  "profile.header": { en:"User Profile", es:"Perfil del Usuario", fr:"Profil Utilisateur" },

  "profile.btnProfile": { en:"Profile", es:"Perfil", fr:"Profil" },
  "profile.btnTasks": { en:"Tasks", es:"Tareas", fr:"Tâches" },
  "profile.btnCalendar": { en:"Calendar", es:"Calendario", fr:"Calendrier" },
  "profile.btnFriends": { en:"Add Friends", es:"Agregar Amigos", fr:"Ajouter des Amis" },

  "profile.friendsHeader": { en:"Friends", es:"Amigos", fr:"Amis" },

  "profile.requestMod": { en:"Request Moderator Access", es:"Solicitar Acceso de Moderador", fr:"Demander l'Accès Modérateur" },
  "profile.goModPage": { en:"Moderator Page", es:"Página de Moderador", fr:"Page Modérateur" },

  "profile.labelUsername": { en:"Username:", es:"Usuario:", fr:"Nom d'utilisateur:" },
  "profile.labelEmail": { en:"Email:", es:"Correo:", fr:"Email:" },
  "profile.labelAccess": { en:"Access Level:", es:"Nivel de Acceso:", fr:"Niveau d'accès:" },
  "profile.labelUAFSID": { en:"UAFS ID:", es:"ID UAFS:", fr:"ID UAFS:" },
  "profile.labelBirthday": { en:"Birthday:", es:"Cumpleaños:", fr:"Anniversaire:" },

  "profile.updateBirthday": { en:"Update Birthday", es:"Actualizar Cumpleaños", fr:"Mettre à Jour l'Anniversaire" },
  "profile.saveBirthday": { en:"Save Birthday", es:"Guardar", fr:"Enregistrer" },

  "profile.about": { en:"About Me", es:"Sobre mí", fr:"À propos de moi" },
  "profile.noBio": { en:"No bio written yet.", es:"Aún no hay biografía.", fr:"Aucune bio pour l'instant." },

  "profile.editBio": { en:"Edit Bio", es:"Editar Biografía", fr:"Modifier la Bio" },
  "profile.bioPlaceholder": { en:"Write something about yourself...", es:"Escribe algo sobre ti...", fr:"Écrivez quelque chose sur vous..." },

  "profile.saveChanges": { en:"Save Changes", es:"Guardar Cambios", fr:"Enregistrer les Modifications" },

  "profile.logout": { en:"Logout", es:"Cerrar Sesión", fr:"Déconnexion" }
};

function translatePage() {
  const lang = localStorage.getItem("language") || "en";

  document.querySelectorAll("[data-translate]").forEach(el => {
    const key = el.dataset.translate;
    if (translations[key] && translations[key][lang]) {
      el.textContent = translations[key][lang];
    }
  });

  document.querySelectorAll("[data-translate-placeholder]").forEach(el => {
    const key = el.dataset.translatePlaceholder;
    if (translations[key] && translations[key][lang]) {
      el.placeholder = translations[key][lang];
    }
  });
}

translatePage();
</script>

<?php include 'Scripts.php'; ?>
</body>
</html>
