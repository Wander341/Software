<?php
$activeQuery = "
  SELECT u.username 
  FROM Friendships f
  JOIN USER u ON u.user_ID = f.friend_id
  WHERE f.user_id = ? AND f.status = 'active'
";
$activeStmt = $conn->prepare($activeQuery);
$activeStmt->bind_param("i", $currentUser);
$activeStmt->execute();
$activeResult = $activeStmt->get_result();

if ($activeResult->num_rows > 0): ?>
  <table>
    <tr><th>Username</th></tr>
    <?php while ($row = $activeResult->fetch_assoc()): ?>
      <tr><td><?php echo htmlspecialchars($row['username']); ?></td></tr>
    <?php endwhile; ?>
  </table>
<?php else: ?>
  <p>You have no active friends.</p>
<?php endif;
$activeStmt->close();
$conn->close();
?>