<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create Account</title>
  <link rel="stylesheet" href="./Styles/login.css">
  
</head>
<body>
  <div class="login-container">
    <h2>Create Account</h2>

    <?php if (!empty($data['error'])): ?>
      <p style="color:red;"><?php echo htmlspecialchars($data['error']); ?></p>
    <?php endif; ?>

    <form action="start.php?action=CreateAccount" method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="text" name="email" placeholder="Email" required>
      <input type="text" name="uafs_id" placeholder="UAFS ID" pattern="\d*" oninput="this.value = this.value.replace(/[^0-9]/g, '')" required>
      <input type="submit" name="create" value="Create Account">
    </form>
  </div>
</body>
</html>
