<?php
$task = $data['task'] ?? null;
if (!$task) {
    echo "No task data found.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Update Task</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./Styles/navbar.css">
    <script src="https://kit.fontawesome.com/a2e0f1f6d8.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f4f6f9;
        }

        .update-container {
            max-width: 650px;
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin: 50px auto;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .btn-update {
            background-color: #007bff;
            color: white;
        }

        .btn-update:hover {
            background-color: #0069d9;
        }
    </style>
</head>

<body>

    <?php include 'Navbar.php'; ?>

    <div class="update-container">
        <h3 class="text-center mb-4 text-primary"><i class="fa-solid fa-pen"></i> Update Your Task</h3>
        <form method="POST" action="start.php?action=TaskUpdateForm">
            <input type="hidden" name="task_id" value="<?= htmlspecialchars($task['task_id']) ?>">

            <div class="mb-3">
                <label class="form-label">Task Name</label>
                <input type="text" name="task_name" class="form-control"
                    value="<?= htmlspecialchars($task['task_name']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="task_desc" class="form-control" rows="4"
                    required><?= htmlspecialchars($task['task_desc']) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Due Date</label>
                <input type="datetime-local" name="due_date" class="form-control"
                    value="<?= date('Y-m-d\TH:i', strtotime($task['due_date'])) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="Pending" <?= $task['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="In Progress" <?= $task['status'] === 'In Progress' ? 'selected' : '' ?>>In Progress
                    </option>
                    <option value="Completed" <?= $task['status'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
                </select>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="start.php?action=TaskView" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back
                </a>
                <button type="submit" name="update_task" class="btn btn-update">
                    <i class="fa-solid fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    </div>
    <?php include 'Scripts.php'; ?>
</body>

</html>