<?php
include_once "./Models/NotificationDAO.php";

$active = $_GET['action'] ?? 'Home';

$notifications = [];
$notifCount = 0;

// Load notifications only when logged in
$userId = $_SESSION['user']['user_ID'] ?? null;

if ($userId) {
  $notifDAO = new NotificationDAO();
  $notifications = $notifDAO->getNotifications($userId);
  $notifCount = count($notifications);
}
?>
<nav class="navbar navbar-expand-lg bg-light border-bottom">
<div class="container-fluid">

<!-- Brand / Logo -->
<a class="navbar-brand" href="start.php?action=Home">
<img src="./Images/LockedIn_favicon2.png" width="50" height="50" alt="Logo">
</a>

<!-- Hamburger -->
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
<span class="navbar-toggler-icon"></span>
</button>

<!-- Navigation -->
<div class="collapse navbar-collapse" id="navbarContent">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">

<li class="nav-item">
<a class="nav-link <?= $active === 'Home' ? 'active' : '' ?>"
href="start.php?action=Home" data-translate="navbar.home">Home</a>
</li>

<li class="nav-item">
<a class="nav-link <?= $active === 'MapView' ? 'active' : '' ?>"
href="start.php?action=MapView" data-translate="navbar.map">Map</a>
</li>

<li class="nav-item">
<a class="nav-link <?= $active === 'ExistingEvents' ? 'active' : '' ?>"
href="start.php?action=ExistingEvents" data-translate="navbar.events">Events</a>
</li>

<li class="nav-item">
<a class="nav-link <?= $active === 'ThreadView' ? 'active' : '' ?>"
href="start.php?action=ThreadView" data-translate="navbar.threads">Threads</a>
</li>

<li class="nav-item">
<a class="nav-link <?= $active === 'GroupView' ? 'active' : '' ?>"
href="start.php?action=GroupView" data-translate="navbar.groups">Groups</a>
</li>

</ul>
</div>

<!-- DARK / LIGHT MODE -->
<button id="DLToggle" class="btn p-0 bg-transparent border-0 me-3">
<i id="DLIcon" class="bi bi-moon-fill"></i>
</button>

<!-- RIGHT SIDE -->
<div class="d-flex align-items-center ms-auto">

<!-- Calendar Icon -->
<a href="start.php?action=CalendarView"
class="nav-link <?= $active === 'CalendarView' ? 'active' : '' ?> text-dark me-3 px-2">
<i class="bi bi-calendar-event" style="font-size: 1.4rem;"></i>
</a>

<!-- NOTIFICATIONS -->
<li class="nav-item dropdown list-unstyled me-3">

<a class="nav-link dropdown-toggle p-2" href="#" data-bs-toggle="dropdown">
<span class="position-relative">
<i class="fa-solid fa-bell fs-4"></i>

<?php if ($notifCount > 0): ?>
<span class="badge bg-danger rounded-pill position-absolute"
style="top: -6px; right: -6px; font-size: 0.65rem;">
<?= $notifCount ?>
</span>
<?php endif; ?>
</span>
</a>

<ul class="dropdown-menu dropdown-menu-end" style="max-height:300px;overflow-y:auto;">
<?php if ($notifCount == 0): ?>
<li><span class="dropdown-item-text text-muted">No notifications</span></li>
<?php else: ?>

<?php foreach ($notifications as $notif): ?>
<li>
<span class="dropdown-item">
<strong><?= htmlspecialchars($notif['notif_type']); ?>:</strong>
<?= htmlspecialchars($notif['notif_name']); ?><br>
<small class="text-muted"><?= $notif['time_sent']; ?></small>
</span>
</li>
<li><hr class="dropdown-divider"></li>
<?php endforeach; ?>

<li class="text-center">
<button class="btn btn-danger btn-sm fw-bold" onclick="clearNotifications()">
Clear Notifications
</button>
</li>
<?php endif; ?>
</ul>

</li>

<!-- PROFILE DROPDOWN -->
<div class="d-lg-flex">
<?php include 'ProfileIcon.php'; ?>
</div>

<!-- LANGUAGE SWITCHER -->
<li class="nav-item dropdown ms-3">
<a class="nav-link dropdown-toggle" href="#" id="languageDropdown"
data-bs-toggle="dropdown" data-translate="navbar.language">Language</a>

<ul class="dropdown-menu">
<li><a class="dropdown-item" onclick="changeLanguage('en')">English</a></li>
<li><a class="dropdown-item" onclick="changeLanguage('es')">Español</a></li>
<li><a class="dropdown-item" onclick="changeLanguage('fr')">Français</a></li>
</ul>
</li>

</div>

</div>
</nav>

<!-- ============================== -->
<!-- JAVASCRIPT SECTION -->
<!-- ============================== -->

<script>
/* CLEAR NOTIFICATIONS */
function clearNotifications() {
  fetch('./Views/ClearNotifs.php', { method: 'POST' })
  .then(r => r.json())
  .then(data => data.success ? location.reload() : alert("Failed to clear notifications"))
  .catch(err => alert("Error clearing notifications"));
}

/* LANGUAGE SYSTEM */
function changeLanguage(lang) {
  localStorage.setItem('language', lang);
  location.reload();
}

document.addEventListener("DOMContentLoaded", () => {
  const lang = localStorage.getItem("language") || "en";
  setLanguage(lang);

  const theme = localStorage.getItem("theme") || "light";
  applyTheme(theme);
});

/* DARK / LIGHT MODE */
document.getElementById("DLToggle").addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-bs-theme");
  const newTheme = current === "light" ? "dark" : "light";
  localStorage.setItem("theme", newTheme);
  applyTheme(newTheme);
});

/* APPLY THEME */
function applyTheme(theme) {
  const html = document.documentElement;
  html.setAttribute("data-bs-theme", theme);

  const navbar = document.querySelector(".navbar");
  const icons = document.querySelectorAll(".navbar i, .navbar svg");
  const links = document.querySelectorAll(".navbar .nav-link, .navbar .dropdown-toggle");

  if (theme === "dark") {
    navbar.classList.remove("bg-light");
    navbar.classList.add("bg-dark", "navbar-dark");
    icons.forEach(i => i.style.color = "white");
    links.forEach(l => l.style.color = "white");
  } else {
    navbar.classList.remove("bg-dark", "navbar-dark");
    navbar.classList.add("bg-light", "navbar-light");
    icons.forEach(i => i.style.color = "");
    links.forEach(l => l.style.color = "");
  }

  updateThemeIcon(theme);
}

function updateThemeIcon(theme) {
  const icon = document.getElementById("DLIcon");
  icon.className = theme === "light"
  ? "bi bi-moon-fill"
  : "bi bi-sun-fill text-warning";
}

/* TRANSLATIONS */
function setLanguage(languageCode) {
  const translations = {
    en: { "navbar.home":"Home","navbar.map":"Map","navbar.events":"Events",
      "navbar.threads":"Threads","navbar.groups":"Groups","navbar.language":"Language",
      "navbar.view_profile":"View Profile","navbar.logout":"Logout" },
      es: { "navbar.home":"Inicio","navbar.map":"Mapa","navbar.events":"Eventos",
        "navbar.threads":"Hilos","navbar.groups":"Grupos","navbar.language":"Idioma",
        "navbar.view_profile":"Ver Perfil","navbar.logout":"Cerrar Sesión" },
        fr: { "navbar.home":"Accueil","navbar.map":"Carte","navbar.events":"Événements",
          "navbar.threads":"Discussion","navbar.groups":"Groupes","navbar.language":"Langue",
          "navbar.view_profile":"Voir le Profil","navbar.logout":"Se Déconnecter" }
  };

  const t = translations[languageCode];
  if (!t) return;

  Object.keys(t).forEach(key => {
    let el = document.querySelector(`[data-translate="${key}"]`);
    if (el) el.innerText = t[key];
  });
}
</script>
