<?php
$nodes = $data['nodes'];
?>
<!DOCTYPE html>
<html>
<head>
<title data-translate="map.title">UAFS Event Map</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=1.0">

<?php include './Styles/Stylesheet.php'; ?>

<style>
/* =====================================================
 *          ULTRA DARK MODE PATCHES
 * =====================================================*/

html[data-bs-theme="dark"] body {
  background-color: #000 !important;
  color: #fff !important;
}

.directions-card {
  padding: 20px;
  border-radius: 10px;
  margin-top: 20px;
  transition: background-color 0.4s, color 0.4s;
}

html[data-bs-theme="light"] .directions-card {
  background-color: #f8f9fa !important;
  color: #000 !important;
}

html[data-bs-theme="dark"] .directions-card {
  background-color: #0d0d0d !important;
  color: #fff !important;
  border: 1px solid #222 !important;
}

#map-container {
flex-grow: 1;
min-height: 50vh;
border-radius: 5px;
margin-top: 20px;
overflow: hidden;
}

html[data-bs-theme="dark"] #map-container {
  background-color: #000 !important;
  border: 1px solid #222 !important;
}

html[data-bs-theme="dark"] .leaflet-popup-content-wrapper,
html[data-bs-theme="dark"] .leaflet-popup-tip {
  background-color: #111 !important;
  color: #fff !important;
  border: 1px solid #333 !important;
}

#content {
display: flex;
padding: 20px;
gap: 20px;
}

#map {
height: 100%;
width: 100%;
cursor: crosshair;
}

.leaflet-marker-icon {
  cursor: pointer;
}
</style>
</head>
<body>

<?php include 'Navbar.php'; ?>

<!-- EVENT DIRECTIONS HEADER -->
<div class="px-4 py-5 my-5 text-center shadow directions-card">

<h2 class="fw-bold" data-translate="map.header">Event Directions</h2>

<div class="col-md-8 mx-auto my-4">
<p class="lead mb-0" data-translate="map.instructions">
Click on a node to see the building name. Double click a node to create an event in that building.
You will then fill out the Event Creation Form. You can also view who registered for the event.
</p>
</div>

<a href="start.php?action=ExistingEvents"
class="btn btn-primary btn-lg"
data-translate="map.upcomingEvents">
Upcoming Events
</a>

</div>

<div id="content">
<div id="map-container">
<div id="map"></div>
</div>
</div>

<?php include 'Scripts.php'; ?>

<script>
/* =====================================================
 * TRANSLATION ENGINE — SAME AS HOME PAGE
 * =====================================================*/

const translations = {
  "map.title": {
    en: "UAFS Event Map",
    fr: "Carte des événements UAFS",
    es: "Mapa de eventos de UAFS"
  },

  "map.header": {
    en: "Event Directions",
    fr: "Instructions pour les événements",
    es: "Instrucciones del evento"
  },

  "map.instructions": {
    en: "Click on a node to see the building name. Double click a node to create an event in that building. You will then fill out the Event Creation Form. You can also view who registered for the event.",
    fr: "Cliquez sur un nœud pour voir le nom du bâtiment. Double-cliquez pour créer un événement dans ce bâtiment. Vous remplirez ensuite le formulaire de création d'événement. Vous pouvez également voir qui s'est inscrit.",
    es: "Haga clic en un nodo para ver el nombre del edificio. Haga doble clic para crear un evento en ese edificio. Luego completará el formulario de creación de eventos. También puede ver quién se registró."
  },

  "map.upcomingEvents": {
    en: "Upcoming Events",
    fr: "Événements à venir",
    es: "Próximos eventos"
  }
};

let lang = localStorage.getItem("language") || "en";

function translatePage() {
  document.querySelectorAll("[data-translate]").forEach(el => {
    let key = el.getAttribute("data-translate");
    if (translations[key] && translations[key][lang]) {
      el.textContent = translations[key][lang];
    }
  });
}

translatePage();

/* =====================================================
 * LEAFLET MAP SETUP
 * =====================================================*/

const imageWidth = 1388;
const imageHeight = 938;
const bounds = [[0, 0], [imageHeight, imageWidth]];

const map = L.map('map', {
  crs: L.CRS.Simple,
  minZoom: -2,
  maxZoom: 2,
  zoom: 0,
  center: [imageHeight / 2, imageWidth / 2]
});

const imageUrl = './Images/uafsmap.png';
L.imageOverlay(imageUrl, bounds).addTo(map);
map.fitBounds(bounds);

const nodes = <?php echo json_encode($nodes); ?>;

nodes.forEach(node => {
  const marker = L.marker([node.y, node.x]).addTo(map);
  marker.bindPopup(`<strong>${node.node_name}</strong>`);

  let last = 0;
  marker.on("click", () => {
    const now = Date.now();
    if (now - last < 1000) {
      window.location.href = `start.php?action=EventCreationForm&node_id=${node.node_id}`;
    } else {
      marker.openPopup();
    }
    last = now;
  });
});
</script>

</body>
</html>
