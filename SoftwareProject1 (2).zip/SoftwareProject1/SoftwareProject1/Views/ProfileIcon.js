
function toggleDropdown() {
  const dropdown = document.getElementById('profile-icon-dropdown');
  dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

document.addEventListener('click', function (e) {
  const profile = document.getElementById('profile-icon-container');
  if (!profile.contains(e.target)) {
    document.getElementById('profile-icon-dropdown').style.display = 'none';
  }
});