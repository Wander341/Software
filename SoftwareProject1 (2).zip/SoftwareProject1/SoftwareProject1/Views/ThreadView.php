<?php
require_once 'Models/Thread.php';
require_once 'Controllers/MessageLoad.php';
require_once 'Models/UserDAO.php';
require_once 'Models/User.php';

$threadModel = new Thread();
$threads = $threadModel->getAllThreads();
$numThreads = count($threads);

if (!empty($data['threadId'])) {
  $selectedThreadId = $data['threadId'];
  foreach ($threads as $thread) {
    if ($selectedThreadId == $thread->getThreadId()) {
      $selectedThreadName = $thread->getThreadName();
      break;
    }
  }
} else if (!empty($threads)) {
  $selectedThreadId = $threads[0]->getThreadId();
  $selectedThreadName = $threads[0]->getThreadName();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_thread'])) {
  $selectedThreadId = htmlspecialchars($_POST['selected_thread']);
  foreach ($threads as $thread) {
    if ($selectedThreadId == $thread->getThreadId()) {
      $selectedThreadName = $thread->getThreadName();
      break;
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include './Styles/Stylesheet.php'; ?>
<meta charset="UTF-8">
<title data-translate="threads.title">Thread View</title>
</head>

<body>
<?php include 'Navbar.php'; ?>

<div class="container-fluid">

<!-- Sidebar Toggle -->
<button class="btn btn-primary m-2 d-flex align-items-center gap-2" type="button"
data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas" aria-controls="sidebarOffcanvas">
<i class="fa-solid fa-arrow-right"></i>
<span data-translate="threads.openSidebar">Open Threads</span>
</button>

<!-- Sidebar -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarOffcanvas">
<div class="offcanvas-header">
<h5 class="offcanvas-title" data-translate="threads.sidebarTitle">Threads</h5>
<button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
</div>

<div class="offcanvas-body">
<h2 data-translate="threads.createTitle">Create Thread</h2>

<form method="POST" action="start.php?action=ThreadView" class="mb-4">
<input type="text" name="thread_name" class="form-control mb-2"
placeholder="Thread name" data-translate-placeholder="threads.placeholderName" required>
<button type="submit" class="btn btn-success w-100" data-translate="threads.createBtn">Create</button>
</form>

<h2 data-translate="threads.threadList">Threads</h2>

<?php foreach ($threads as $thread): ?>
<?php $isActive = ($thread->getThreadId() == $selectedThreadId); ?>
<form method="POST" action="start.php?action=ThreadView" class="mb-2">
<input type="hidden" name="selected_thread" value="<?= $thread->getThreadId(); ?>">
<button type="submit"
class="btn <?= $isActive ? 'btn-dark' : 'btn-primary' ?> w-100 text-start">
<?= htmlspecialchars($thread->getThreadName()); ?>
</button>
</form>
<?php endforeach; ?>
</div>
</div>

<!-- Chat Panel -->
<div class="row mt-3">
<div class="col-12 col-md-10 col-lg-8 mx-auto">
<div class="border rounded shadow-sm p-3 d-flex flex-column" style="min-height: 600px; max-height: 80vh;">
<div class="bg-primary text-white p-3 mb-3 fw-bold fs-4 rounded">
<?= htmlspecialchars($selectedThreadName ?? 'No Thread Selected'); ?>
</div>

<div class="flex-grow-1 overflow-auto" style="max-height: 70vh;" id="chatMessages">

<?php
$currentUserId = $_SESSION['user']['user_ID'] ?? null;
if (!empty($selectedThreadId)) {
  $loader = new MessageLoad();
  $messages = $loader->loadMessagesByThreadId($selectedThreadId);

  foreach ($messages as $msg) {
    $userDAO = new UserDAO();
    $user = $userDAO->getUser($msg->user_id);

    $dt = new DateTime($msg->time_sent, new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone('America/Chicago'));
    $formattedTime = $dt->format('M j, Y g:i A');

    $isOwnMessage = ($msg->user_id == $currentUserId);
    $bubbleClass = $isOwnMessage ? 'bg-primary text-white' : 'bg-light text-dark';
    $justifyClass = $isOwnMessage ? 'justify-content-end' : 'justify-content-start';
    $timestampClass = $isOwnMessage ? 'text-dark' : 'text-secondary';

    echo '<div class="d-flex ' . $justifyClass . ' mb-2" data-message-id="' . $msg->message_id . '">';
    echo '<div class="p-2 rounded shadow-sm ' . $bubbleClass . '" style="max-width: 75%; word-wrap: break-word;">';
    echo '<div class="d-flex mb-1">';
    if ($isOwnMessage) {
      echo '<span class="' . $timestampClass . ' small me-2">' . htmlspecialchars($formattedTime) . '</span>';
      echo '<span class="fw-bold ps-3">' . htmlspecialchars($user->getUsername()) . '</span>';
    } else {
      echo '<span class="fw-bold me-2">' . htmlspecialchars($user->getUsername()) . '</span>';
      echo '<span class="' . $timestampClass . ' small">' . htmlspecialchars($formattedTime) . '</span>';
    }
    echo '</div>';
    echo '<div class="fs-6 text-break">' . htmlspecialchars($msg->message_text) . '</div>';
    echo '</div>';
    echo '</div>';
  }
}
?>

</div>

<button id="jump-to-present" class="btn btn-primary mt-2 d-none" data-translate="threads.jump">
Jump to Present
</button>
</div>

<!-- Chat Input -->
<form method="POST" action="start.php?action=ThreadReload" class="mt-3 d-flex gap-2">
<input type="hidden" name="thread_id" value="<?= $selectedThreadId; ?>">
<input type="text" name="message_text" class="form-control"
placeholder="Type a message..." data-translate-placeholder="threads.typeMessage" required>
<button type="submit" class="btn btn-success" data-translate="threads.send">Send</button>
</form>

</div>
</div>
</div>

<?php include 'Scripts.php'; ?>

<!-- Auto-refresh chat + Translate Engine -->
<script>
let lastMessageId = <?php echo $messages[count($messages)-1]->message_id ?? 0; ?>;
const threadId = <?= $selectedThreadId ?>;
const chatMessages = document.querySelector('#chatMessages');
const jumpButton = document.getElementById('jump-to-present');

function isNearBottom() {
  return chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight < 100;
}

setInterval(() => {
  fetch(`./Controllers/MessageCheck.php?threadId=${threadId}&lastMessageId=${lastMessageId}`)
  .then(r => r.text())
  .then(html => {
    if (html.trim()) {
      const nearBottom = isNearBottom();
      chatMessages.innerHTML += html;

      const newId = chatMessages.lastElementChild?.dataset.messageId;
      if (newId) lastMessageId = parseInt(newId);

      if (nearBottom) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
        jumpButton.classList.add('d-none');
      } else {
        jumpButton.classList.remove('d-none');
      }
    }
  });
}, 1000);

jumpButton.onclick = () => {
  chatMessages.scrollTop = chatMessages.scrollHeight;
  jumpButton.classList.add('d-none');
};

/* =============================================
 *      UNIVERSAL TRANSLATION ENGINE
 *   ============================================= */
const translations = {
  "threads.title": { en:"Thread View", es:"Vista de Hilos", fr:"Vue des Fils" },
  "threads.openSidebar": { en:"Open Threads", es:"Abrir Hilos", fr:"Ouvrir les Fils" },
  "threads.sidebarTitle": { en:"Threads", es:"Hilos", fr:"Fils" },
  "threads.createTitle": { en:"Create Thread", es:"Crear Hilo", fr:"Créer un Fil" },
  "threads.placeholderName": { en:"Thread name", es:"Nombre del hilo", fr:"Nom du fil" },
  "threads.createBtn": { en:"Create", es:"Crear", fr:"Créer" },
  "threads.threadList": { en:"Threads", es:"Hilos", fr:"Fils" },
  "threads.jump": { en:"Jump to Present", es:"Ir al Presente", fr:"Aller au Présent" },
  "threads.typeMessage": { en:"Type a message...", es:"Escribe un mensaje...", fr:"Tapez un message..." },
  "threads.send": { en:"Send", es:"Enviar", fr:"Envoyer" }
};

let lang = localStorage.getItem("language") || "en";

function translatePage() {
  document.querySelectorAll("[data-translate]").forEach(el => {
    const key = el.dataset.translate;
    if (translations[key] && translations[key][lang]) {
      el.textContent = translations[key][lang];
    }
  });

  document.querySelectorAll("[data-translate-placeholder]").forEach(el => {
    const key = el.dataset.translatePlaceholder;
    if (translations[key] && translations[key][lang]) {
      el.placeholder = translations[key][lang];
    }
  });
}

translatePage();
</script>

</body>
</html>
