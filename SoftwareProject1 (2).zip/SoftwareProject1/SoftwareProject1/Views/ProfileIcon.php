<?php
include_once "./Models/UserDAO.php";

$user = null;
if (isset($_SESSION['user']['user_ID'])) {
    $dao = new UserDAO();
    $user = $dao->getUser($_SESSION['user']['user_ID']);
}
?>
<div class="text-end pe-3">
    <div class="dropdown d-inline-block">

    <?php if ($user): ?>

        <!-- Trigger -->
        <a href="#"
           class="d-block link-body-emphasis text-decoration-none dropdown-toggle"
           id="dropdownUser"
           data-bs-toggle="dropdown"
           aria-expanded="false">

            <img src="<?= htmlspecialchars($user->getProfilePic()) ?>"
                 alt="Profile Picture"
                 width="40"
                 height="40"
                 class="rounded-circle"
                 style="object-fit: cover;">

            <span class="ms-2 fw-semibold">
                <?= htmlspecialchars($user->getUsername()) ?>
            </span>
        </a>

        <!-- Dropdown Menu -->
        <ul class="dropdown-menu dropdown-menu-end text-small" aria-labelledby="dropdownUser">

            <!-- Username + ID -->
            <li>
                <span class="dropdown-item-text text-muted small">
                    <?= htmlspecialchars($user->getUsername()) ?>#<?= htmlspecialchars($user->getUserID()) ?>
                </span>
            </li>

            <!-- View Profile -->
            <li>
                <a class="dropdown-item"
                   href="start.php?action=ProfileView"
                   data-translate="navbar.view_profile">
                    View Profile
                </a>
            </li>

            <li><hr class="dropdown-divider"></li>

            <!-- Logout -->
            <li>
                <form action="start.php?action=Logout" method="POST" class="m-0">
                    <button type="submit"
                            class="dropdown-item text-danger"
                            data-translate="navbar.logout">
                        Log Out
                    </button>
                </form>
            </li>

        </ul>

    <?php else: ?>

        <!-- Not logged in -->
        <a href="start.php?action=Login" class="btn btn-outline-primary">
            Log In
        </a>

    <?php endif; ?>

    </div>
</div>
