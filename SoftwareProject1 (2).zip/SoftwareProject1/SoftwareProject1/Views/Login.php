<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="../Styles/login.css">
  <style>
    .button-row {
      display: flex;
      gap: 10px;
      margin-top: 10px;
    }
    .button-row form {
      margin: 0;
    }
    .button-row input[type="submit"] {
      width: 100%;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Login</h2>

    <?php if (!empty($data['error'])): ?>
      <p style="color:red;"><?php echo htmlspecialchars($data['error']); ?></p>
    <?php endif; ?>

    <form action="start.php?action=Login" method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <div class="button-row">
        <input type="submit" name="login" value="Login">
      </div>
    </form>

    <form action="start.php?action=CreateAccount" method="POST">
      <div class="button-row">
        <input type="submit" name="create" value="Create Account">
      </div>
    </form>
  </div>
</body>
</html>
