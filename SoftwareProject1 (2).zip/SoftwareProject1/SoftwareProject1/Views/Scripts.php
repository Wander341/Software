<!-- ============================
BOOTSTRAP + LEAFLET CORE JS
============================ -->

<!-- Leaflet Map Library -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- Bootstrap JS Bundle (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<!-- ============================
FRIEND REQUEST: ACCEPT BUTTON
============================ -->
<script>
document.addEventListener('DOMContentLoaded', () => {

    // Attach click event to all Accept buttons dynamically
    document.querySelectorAll('.accept-btn').forEach(button => {

        button.addEventListener('click', function () {

            const friendId = this.dataset.friendId;

            fetch('start.php?action=FriendRequest&subaction=accept', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'friend_id=' + encodeURIComponent(friendId)
            })
            .then(response => response.text())
            .then(() => {
                // Remove the row immediately from the UI
                const row = this.closest('tr');
                if (row) row.remove();
            })
            .catch(error => {
                console.error('Error accepting friend request:', error);
                alert('There was an error accepting the friend request.');
            });

        });

    });

});
</script>
