<?php
require_once 'Models/Group.php';
require_once 'Controllers/MessageLoad.php';
require_once 'Models/UserDAO.php';
require_once 'Models/User.php';

$groupModel = new Group();
$userID = $_SESSION['user']['user_ID'];
$groups = $groupModel->getAllGroupsByUser($userID);

// Determine selected group
$selectedGroupId = $_GET['group_id'] ?? (!empty($groups) ? ($groups[0]->getGroupID() ?? 0) : 0);

$selectedGroup = $selectedGroupId ? $groupModel->getGroup($selectedGroupId) : null;
$groupMembers = $selectedGroup ? $selectedGroup->getStudents() : [];
$selectedGroupName = $selectedGroup ? $selectedGroup->getGroupName() : "No groups yet";

// Load messages
$loader = new MessageLoad();
$messages = $selectedGroupId ? $loader->loadMessagesByGroupId($selectedGroupId) : [];

// Notifications
$groupMessageNotifs = [];
if (!empty($notifications)) {
  foreach ($notifications as $notif) {
    if ($notif['notif_type'] === 'message') {
      $groupMessageNotifs[] = $notif['notif_name'];
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title data-translate="groups.title">Group View</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include './Styles/Stylesheet.php'; ?>
<link rel="stylesheet" href="./Styles/group.css">

<style>
/* ULTRA DARK MODE FIXES */
html[data-bs-theme="dark"] .chat-panel,
html[data-bs-theme="dark"] .chat-messages,
html[data-bs-theme="dark"] .chat-header,
html[data-bs-theme="dark"] .offcanvas,
html[data-bs-theme="dark"] .offcanvas-body,
html[data-bs-theme="dark"] .offcanvas-header,
html[data-bs-theme="dark"] #member-panel,
html[data-bs-theme="dark"] .bg-light {
  background: #000 !important;
  color: #fff !important;
  border-color: #222 !important;
}
html[data-bs-theme="dark"] .bg-light.text-dark {
  background: #111 !important;
  color: #fff !important;
}
html[data-bs-theme="dark"] .text-secondary {
  color: #bbb !important;
}
.notif-dot {
  width: 10px; height: 10px;
  background: red; border-radius: 50%;
  position: absolute; top: 8px; right: 8px;
}
</style>
</head>

<body>

<?php include 'Navbar.php'; ?>

<div class="container-fluid mt-3 px-5">

<!-- GROUP HEADER -->
<div class="text-center mb-3">
<div class="bg-primary text-white fw-bold rounded d-inline-block"
style="font-size: 2rem; padding: 1rem 2rem;"
data-translate="groups.header">
<?= htmlspecialchars($selectedGroupName); ?>
</div>
</div>

<!-- BUTTON ROW -->
<div class="d-flex justify-content-between align-items-center mb-3">

<button class="btn btn-primary d-flex align-items-center gap-2"
data-bs-toggle="offcanvas" data-bs-target="#groupSidebarOffcanvas">
<i class="fa-solid fa-arrow-right"></i>
<span data-translate="groups.sidebarBtn">Groups</span>
</button>

<button class="btn btn-outline-secondary d-flex align-items-center gap-2"
data-bs-toggle="offcanvas" data-bs-target="#memberSidebarOffcanvas">
<i class="fa-solid fa-users"></i>
<span data-translate="groups.membersBtn">View Members</span>
</button>

</div>

<!-- CHAT PANEL -->
<?php if ($selectedGroupId): ?>
<div class="chat-panel mb-4 p-3 border rounded">

<div class="chat-header fw-bold fs-5 mb-2" data-translate="groups.messagesHeader">
Messages
</div>

<div class="chat-messages d-flex flex-column gap-2" style="max-height:60vh; overflow-y:auto;">

<?php foreach ($messages as $msg): ?>
<?php
$userDAO = new UserDAO();
$user = $userDAO->getUser($msg->user_id);

$dt = new DateTime($msg->time_sent, new DateTimeZone('UTC'));
$dt->setTimezone(new DateTimeZone('America/Chicago'));
$formattedTime = $dt->format('M j, Y g:i A');

$isOwnMessage = ($msg->user_id == $_SESSION['user']['user_ID']);
$bubbleClass = $isOwnMessage ? 'bg-primary text-white' : 'bg-light text-dark';
$justifyClass = $isOwnMessage ? 'justify-content-end' : 'justify-content-start';
$timestampClass = $isOwnMessage ? 'text-dark' : 'text-secondary';
?>

<div class="d-flex <?= $justifyClass ?> mb-2" data-message-id="<?= $msg->message_id; ?>">
<div class="p-2 rounded shadow-sm <?= $bubbleClass ?>"
style="max-width: 75%; width: fit-content; word-wrap: break-word;">

<div class="d-flex mb-1">
<?php if ($isOwnMessage): ?>
<span class="<?= $timestampClass ?> small me-2"><?= $formattedTime ?></span>
<span class="fw-bold fs-6"><?= htmlspecialchars($user->getUsername()); ?></span>
<?php else: ?>
<span class="fw-bold fs-6 me-2"><?= htmlspecialchars($user->getUsername()); ?></span>
<span class="<?= $timestampClass ?> small"><?= $formattedTime ?></span>
<?php endif; ?>
</div>

<div class="fs-6 text-break <?= $isOwnMessage ? 'text-end' : '' ?>"
data-dynamic-translate
data-original-text="<?= htmlspecialchars($msg->message_text); ?>">
<?= htmlspecialchars($msg->message_text); ?>
</div>

</div>
</div>

<?php endforeach; ?>

</div>

<button id="jump-to-present" class="btn btn-primary mt-2 align-self-end d-none"
data-translate="groups.jumpBtn">
Jump to Present
</button>
</div>

<!-- MESSAGE INPUT -->
<form method="POST" action="start.php?action=SendMessage" class="d-flex gap-2">
<input type="hidden" name="group_id" value="<?= $selectedGroupId; ?>">
<input type="text" name="message_text" class="form-control"
placeholder="Type a message..."
data-translate-placeholder="groups.messagePH" required>
<button type="submit" class="btn btn-primary" data-translate="groups.sendBtn">Send</button>
</form>

<?php endif; ?>
</div>

<!-- GROUP SIDEBAR -->
<div class="offcanvas offcanvas-start" id="groupSidebarOffcanvas">
<div class="offcanvas-header">
<h5 data-translate="groups.sidebarTitle">Your Groups</h5>
<button class="btn-close" data-bs-dismiss="offcanvas"></button>
</div>

<div class="offcanvas-body">
<?php foreach ($groups as $group): ?>
<?php
$gName = $group->getGroupName();
$notifText = "You have new messages from " . $gName;
$hasNotif = in_array($notifText, $groupMessageNotifs);
?>
<a href="start.php?action=GroupView&group_id=<?= $group->getGroupID(); ?>"
class="d-block btn btn-primary mb-2 position-relative">
<?= htmlspecialchars($gName); ?>
<?php if ($hasNotif): ?><span class="notif-dot"></span><?php endif; ?>
</a>
<?php endforeach; ?>
</div>
</div>

<!-- MEMBER SIDEBAR -->
<div class="offcanvas offcanvas-end" id="memberSidebarOffcanvas">
<div class="offcanvas-header">
<h5 data-translate="groups.memberSidebarTitle">Members</h5>
<button class="btn-close" data-bs-dismiss="offcanvas"></button>
</div>

<div class="offcanvas-body">
<div class="d-flex flex-column gap-2">

<?php foreach ($groupMembers as $member):
$fullUser = (new UserDAO())->getUser($member['user_id']);
?>
<button class="btn btn-outline-primary d-flex align-items-center gap-2 member-btn"
data-username="<?= htmlspecialchars($fullUser->getUsername()); ?>"
data-email="<?= htmlspecialchars($fullUser->getEmail()); ?>"
data-desc="<?= htmlspecialchars($fullUser->getDescription()); ?>"
data-profile="<?= htmlspecialchars($fullUser->getProfilePic()); ?>">

<img src="<?= $fullUser->getProfilePic(); ?>" class="rounded-circle"
style="width:24px;height:24px;">
<?= htmlspecialchars($fullUser->getUsername()); ?>

</button>
<?php endforeach; ?>

</div>
</div>
</div>

<!-- MEMBER PANEL -->
<div id="member-panel" class="position-fixed border p-3 shadow"
style="top: 20px; right: -350px; width: 300px; transition: right 0.3s; background:white;">

<button id="close-member-panel" class="btn-close float-end"></button>

<img id="panel-profile" src="" class="rounded-circle mb-3" style="width:80px;height:80px;">

<h5 id="panel-username"></h5>

<p><strong data-translate="groups.emailLabel">Email:</strong>
<span id="panel-email"></span></p>

<p><strong data-translate="groups.aboutLabel">About Me:</strong>
<span id="panel-desc"></span></p>

</div>

<?php include 'Scripts.php'; ?>

<!-- FULL PAGE TRANSLATION ENGINE -->
<script>
const translations = {
  "groups.title": { en:"Group View", es:"Vista de Grupo", fr:"Vue du Groupe" },
  "groups.header": { en:"Group", es:"Grupo", fr:"Groupe" },
  "groups.sidebarBtn": { en:"Groups", es:"Grupos", fr:"Groupes" },
  "groups.membersBtn": { en:"View Members", es:"Ver Miembros", fr:"Voir les Membres" },
  "groups.messagesHeader": { en:"Messages", es:"Mensajes", fr:"Messages" },
  "groups.jumpBtn": { en:"Jump to Present", es:"Ir al Presente", fr:"Aller au Présent" },
  "groups.messagePH": { en:"Type a message...", es:"Escribe un mensaje...", fr:"Tapez un message..." },
  "groups.sendBtn": { en:"Send", es:"Enviar", fr:"Envoyer" },
  "groups.sidebarTitle": { en:"Your Groups", es:"Tus Grupos", fr:"Vos Groupes" },
  "groups.memberSidebarTitle": { en:"Members", es:"Miembros", fr:"Membres" },
  "groups.emailLabel": { en:"Email:", es:"Correo:", fr:"Email:" },
  "groups.aboutLabel": { en:"About Me:", es:"Sobre mí:", fr:"À propos de moi:" }
};

let lang = localStorage.getItem("language") || "en";

function translatePage() {
  document.querySelectorAll("[data-translate]").forEach(el => {
    const key = el.dataset.translate;
    if (translations[key] && translations[key][lang]) {
      el.textContent = translations[key][lang];
    }
  });

  document.querySelectorAll("[data-translate-placeholder]").forEach(el => {
    const key = el.dataset.translatePlaceholder;
    if (translations[key] && translations[key][lang]) {
      el.placeholder = translations[key][lang];
    }
  });
}

translatePage();
</script>

<!-- MESSAGE TRANSLATION POLLING (unchanged) -->
<script>
async function autoTranslate(text, lang) {
  if (!text || lang === "en") return text;

  const result = await fetch("start.php?action=Translate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, lang })
  });
  return (await result.json()).translatedText || text;
}

document.addEventListener("DOMContentLoaded", () => {
  const lang = localStorage.getItem("language") || "en";
  if (lang !== "en") {
    document.querySelectorAll("[data-dynamic-translate]").forEach(async el => {
      el.textContent = await autoTranslate(el.dataset.originalText, lang);
    });
  }
});
</script>

</body>
</html>
