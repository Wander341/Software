<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include './Styles/Stylesheet.php'; ?>

<style>
/* ============================================================
 *       ULTRA DARK MODE OVERRIDES
 *    ============================================================ */

html[data-bs-theme="dark"] body {
  background-color: #050505 !important;
  color: #e6e6e6 !important;
}

html[data-bs-theme="dark"] .bg-light {
  background-color: #121212 !important;
  color: #e6e6e6 !important;
}

html[data-bs-theme="dark"] .about-panel {
  background-color: #161616 !important;
  color: #e6e6e6 !important;
  border: 1px solid #333 !important;
}

html[data-bs-theme="dark"] #map-container {
  background-color: #0d0d0d !important;
  box-shadow: 0 0 10px rgba(0,0,0,0.8) !important;
}

html[data-bs-theme="dark"] #content {
  background-color: #050505 !important;
}

html[data-bs-theme="dark"] #Contact-Btn {
  background-color: #0066ff !important;
  color: white !important;
}
html[data-bs-theme="dark"] #Contact-Btn:hover {
  background-color: #0044cc !important;
}

/* ---------- Layout ---------- */
#content {
display: flex;
padding: 20px;
}

#map-container {
flex-grow: 1;
min-height: 50vh;
box-shadow: 2px 2px 10px rgba(0,0,0,0.3);
border-radius: 5px;
overflow: hidden;
margin-top: 20px;
}

#map { height: 100%; width: 100%; }

#bottom-button-container {
text-align: center;
padding: 30px 0 10px;
}

#Contact-Btn {
background-color: #007BFF;
color: white;
padding: 15px 30px;
font-size: 1.2em;
border-radius: 50px;
cursor: pointer;
}
#Contact-Btn:hover {
background-color: #0052cc;
}
</style>
</head>
<body>

<?php include 'Navbar.php'; ?>

<!-- ABOUT SECTION -->
<div class="px-4 py-5 my-5 text-center rounded shadow about-panel bg-light">

<h1 class="display-5 fw-bold" data-translate="home_title">About LockedIn</h1>

<div class="col-md-8 mx-auto my-4">
<p class="lead mb-0" data-translate="home_desc">
LockedIn is a social media web application created by UAFS Computer Science students,
for UAFS Computer Science students. It's designed to help students optimize their schedules
  and connect with their peers. With features like an interactive map for scheduling group
  sessions, task management tools for collaboration, and communication threads to socialize
  with other CS peers, LockedIn makes time management and social interaction easier.
  </p>
  </div>

  </div>

  <!-- MAP SECTION -->
  <div id="content">
  <div id="map-container">
  <div id="map"></div>
  </div>
  </div>

  <!-- CONTACT BUTTON -->
  <div id="bottom-button-container">
  <button id="Contact-Btn" data-translate="contact_btn">
  Contact us at: CompletelyRealEmail@uafs.edu
  </button>
  </div>

  <?php include 'Scripts.php'; ?>

  <script>
  /* ============================================================
   *                 LANGUAGE TRANSLATION ENGINE
   * ============================================================ */

  const translations = {

    home_title: {
      en: "About LockedIn",
      fr: "À propos de LockedIn",
      es: "Acerca de LockedIn"
    },

    home_desc: {
      en: "LockedIn is a social media web application created by UAFS Computer Science students, for UAFS Computer Science students. It's designed to help students optimize their schedules and connect with their peers. With features like an interactive map for scheduling group sessions, task management tools for collaboration, and communication threads to socialize with other CS peers, LockedIn makes time management and social interaction easier.",
      fr: "LockedIn est une application de médias sociaux créée par des étudiants en informatique de l'UAFS pour les étudiants en informatique de l'UAFS. Elle est conçue pour aider les étudiants à optimiser leurs horaires et à se connecter avec leurs pairs.",
      es: "LockedIn es una aplicación de redes sociales creada por estudiantes de informática de UAFS para estudiantes de informática de UAFS. Está diseñada para ayudar a los estudiantes a optimizar sus horarios y conectarse con sus compañeros."
    },

    contact_btn: {
      en: "Contact us at: CompletelyRealEmail@uafs.edu",
      fr: "Contactez-nous à : CompletelyRealEmail@uafs.edu",
      es: "Contáctenos en: CompletelyRealEmail@uafs.edu"
    }

  };

  // Load language set by Navbar
  let lang = localStorage.getItem("language") || "en";

  // Apply translation to page
  function translatePage() {
    document.querySelectorAll("[data-translate]").forEach(el => {
      let key = el.getAttribute("data-translate");
      if (translations[key] && translations[key][lang]) {
        el.textContent = translations[key][lang];
      }
    });
  }

  translatePage();

  /* ============================================================
   *                     LEAFLET MAP INITIALIZATION
   * ============================================================ */
  const imageWidth = 1388;
  const imageHeight = 938;
  const bounds = [[0, 0], [imageHeight, imageWidth]];

  const map = L.map('map', {
    crs: L.CRS.Simple,
    minZoom: -2,
    maxZoom: 2,
    zoom: 0,
    center: [imageHeight / 2, imageWidth / 2]
  });

  const imageUrl = './Images/uafsmap.png';
  const mapImage = L.imageOverlay(imageUrl, bounds).addTo(map);

  mapImage.on('error', function () {
    L.marker(map.getCenter()).addTo(map).bindPopup("Map failed to load.").openPopup();
  });

  map.fitBounds(bounds);

  </script>

  </body>
  </html>
