<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$text = $data["text"] ?? "";
$lang = $data["lang"] ?? "es";

// Public instance of LibreTranslate (free)
// You may replace with your own local instance
$url = "https://libretranslate.de/translate";

$params = [
    "q" => $text,
"source" => "en",
"target" => $lang,
"format" => "text"
];

$options = [
    "http" => [
        "header"  => "Content-type: application/json\r\n",
"method"  => "POST",
"content" => json_encode($params),
    ]
];

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);

echo $result;
