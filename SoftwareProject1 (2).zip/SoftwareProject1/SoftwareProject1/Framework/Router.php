<?php
// Removed session_start() to prevent duplicate session warnings
include_once "./Framework/Controller.php";

class Router {
    public $controllers;

    public function __construct() {
        $this->showErrors(0);
        $this->controllers = [];
    }

    public function run() {
        $action = "default";

        // Check if action was supplied in HTTP request
        if (isset($_REQUEST['action'])) {
            $action = $_REQUEST['action'];
        }

        // Authorization check — overridden in MyRouter (start.php)
        $this->authCheck($action);

        // Run the controller for this action
        if (!isset($this->controllers[$action])) {
            die("Error: Controller for action '$action' not found.");
        }

        $controller = $this->controllers[$action];
        $controller->performAction();
    }

    public function addController($action, $controller) {
        $this->controllers[$action] = $controller;
    }

    public function authCheck($action) {
        return;
    }

    public function showErrors($debug) {
        if ($debug == 1) {
            ini_set('display_errors', 1);
            ini_set('display_startup_errors', 1);
            error_reporting(E_ALL & ~E_NOTICE);
        } else {
            ini_set('display_errors', 0);
            error_reporting(0);
        }
    }
}
?>
