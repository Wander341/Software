<?php
include_once 'config.php';
class SendMessage {
    private function connectDB() {
        $host = DB_HOST;
        $user = DB_USER;
        $pass = DB_PASS;
        $dbname = DB_NAME;

        $conn = new mysqli($host, $user, $pass, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }

    public function sendMessage($userId, $threadId, $messageText) {
        $conn = $this->connectDB();
        $stmt = $conn->prepare("INSERT INTO MESSAGE (user_id, thread_id, message_text, time_sent) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $userId, $threadId, $messageText);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }


    public function sendGroupMessage($userId, $groupId, $messageText) {
        $conn = $this->connectDB();

        // Inserts the actual message
        $stmt = $conn->prepare(
            "INSERT INTO MESSAGE (user_id, group_id, message_text, time_sent)
            VALUES (?, ?, ?, NOW())"
        );
        $stmt->bind_param("iis", $userId, $groupId, $messageText);
        $stmt->execute();
        $stmt->close();

        //Gets group name
        $stmt = $conn->prepare("SELECT group_name FROM GROUPTABLE WHERE group_id = ?");
        $stmt->bind_param("i", $groupId);
        $stmt->execute();
        $result = $stmt->get_result();
        $groupName = $result->fetch_assoc()['group_name'];
        $stmt->close();

        $notifName = "You have new messages from " . $groupName;
        $notifType = "message";

        //Gets all group members
        $stmt = $conn->prepare("
            SELECT user_id 
            FROM GROUP_ASSIGNMENT
            WHERE group_id = ?
        ");
        $stmt->bind_param("i", $groupId);
        $stmt->execute();
        $members = $stmt->get_result();
        $stmt->close();

        // Sends notification
        $stmtNotif = $conn->prepare("
            INSERT INTO NOTIFICATION (notif_name, notif_type, time_sent)
            VALUES (?, ?, NOW())
        ");
        $stmtNotif->bind_param("ss", $notifName, $notifType);
        $stmtNotif->execute();

        $notifId = $stmtNotif->insert_id;
        $stmtNotif->close();

        //For each member, add notification if they don’t already have it
        while ($member = $members->fetch_assoc()) {
            $memberId = $member['user_id'];

            // Skip sender
            if ($memberId == $userId) {
                continue;
            }

            //Check if this user already has this notification
            $check = $conn->prepare("
                SELECT 1
                FROM NOTIFICATION n
                JOIN NOTIF_ASSIGNMENT a ON n.notif_id = a.notif_id
                WHERE n.notif_type = ?
                AND n.notif_name = ?
                AND a.user_id = ?
                LIMIT 1
            ");
            $check->bind_param("ssi", $notifType, $notifName, $memberId);
            $check->execute();
            $alreadyExists = $check->get_result()->num_rows > 0;
            $check->close();

            if ($alreadyExists) {
                continue;
            }

            $stmtAssign = $conn->prepare("
                INSERT INTO NOTIF_ASSIGNMENT (notif_id, user_id)
                VALUES (?, ?)
            ");
            $stmtAssign->bind_param("ii", $notifId, $memberId);
            $stmtAssign->execute();
            $stmtAssign->close();
        }

        $conn->close();
    }
    

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = isset($_SESSION['user']['user_ID']) ? intval($_SESSION['user']['user_ID']) : -1;
    $threadId = isset($_POST['thread_id']) ? intval($_POST['thread_id']) : 0;
    $groupId = isset($_POST['group_id']) ? intval($_POST['group_id']) : 0;
    $messageText = isset($_POST['message_text']) ? trim($_POST['message_text']) : '';

    if ($threadId && $messageText !== '') {
        $sender = new SendMessage();
        $sender->sendMessage($userId, $threadId, $messageText);
    }
    if ($groupId && $messageText !== '') {
        $sender = new SendMessage();
        $sender->sendGroupMessage($userId, $groupId, $messageText);
    }
}
?>
