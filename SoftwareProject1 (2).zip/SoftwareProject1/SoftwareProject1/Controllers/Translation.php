<?php
include_once __DIR__ . "/../Framework/Controller.php";

class Translation extends Controller {

    public function performAction() {
        header("Content-Type: application/json");

        // Read JSON input
        $input = json_decode(file_get_contents("php://input"), true);
        if (!$input || !isset($input['text']) || !isset($input['lang'])) {
            echo json_encode(["error" => "Invalid input"]);
            return;
        }

        $text = $input['text'];
        $lang = $input['lang'];

        // WORKING translation server
        $url = "https://translate.fedilab.app/translate";
        //$url = "http://libretranslate.de/translate";

        $payload = json_encode([
            "q" => $text,
            "source" => "auto",
            "target" => $lang,
            "format" => "text"
        ]);

        // Use file_get_contents with HTTPS
        $opts = [
            "http" => [
                "method"  => "POST",
                "header"  => "Content-Type: application/json",
                "content" => $payload,
                "ignore_errors" => true
            ]
        ];

        $context = stream_context_create($opts);
        $response = file_get_contents($url, false, $context);

        if ($response === FALSE) {
            echo json_encode([
                "error" => "Translation request failed",
                "details" => error_get_last()
            ]);
            return;
        }

        echo $response; // already valid JSON
    }

    public function getAuth() {
        return "PUBLIC";
    }
}
?>



