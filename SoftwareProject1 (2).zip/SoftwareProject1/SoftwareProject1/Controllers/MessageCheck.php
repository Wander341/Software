<?php
include_once "../Models/UserDAO.php";
include_once __DIR__ . '/../config.php';

// DB connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Inputs
$threadId      = intval($_GET['threadId'] ?? 0);
$groupId       = intval($_GET['groupId'] ?? 0);
$lastMessageId = intval($_GET['lastMessageId'] ?? 0);

// Language for translation
$lang = $_GET["lang"] ?? "en";

$userDAO = new UserDAO();
$currentUserId = $_SESSION['user']['user_ID'] ?? null;

// Select correct message source
if ($threadId !== 0) {
    $stmt = $conn->prepare("
    SELECT message_id, user_id, message_text, time_sent
    FROM MESSAGE
    WHERE thread_id = ? AND message_id > ?
    ORDER BY time_sent ASC
    ");
    $stmt->bind_param("ii", $threadId, $lastMessageId);
} else {
    $stmt = $conn->prepare("
    SELECT message_id, user_id, message_text, time_sent
    FROM MESSAGE
    WHERE group_id = ? AND message_id > ?
    ORDER BY time_sent ASC
    ");
    $stmt->bind_param("ii", $groupId, $lastMessageId);
}

$stmt->execute();
$result = $stmt->get_result();

// Output each new message
while ($row = $result->fetch_assoc()) {

    $user = $userDAO->getUser($row['user_id']);
    $username = $user ? htmlspecialchars($user->getUsername()) : "Unknown";

    // Convert timestamps to CST
    $dt = new DateTime($row['time_sent'], new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone('America/Chicago'));
    $formattedTime = $dt->format('M j, Y g:i A');

    // Style classes
    $isOwnMessage = ($row['user_id'] == $currentUserId);
    $bubbleClass = $isOwnMessage ? "bg-primary text-white" : "bg-light text-dark";
    $justifyClass = $isOwnMessage ? "justify-content-end" : "justify-content-start";
    $timestampClass = $isOwnMessage ? "text-dark" : "text-secondary";
    $textAlignClass = $isOwnMessage ? "text-end" : "";

    echo '<div class="d-flex ' . $justifyClass . ' mb-2" data-message-id="' . $row['message_id'] . '">';
    echo '<div class="p-2 rounded shadow-sm ' . $bubbleClass . '"
    style="max-width: 75%; width: fit-content; word-wrap: break-word;">';

    // Header row
    echo '<div class="d-flex mb-1">';
    if ($isOwnMessage) {
        echo '<span class="' . $timestampClass . ' small me-2">' . $formattedTime . '</span>';
        echo '<span class="fw-bold fs-6 ps-3">' . $username . '</span>';
    } else {
        echo '<span class="fw-bold fs-6 me-2">' . $username . '</span>';
        echo '<span class="' . $timestampClass . ' small">' . $formattedTime . '</span>';
    }
    echo '</div>';

    // MESSAGE TEXT (now supports dynamic translation)
    echo '<div class="fs-6 text-break ' . $textAlignClass . '"
    data-dynamic-translate
    data-original-text="' . htmlspecialchars($row['message_text']) . '">'
    . htmlspecialchars($row['message_text']) .
    '</div>';

    echo '</div>';
    echo '</div>';
}

$stmt->close();
$conn->close();
?>
