<?php
include_once "./Framework/Controller.php";
include_once "./Models/TaskDAO.php";
include_once "./Models/Task.php";

class TaskUpdateForm extends Controller
{
    public function performAction()
    {
        $taskDAO = new TaskDAO();

        if (!isset($_SESSION['user'])) {
            header("Location: start.php?action=Login");
            exit;
        }

        $user = $_SESSION['user'];
        $task_id = $_GET['task_id'] ?? $_POST['task_id'] ?? null;

        if (!$task_id) {
            echo "No task selected for update.";
            return;
        }

        //If form submitted, update the task 
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_task'])) {
            $taskDAO->updateTask($task_id, $_POST['task_name'], $_POST['task_desc'], $_POST['due_date'], $_POST['status']);
            header("Location: start.php?action=TaskView");
            exit;
        }

        //Otherwise, fetch task data for prefill 
        $task = $taskDAO->getTask($task_id);

        if (!$task) {
            echo "Task not found.";
            return;
        }

        //Render form with task data
        $this->renderView("TaskUpdateForm", ["task" => $task]);
    }
    public function renderView($view, $data = [])
    {
        include "./Views/$view.php";
    }

    public function getAuth()
    {
        return "PRIVATE";
    }
}
