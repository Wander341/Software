<?php
include_once "./Models/EventDAO.php";
include_once "./Models/MapNodeDAO.php";
include_once "./Models/MapNode.php";
include_once "./Models/Event.php";
include_once "./Framework/Controller.php";

class EventCreationForm extends Controller {

    public function performAction() {

        // -----------------------------
        // 1. HANDLE GET (Show the form)
        // -----------------------------
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {

            if (isset($_GET['node_id']) && $_GET['node_id'] !== "") {

                $nodeID = intval($_GET['node_id']);
                $mapNodeDAO = new MapNodeDAO();

                if ($nodeID === 0) {
                    // general event with no building
                    $locations = ["General Event"];
                } else {
                    // load building
                    $nodeData = $mapNodeDAO->getNode($nodeID);

                    if ($nodeData) {
                        $node = new MapNode();
                        $node->load($nodeData);
                        $locations = $node->getLocations();
                    } else {
                        header("Location: start.php?action=ExistingEvents");
                        exit;
                    }
                }

                // Render form
                $this->renderView("EventCreationForm", [
                    "node_id" => $nodeID,
                    "location" => $locations,
                    "error" => null
                ]);

                return;
            }
            else {
                // No node_id? Default to general event
                $this->renderView("EventCreationForm", [
                    "node_id" => 0,
                    "location" => ["General Event"],
                    "error" => null
                ]);
                return;
            }
        }

        // ------------------------------------
        // 2. HANDLE POST (Create an event)
        // ------------------------------------
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            if (
                isset($_POST['event_name']) &&
                isset($_POST['event_desc']) &&
                isset($_POST['event_date']) &&
                isset($_POST['start_time']) &&
                isset($_POST['end_time']) &&
                isset($_POST['node_id']) &&
                isset($_POST['location'])
            ) {
                $eventName = trim($_POST['event_name']);
                $eventDescription = trim($_POST['event_desc']);
                $eventDate = trim($_POST['event_date']);
                $startTime = trim($_POST['start_time']);
                $endTime = trim($_POST['end_time']);
                $nodeID = intval($_POST['node_id']);
                $location = trim($_POST['location']);
                $userID = $_SESSION['user']['user_ID'];

                $startDateTime = date('Y-m-d H:i:s', strtotime("$eventDate $startTime"));
                $endDateTime   = date('Y-m-d H:i:s', strtotime("$eventDate $endTime"));

                $eventDAO = new EventDAO();
                $eventID = $eventDAO->createEvent(
                    $eventName,
                    $eventDescription,
                    $startDateTime,
                    $endDateTime,
                    $nodeID,
                    $location,
                    $userID
                );

                // Check scheduling conflicts
                if ($eventID === "event_conflict" || $eventID === "class_conflict") {

                    $mapNodeDAO = new MapNodeDAO();
                    $nodeData = $mapNodeDAO->getNode($nodeID);

                    if ($nodeID === 0) {
                        $locations = ["General Event"];
                    } else {
                        $node = new MapNode();
                        $node->load($nodeData);
                        $locations = $node->getLocations();
                    }

                    $errorMessage = ($eventID === "class_conflict")
                    ? "A class is being held in that room during this time."
                    : "There is already an event scheduled at this location during that time.";

                    $this->renderView("EventCreationForm", [
                        "node_id" => $nodeID,
                        "location" => $locations,
                        "error" => $errorMessage
                    ]);
                    return;
                }

                // SUCCESS → return to ExistingEvents
                header("Location: start.php?action=ExistingEvents");
                exit;
            }

            // POST missing data → return
            header("Location: start.php?action=ExistingEvents");
            exit;
        }
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
