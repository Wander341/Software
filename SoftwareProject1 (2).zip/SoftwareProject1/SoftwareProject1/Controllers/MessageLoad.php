<?php
require_once 'Models/Message.php';
include_once 'config.php';

class MessageLoad {
    private function connectDB() {
        $host = DB_HOST;
        $user = DB_USER;
        $pass = DB_PASS;
        $dbname = DB_NAME;

        $conn = new mysqli($host, $user, $pass, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }

    public function loadMessagesByThreadId($threadId) {
        $conn = $this->connectDB();
        $stmt = $conn->prepare("SELECT * FROM MESSAGE WHERE thread_id = ? ORDER BY time_sent DESC LIMIT 50");
        $stmt->bind_param("i", $threadId);
        $stmt->execute();
        $result = $stmt->get_result();

        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = new Message($row);
        }

        $stmt->close();
        $conn->close();

        return array_reverse($messages); // oldest first
    }

    public function loadMessagesByGroupId($groupId) {
        $conn = $this->connectDB();
        $stmt = $conn->prepare("SELECT * FROM MESSAGE WHERE group_id = ? ORDER BY time_sent DESC LIMIT 50");
        $stmt->bind_param("i", $groupId);
        $stmt->execute();
        $result = $stmt->get_result();

        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = new Message($row);
        }

        $stmt->close();
        $conn->close();

        return array_reverse($messages); // oldest first
    }
}

// Only run this block if the file is accessed directly
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    header('Content-Type: application/json');

    if (!isset($_GET['thread_id']) || !is_numeric($_GET['thread_id'])) {
        echo json_encode(['error' => 'Missing or invalid thread_id']);
        exit;
    }
    $threadId = intval($_GET['thread_id']);
    if($threadId != 0) {
        $loader = new MessageLoad();
        $messages = $loader->loadMessagesByThreadId($threadId);

        echo json_encode($messages);
    }else {
        $groupId = intval($_GET['group_id']);
        $loader = new MessageLoad();
        $messages = $loader->loadMessagesByGroupId($groupId);

        echo json_encode($messages);
    }
}
?>
