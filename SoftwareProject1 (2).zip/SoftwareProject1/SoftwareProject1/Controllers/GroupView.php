<?php
ob_start();
include_once "./Framework/Controller.php";
require_once './Models/Group.php';
require_once './Controllers/MessageLoad.php';
require_once './Models/NotificationDAO.php';   // <-- ADD THIS

class GroupView extends Controller {

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function performAction() {
        if (!isset($_SESSION['user'])) {
            header("Location: start.php?action=Login");
            exit;
        }

        $userData = $_SESSION['user'];
        $userID = $userData['user_ID'];

        $groupModel = new Group();
        $groups = $groupModel->getUserGroups($userID);

        // The selected group ID from POST, GET, or default to first group
        $selectedGroupId = $_POST['selected_group'] ?? $_GET['group_id'] ?? null;

        if (!$selectedGroupId && count($groups) > 0) {
            $selectedGroupId = $groups[0]->getGroupID();
        }

        $selectedGroupName = "No groups yet";

        if ($selectedGroupId) {
            foreach ($groups as $g) {
                if ($g->getGroupID() == $selectedGroupId) {
                    $selectedGroupName = $g->getGroupName();
                    break;
                }
            }

            // ------------------------------------------
            // DELETE MESSAGE NOTIFICATION FOR THIS GROUP
            // ------------------------------------------
            $notifDAO = new NotificationDAO();
            $notifDAO->deleteGroupMessageNotification($userID, $selectedGroupName);
        }

        // Load members for selected group
        $members = [];
        if ($selectedGroupId) {
            $members = $groupModel->getGroupMembers($selectedGroupId);
        }

        // Render the main view
        $this->renderView("GroupView", [
            'groups' => $groups,
            'selectedGroupId' => $selectedGroupId,
            'selectedGroupName' => $selectedGroupName,
            'members' => $members
        ]);

        ob_end_flush();
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>