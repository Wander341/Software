<?php
ob_start();
include_once "./Framework/Controller.php";
require_once './Models/Thread.php';

    class ThreadView extends Controller {

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }
    public function performAction(){
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['thread_name'])) {
            $thread = new Thread();
            $thread->setThreadName(trim($_POST['thread_name']));
            $thread->createThread($thread);
            header("Location: start.php?action=ThreadView");
            ob_end_flush();
        }
        $this->renderView("ThreadView");
        }
        public function getAuth() {
        return "PRIVATE";
    }
    }
    
?>