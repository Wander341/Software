<?php
include_once "./Framework/Controller.php";
include_once "./Models/User.php";
include_once "./Models/UserDAO.php";

class ModeratorView extends Controller
{

    public function performAction()
    {

        $userData = $_SESSION['user'] ?? null;
        $userDAO = new UserDAO();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_action']) && isset($_POST['user_ID'])) {
            $action = $_POST['user_action'];
            $userID = intval($_POST['user_ID']);

            if ($action === 'ban') {
                $userDAO->banUser($userID);
            } else if ($action === 'unban') {
                $userDAO->unbanUser($userID);
            } else if ($action === 'change_access') {
                $userDAO->changeAccessLevel($userID);
                $userAccess = $_SESSION['user']['accessLvl'];
                if ($userAccess == "user") {
                    $_SESSION['user']['accessLvl'] = "moderator";
                } else if ($userAccess == "moderator") {
                    $_SESSION['user']['accessLvl'] = "user";
                }
            }

            $this->renderView("ModeratorView");
            exit;
        }

        //GET request: just render the page
        $this->renderView("ModeratorView");
    }

    public function getAuth()
    {
        return "PRIVATE";
    }

    public function renderView($view, $data = [])
    {
        include "./Views/$view.php";
    }
}
?>