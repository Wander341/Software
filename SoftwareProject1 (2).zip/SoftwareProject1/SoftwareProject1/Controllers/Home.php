<?php
class Home extends Controller {

    public function performAction() {
        $this->renderView("Home");
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PUBLIC";
    }
}
