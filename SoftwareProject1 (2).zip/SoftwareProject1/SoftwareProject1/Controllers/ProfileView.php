<?php
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Framework/Controller.php";

class ProfileView extends Controller {

    public function performAction() {
        $dao = new UserDAO();

        if (!isset($_SESSION['user'])) {
            header("Location: start.php?action=Login");
            exit;
        }

        $userID = $_SESSION['user']['user_ID'];
        $userData = $dao->getUser($userID);

        $error = "";
        $success = "";

        /* -------------------------------------------
         * PROFILE PICTURE UPDATE
         * ------------------------------------------- */
        if ($_SERVER["REQUEST_METHOD"] === "POST" &&
            isset($_FILES["profilepic"]) &&
            $_FILES["profilepic"]["error"] !== UPLOAD_ERR_NO_FILE) {

            $uploadDir = "./Images/profile_pics/";
        if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

        $tmp = $_FILES["profilepic"]["tmp_name"];
            $name = basename($_FILES["profilepic"]["name"]);
            $target = $uploadDir . time() . "_" . $name;

            $ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
            $allowed = ["jpg", "jpeg", "png", "gif"];

            if (in_array($ext, $allowed)) {
                if (move_uploaded_file($tmp, $target)) {
                    $dao->updateProfilePicture($userID, $target);
                    $success = "Profile picture updated!";
                    $userData = $dao->getUser($userID);
                } else {
                    $error = "Failed to upload file.";
                }
            } else {
                $error = "Invalid file type.";
            }
            }

            /* -------------------------------------------
             * BIO UPDATE
             * ------------------------------------------- */
            if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["updateDesc"])) {
                $newDesc = trim($_POST["userDesc"]);
                $dao->updateDescription($userID, $newDesc);
                $success = "Bio updated!";
                $userData = $dao->getUser($userID);
            }

            /* -------------------------------------------
             * BIRTHDAY UPDATE
             * ------------------------------------------- */
            if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["updateBirthday"])) {
                $birthday = $_POST["birthday"];

                if (!empty($birthday)) {
                    $dao->updateBirthday($userID, $birthday);
                    $success = "Birthday updated!";
                    $userData = $dao->getUser($userID);
                }
            }

            /* -------------------------------------------
             * REQUEST MODERATOR ACCESS
             * ------------------------------------------- */
            if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["requestModAccess"])) {

                $username = $userData->getUsername();
                $uid = $userData->getUserID();

                $message = "Moderator Access Request from: $username (#$uid)";

                $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

                // Insert notification
                $stmt = $conn->prepare("
                INSERT INTO NOTIFICATION (notif_name, notif_type, time_sent)
                VALUES (?, 'mod_request', NOW())
                ");
                $stmt->bind_param("s", $message);
                $stmt->execute();
                $notifID = $stmt->insert_id;
                $stmt->close();

                // Send to all moderators
                $mods = $conn->prepare("SELECT user_ID FROM USER WHERE accessLvl = 'moderator'");
                $mods->execute();
                $result = $mods->get_result();

                $assign = $conn->prepare("
                INSERT INTO NOTIF_ASSIGNMENT (notif_id, user_id)
                VALUES (?, ?)
                ");

                while ($row = $result->fetch_assoc()) {
                    $modID = $row["user_ID"];
                    $assign->bind_param("ii", $notifID, $modID);
                    $assign->execute();
                }

                $assign->close();
                $mods->close();
                $conn->close();

                $success = "Your moderator access request has been sent!";
            }

            $this->renderView("ProfileView", [
                "user" => $userData,
                "error" => $error,
                "success" => $success
            ]);
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
