#!/bin/bash
docker run -d \
  -p 6767:80 \
  -v /home/user/Desktop/SoftwareProject1/SoftwareProject1:/var/www/html \
  --name apachecontainer \
  apacheimage
