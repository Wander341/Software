<?php
    include_once "./Framework/Controller.php";
    include_once "./Framework/Router.php";
    include_once "./Controllers/EventCreationForm.php";
    include_once "./Controllers/MapView.php";
    include_once "./Controllers/Home.php";
    include_once "./Controllers/Login.php";
    include_once "./Controllers/CreateAccount.php";
    include_once "./Controllers/ExistingEvents.php";
    include_once "./Controllers/RSVPView.php";
    include_once "./Controllers/ProfileView.php";
    include_once "./Controllers/Logout.php";
    include_once "./Controllers/FriendRequest.php";
    include_once "./Controllers/ThreadView.php";
    include_once "./Controllers/SendMessage.php";
    include_once "./Controllers/MessageLoad.php";
    include_once "./Controllers/ThreadReload.php";
    include_once "./Controllers/GroupView.php";
    include_once "./Controllers/GroupReload.php";
    include_once "./Controllers/GroupCreationForm.php";
    include_once "./Controllers/TaskView.php";
    include_once "./Controllers/GroupCreationForm.php";
    include_once "./Controllers/TaskCreationForm.php";
    include_once "./Controllers/CalendarView.php";
    include_once "./Controllers/TaskUpdateForm.php";
    include_once "./Controllers/ModeratorView.php";

    class MyRouter extends Router{
        public function authCheck($action){
            $controller = $this->controllers[$action];
            $access = $controller->getAuth();
            if($access!="PUBLIC"){
                if(!isset($_SESSION['user'])){
                    header("Location: start.php?action=Login");
                    exit;
                }
            }
        }
    }
$router = new MyRouter();
    $router->showErrors(0);

    $router->addController('EventCreationForm',new EventCreationForm());
    $router->addController('MapView', new MapView());
    $router->addController('Home', new Home());
    $router->addController('Login', new Login());
    $router->addController('CreateAccount', new CreateAccount());
    $router->addController('ExistingEvents', new ExistingEvents());
    $router->addController('RSVPView', new RSVPView());
    $router->addController('ProfileView', new ProfileView());
    $router->addController('Logout', new Logout());
    $router->addController('FriendRequest', new FriendRequest());
    $router->addController('ThreadView', new ThreadView());
    $router->addController('SendMessage', new SendMessage());
    $router->addController('MessageLoad', new MessageLoad());
    $router->addController('ThreadReload', new ThreadReload());
    $router->addController('GroupView', new GroupView());
    $router->addController('GroupReload', new GroupReload());
    $router->addController('TaskView',new TaskView());
    $router->addController('GroupCreationForm',new GroupCreationForm());
    $router->addController('TaskCreationForm',new TaskCreationForm());
    $router->addController('CalendarView',new CalendarView());
    $router->addController('TaskUpdateForm',new TaskUpdateForm());
    $router->addController('ModeratorView',new ModeratorView());


    $router->run();

?>
