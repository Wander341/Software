<?php
include_once 'config.php';
class MessageDAO {
   
    public function getConnection(): ?mysqli {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            return null;
        }
        return $mysqli;
    }
    private function connect(): ?mysqli {
        return $this->getConnection();
    }

    public function addMessage(int $userID, string $messageText): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("INSERT INTO MESSAGE (user_id, message_text, time_sent, is_pinned) VALUES (?, ?, NOW(), 0)");
        $stmt->bind_param("is", $userID, $messageText);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function viewMessage(int $messageID): ?array {
        $conn = $this->connect();
        if (!$conn) return null;

        $stmt = $conn->prepare("SELECT * FROM MESSAGE WHERE message_id = ?");
        $stmt->bind_param("i", $messageID);
        $stmt->execute();
        $result = $stmt->get_result();
        $message = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $message ?: null;
    }

    public function viewRecentMessages(int $count): array {
        $conn = $this->connect();
        if (!$conn) return [];

        $stmt = $conn->prepare("SELECT * FROM MESSAGE ORDER BY time_sent DESC LIMIT ?");
        $stmt->bind_param("i", $count);
        $stmt->execute();
        $result = $stmt->get_result();
        $MESSAGE = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $conn->close();
        return $MESSAGE;
    }

    public function updateMessage(int $messageID, string $newText): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("UPDATE MESSAGE SET message_text = ? WHERE message_id = ?");
        $stmt->bind_param("si", $newText, $messageID);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function deleteMessage(int $messageID): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("UPDATE MESSAGE SET visible = 0 WHERE message_id = ?");
        $stmt->bind_param("i", $messageID);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function restoreMessage(int $messageID): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("UPDATE MESSAGE SET visible = 1 WHERE message_id = ?");
        $stmt->bind_param("i", $messageID);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }
}
?>