<?php
include_once "Event.php";
include_once __DIR__ . "/../config.php";

class EventDAO {

    private function getConnection() {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        return $mysqli->connect_errno ? null : $mysqli;
    }

    /* ----------------------------------------------------------
     * CREATE EVENT
     * ---------------------------------------------------------- */
    public function createEvent($eventName, $eventDescription, $startTime, $endTime, $nodeID, $location, $creatorID) {
        $conn = $this->getConnection();
        if ($conn === null) return false;

        // RSVP JSON always starts with creator
        $rsvpJSON = json_encode([$creatorID]);

        $stmt = $conn->prepare("
        INSERT INTO EVENT (event_name, event_desc, start_time, end_time, location, rsvp)
        VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param("ssssss",
                          $eventName,
                          $eventDescription,
                          $startTime,
                          $endTime,
                          $location,
                          $rsvpJSON
        );

        if (!$stmt->execute()) {
            return false;
        }

        $eventID = $stmt->insert_id;

        // Assign to location (node)
        $stmtAssign = $conn->prepare("INSERT INTO NODE_ASSIGNMENT (node_id, event_id) VALUES (?, ?)");
        $stmtAssign->bind_param("ii", $nodeID, $eventID);
        $stmtAssign->execute();

        return true;
    }

    /* ----------------------------------------------------------
     * CLEANUP PAST EVENTS
     * ---------------------------------------------------------- */
    public function eventCleanup() {
        $conn = $this->getConnection();
        if ($conn === null) return false;

        $pastEvents = $conn->query("SELECT event_id FROM EVENT WHERE end_time < NOW()");
        while ($row = $pastEvents->fetch_assoc()) {
            $this->deleteEventCompletely($row["event_id"]);
        }
    }

    /* ----------------------------------------------------------
     * GET EVENT
     * ---------------------------------------------------------- */
    public function getEvent($eventID) {
        $conn = $this->getConnection();
        if ($conn === null) return null;

        $stmt = $conn->prepare("SELECT * FROM EVENT WHERE event_id = ?");
        $stmt->bind_param("i", $eventID);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    /* ----------------------------------------------------------
     * GET ALL EVENTS
     * ---------------------------------------------------------- */
    public function getAllEvents() {
        $conn = $this->getConnection();
        $result = $conn->query("SELECT * FROM EVENT ORDER BY start_time ASC");

        $events = [];
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
        return $events;
    }

    /* ----------------------------------------------------------
     * GET NODE ID FOR EVENT
     * ---------------------------------------------------------- */
    public function getNodeIDForEvent($eventID) {
        $conn = $this->getConnection();
        $stmt = $conn->prepare("SELECT node_id FROM NODE_ASSIGNMENT WHERE event_id = ?");
        $stmt->bind_param("i", $eventID);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();

        return $res["node_id"] ?? 0;
    }

    /* ----------------------------------------------------------
     * UPDATE RSVP JSON
     * ---------------------------------------------------------- */
    public function updateEventRSVP($eventID, $rsvpJSON) {
        $conn = $this->getConnection();
        $stmt = $conn->prepare("UPDATE EVENT SET rsvp = ? WHERE event_id = ?");
        $stmt->bind_param("si", $rsvpJSON, $eventID);
        $stmt->execute();
    }

    /* ----------------------------------------------------------
     * DELETE EVENT (CREATOR/MODERATOR ONLY)
     * ---------------------------------------------------------- */
    public function deleteEventIfAllowed($eventID, $currentUserID, $isModerator) {
        $event = $this->getEvent($eventID);
        if (!$event) return false;

        $rsvp = json_decode($event["rsvp"], true);
        $creatorID = $rsvp[0] ?? null;

        // Deny deletion if user is not moderator AND not creator
        if (!$isModerator && $creatorID != $currentUserID) {
            return false;
        }

        return $this->deleteEventCompletely($eventID);
    }

    /* ----------------------------------------------------------
     * DELETE EVENT COMPLETELY
     * ---------------------------------------------------------- */
    public function deleteEventCompletely($eventID) {
        $conn = $this->getConnection();
        if ($conn === null) return false;

        // Delete node assignment
        $stmtNA = $conn->prepare("DELETE FROM NODE_ASSIGNMENT WHERE event_id = ?");
        $stmtNA->bind_param("i", $eventID);
        $stmtNA->execute();

        // Delete event
        $stmtE = $conn->prepare("DELETE FROM EVENT WHERE event_id = ?");
        $stmtE->bind_param("i", $eventID);
        $stmtE->execute();

        return true;
    }
}
?>
