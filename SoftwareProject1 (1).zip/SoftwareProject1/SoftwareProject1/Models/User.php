<?php
class User implements JsonSerializable {

    private $userID;
    private $username;
    private $email;
    private $password;
    private $accessLevel;
    private $description;
    private $uafsID;
    private $profile_pic;

    // NEW FIELD
    private $birthday;

    public function load($row) {
        $this->setUserID($row['user_ID']);
        $this->setUsername($row['username']);
        $this->setEmail($row["email"]);
        $this->setPassword($row["password"]);
        $this->setAccessLevel($row['accessLvl']);
        $this->setDescription($row['userDesc']);
        $this->setUafsID($row['uafs_id']);
        $this->setProfilePic($row['profile_pic']);

        // NEW — ensure birthday loads even if NULL
        $this->setBirthday($row['birthday'] ?? '');
    }

    // ----------------------------
    // GETTERS / SETTERS
    // ----------------------------

    public function setUserID($userID) { $this->userID = $userID; }
    public function getUserID() { return $this->userID; }

    public function setUsername($username) { $this->username = $username; }
    public function getUsername() { return $this->username; }

    public function setEmail($email) { $this->email = $email; }
    public function getEmail() { return $this->email; }

    public function setPassword($password) { $this->password = $password; }
    public function getPassword() { return $this->password; }

    public function setAccessLevel($accessLevel) { $this->accessLevel = $accessLevel; }
    public function getAccessLevel() { return $this->accessLevel; }

    public function setDescription($description) { $this->description = $description; }
    public function getDescription() { return $this->description; }

    public function setUafsID($uafsID) { $this->uafsID = $uafsID; }
    public function getUafsID() { return $this->uafsID; }

    public function setProfilePic($profile_pic) {
        $this->profile_pic = $profile_pic;
    }
    public function getProfilePic() {
        return !empty($this->profile_pic) ? $this->profile_pic : './Images/default_profile.png';
    }

    // ----------------------------
    // NEW BIRTHDAY SUPPORT
    // ----------------------------

    public function setBirthday($birthday) {
        $this->birthday = $birthday;
    }

    public function getBirthday() {
        return $this->birthday;
    }

    // ----------------------------
    // JSON SERIALIZATION
    // ----------------------------
    public function jsonSerialize(): mixed {
        return [
            'user_ID'     => $this->userID,
            'username'    => $this->username,
            'email'       => $this->email,
            'password'    => $this->password,
            'accessLvl'   => $this->accessLevel,
            'userDesc'    => $this->description,
            'uafs_id'     => $this->uafsID,
            'profile_pic' => $this->profile_pic,

            // NEW
            'birthday'    => $this->birthday
        ];
    }

}
?>
