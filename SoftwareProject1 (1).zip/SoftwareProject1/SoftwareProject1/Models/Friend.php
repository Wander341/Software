<?php
class Friend implements JsonSerializable {
    private $userID;
    private $friendID;
    private $status;

    public function load($row) {
        $this->setUserID($row['user_id']);
        $this->setFriendID($row['friend_id']);
        $this->setStatus($row['status']);
    }

    public function setUserID($userID) {
        $this->userID = $userID;
    }

    public function getUserID() {
        return $this->userID;
    }

    public function setFriendID($friendID) {
        $this->friendID = $friendID;
    }

    public function getFriendID() {
        return $this->friendID;
    }

    public function setStatus($status) {
        $this->status = $status;
    }

    public function getStatus() {
        return $this->status;
    }

    public function jsonSerialize(): mixed {
        return array(
            'user_id' => $this->userID,
            'friend_id' => $this->friendID,
            'status' => $this->status
        );
    }
}
?>