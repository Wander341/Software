<?php
include_once 'Notification.php';
include_once __DIR__ . '/../config.php';
class NotificationDAO {

    public function getConnection(){
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            $mysqli = null;
        }
        return $mysqli;
    }

    public function getNotifications($userID) {
        $connection = $this->getConnection();
        if (!$connection) return [];

        $stmt = $connection->prepare("
            SELECT n.notif_id, n.notif_name, n.notif_type,
                DATE_FORMAT(n.time_sent, '%Y-%m-%d %H:%i:%s') AS time_sent
            FROM NOTIFICATION n
            INNER JOIN NOTIF_ASSIGNMENT na ON n.notif_id = na.notif_id
            WHERE na.user_id = ?
            ORDER BY n.time_sent DESC
        ");

        $stmt->bind_param("i", $userID);
        $stmt->execute();

        $result = $stmt->get_result();
        $notifications = [];

        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }

        $stmt->close();
        $connection->close();

        return $notifications;
    }

    public function clearNotifications($userID) {
        $connection = $this->getConnection();
        if (!$connection) return;

        $stmt = $connection->prepare("
            DELETE FROM NOTIF_ASSIGNMENT
            WHERE user_id = ?
        ");

        $stmt->bind_param("i", $userID);
        $stmt->execute();

        $stmt->close();
        $connection->close();
    }

    public function deleteGroupMessageNotification($userID, $groupName) {
        $connection = $this->getConnection();
        if (!$connection) return;

        $notifName = "you have new messages from " . $groupName;

        // Delete from NOTIF_ASSIGNMENT
        $stmt = $connection->prepare("
            DELETE na
            FROM NOTIF_ASSIGNMENT na
            JOIN NOTIFICATION n ON na.notif_id = n.notif_id
            WHERE na.user_id = ?
            AND n.notif_type = 'message'
            AND n.notif_name = ?
        ");
        $stmt->bind_param("is", $userID, $notifName);
        $stmt->execute();
        $stmt->close();

        $connection->close();
    }

    public function createNotification($notifName, $type, $userIDs = []) {
        if (empty($userIDs)) return null;

        $connection = $this->getConnection();
        if (!$connection) return null;

        //Insert into NOTIFICATION
        $stmt1 = $connection->prepare("
            INSERT INTO NOTIFICATION (notif_name, notif_type, time_sent)
            VALUES (?, ?, NOW())
        ");
        $stmt1->bind_param("ss", $notifName, $type);
        $stmt1->execute();

        $notifID = $stmt1->insert_id;
        $stmt1->close();

        //Assign to users
        $stmt2 = $connection->prepare("
            INSERT INTO NOTIF_ASSIGNMENT (notif_id, user_id)
            VALUES (?, ?)
        ");

        foreach ($userIDs as $uid) {
            $stmt2->bind_param("ii", $notifID, $uid);
            $stmt2->execute();
        }

        $stmt2->close();
        $connection->close();

        return $notifID;
    }
}
?>