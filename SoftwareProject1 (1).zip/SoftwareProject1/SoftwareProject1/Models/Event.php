<?php
class Event implements JsonSerializable {
    private $eventID;
    private $eventName;
    private $eventDescription;
    private $startTime;
    private $endTime;
    private $rsvp = [];
    private $location;

    public function load($row) {
        $this->setEventID($row['event_id'] ?? null);
        $this->setEventName($row['event_name'] ?? null);
        $this->setEventDescription($row['event_desc'] ?? null);
        $this->setStartTime($row['start_time'] ?? null);
        $this->setEndTime($row['end_time'] ?? null);
        $this->setRsvp($row['rsvp'] ?? []);
        $this->setLocation($row['location'] ?? null);
    }

    public function setEventID($eventID) {
        $this->eventID = $eventID;
    }

    public function getEventID() {
        return $this->eventID;
    }

    public function setEventName($eventName) {
        $this->eventName = $eventName;
    }

    public function getEventName() {
        return $this->eventName;
    }

    public function setEventDescription($eventDescription) {
        $this->eventDescription = $eventDescription;
    }

    public function getEventDescription() {
        return $this->eventDescription;
    }

    public function setStartTime($startTime) {
        $this->startTime = $startTime;
    }

    public function getStartTime() {
        return $this->startTime;
    }

    public function setEndTime($endTime) {
        $this->endTime = $endTime;
    }

    public function getEndTime() {
        return $this->endTime;
    }

public function setRsvp($rsvp) {
    if (is_string($rsvp)) {
        $decoded = json_decode($rsvp, true);
        $this->rsvp = is_array($decoded) ? $decoded : [];
    } elseif (is_array($rsvp)) {
        $this->rsvp = $rsvp;
    } else {
        $this->rsvp = [];
    }
}


    public function getRsvp() {
        return $this->rsvp;
    }

    public function setLocation($location) {
        $this->location = $location;
    }

    public function getLocation() {
        return $this->location;
    }

    public function addRsvp($value) {
        $this->rsvp[] = $value;
    }

    public function rsvpDelete($index) {
        if (isset($this->rsvp[$index])) {
            unset($this->rsvp[$index]);
            $this->rsvp = array_values($this->rsvp);
            return true;
        }
        return false;
    }

    public function rsvpSearch($user) {
        $index = array_search($user, $this->rsvp, true);
        return ($index !== false) ? $index : -1;
    }

    public function jsonSerialize(): mixed {
        return [
            'event_id'   => $this->eventID,
            'event_name' => $this->eventName,
            'event_desc' => $this->eventDescription,
            'start_time' => $this->startTime,
            'end_time'   => $this->endTime,
            'rsvp'       => $this->rsvp,
            'location'   => $this->location
        ];
    }
}
?>