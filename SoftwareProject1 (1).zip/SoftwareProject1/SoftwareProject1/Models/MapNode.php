<?php
class MapNode implements JsonSerializable {
    private $nodeID;
    private $nodeName;
    private $locations;
    private $x;
    private $y;

    public function load($row) {
        $this->setNodeID($row['node_id']);
        $this->setNodeName($row['node_name']);
        $this->setLocations($row['location'] ?? []);
        $this->setX($row['x']);
        $this->setY($row['y']);
    }

    public function setNodeID($nodeID) {
        $this->nodeID = $nodeID;
    }

    public function setNodeName($nodeName) {
        $this->nodeName = $nodeName;
    }

    public function setLocations($locations) {
        if (is_string($locations) && !empty($locations)) {
            $locations_array = explode(',', $locations);
            $this->locations = array_map('trim', $locations_array);
        } elseif (is_array($locations)) {
            $this->locations = $locations;
        } else {
            $this->locations = [];
        }
    }
    public function setX($x) {
        $this->x = $x;
    }

    public function setY($y) {
        $this->y = $y;
    }

    public function getNodeID() {
        return $this->nodeID;
    }

    public function getNodeName() {
        return $this->nodeName;
    }

    public function getLocations() {
        return $this->locations;
    }

    public function getX() {
        return $this->x;
    }

    public function getY() {
        return $this->y;
    }



    public function jsonSerialize(): mixed {
        return array(
            'node_id' => $this->nodeID,
            'node_name' => $this->nodeName,
            'location' => $this->locations,
            'x' => $this->x,
            'y' => $this->y
        );
    }
}
?>