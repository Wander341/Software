<?php
include_once 'MapNode.php';
include_once 'config.php';
class MapNodeDAO {

    public function getConnection() {
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            $mysqli = null;
        }
        return $mysqli;
    }

    public function addNode($nodeName, $locations = []) {
        $connection = $this->getConnection();
        $locationsString = implode(',', $locations);
        $stmt = $connection->prepare("INSERT INTO NODE (node_name, location) VALUES (?, ?)");
        $stmt->bind_param("ss", $nodeName, $locationsString);
        $stmt->execute();
        $nodeID = $stmt->insert_id;
        $stmt->close();
        return $nodeID;
    }

    public function getAllNodes() {
        $connection = $this->getConnection();
        $result = $connection->query("SELECT * FROM NODE");
        $nodes = [];
        while ($row = $result->fetch_assoc()) {
            if (isset($row['location']) && !empty($row['location'])) {
                $row['location'] = explode(',', $row['location']);
            } else {
                $row['location'] = [];
            }

            $node = new MapNode();
            $node->load($row);
            $nodes[] = $node;
        }
        return $nodes;
    }

    public function getNode($nodeID) {
        $connection = $this->getConnection();
        $stmt = $connection->prepare("SELECT * FROM NODE WHERE node_id = ?");
        $stmt->bind_param("i", $nodeID);
        $stmt->execute();
        $result = $stmt->get_result();
        $node = $result->fetch_assoc();
        $stmt->close();
        if (isset($node['location']) && !empty($node['location'])) {
            $node['location'] = explode(',', $node['location']);
        } else {
            $node['location'] = [];
        }

        return $node;
    }

    public function updateNode($nodeID, $nodeName, $locations = []) {
        $connection = $this->getConnection();
        $locationsString = implode(',', $locations);
        $stmt = $connection->prepare("UPDATE NODE SET node_name = ?, location = ? WHERE node_id = ?");
        $stmt->bind_param("ssi", $nodeName, $locationsString, $nodeID);
        $stmt->execute();
        $stmt->close();
    }

    public function deleteNode($nodeID) {
        $connection = $this->getConnection();

        $stmt = $connection->prepare("DELETE FROM NODE WHERE node_id = ?");
        $stmt->bind_param("i", $nodeID);
        $stmt->execute();
        $stmt->close();
    }
}
?>