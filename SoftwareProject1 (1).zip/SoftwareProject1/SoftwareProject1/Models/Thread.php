<?php
include_once 'Group.php';
include_once 'config.php';
class Thread extends Group {
    private $threadID;
    private $threadName;

    public function load($row) {
        parent::load($row);
        $this->setThreadID($row['thread_id'] ?? null);
        $this->setThreadName($row['thread_name'] ?? null);
    }

    public function setThreadID($threadID) {
        $this->threadID = $threadID;
    }

    public function getThreadID() {
        return $this->threadID;
    }

    public function setThreadName($threadName) {
        $this->threadName = $threadName;
    }

    public function getThreadName() {
        return $this->threadName;
    }

    public function jsonSerialize(): mixed {
        $parentData = parent::jsonSerialize();
        $parentData['thread_id'] = $this->threadID;
        $parentData['thread_name'] = $this->threadName;
        return $parentData;
    }

    public function createThread(Thread $thread) {
        $conn = $this->connectDB();
        $sql = "INSERT INTO THREAD (message_id, thread_name) VALUES (NULL, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $thread->threadName);
            if ($stmt->execute()) {
                echo "Thread created successfully!";
            } else {
                echo "Execution failed: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Preparation failed: " . $conn->error;
        }
        $conn->close();
    }

    public function getAllThreads() {
        $conn = $this->connectDB();
        $threads = [];

        $sql = "SELECT thread_id, thread_name FROM THREAD";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $iterator = 0;
            while ($row = $result->fetch_assoc()) {
                $t = new Thread();
                $t->setThreadID($row['thread_id']);
                $t->setThreadName($row['thread_name']);
                $threads[$iterator] = $t;
                $iterator++;
            }
        }

        $conn->close();
        return $threads;
    }

        private function connectDB() {
            $host = DB_HOST;
            $user = DB_USER;
            $pass = DB_PASS;
            $dbname = DB_NAME;

            $conn = new mysqli($host, $user, $pass, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            return $conn;
    }

    }
?>