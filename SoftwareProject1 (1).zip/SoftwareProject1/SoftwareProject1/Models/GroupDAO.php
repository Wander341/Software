<?php
include_once 'config.php';
class GroupDAO {
    
    public function getConnection(){
        $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($mysqli->connect_errno) {
            $mysqli=null;
        }
        return $mysqli;
    }
    private function connect(): ?mysqli {
        return $this->getConnection();
    }

    public function getAllGROUP_TABLE(): array {
        $conn = $this->connect();
        if (!$conn) return [];

        $result = $conn->query("SELECT * FROM GROUPTABLE");
        $GROUP_TABLE = $result->fetch_all(MYSQLI_ASSOC);
        $conn->close();
        return $GROUP_TABLE;
    }

    public function getGroup(int $groupID): ?array {
        $conn = $this->connect();
        if (!$conn) return null;

        $stmt = $conn->prepare("SELECT * FROM GROUPTABLE WHERE group_id = ?");
        $stmt->bind_param("i", $groupID);
        $stmt->execute();
        $result = $stmt->get_result();
        $group = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $group ?: null;
    }

    public function addGroup(string $groupName): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("INSERT INTO GROUPTABLE (group_name) VALUES (?)");
        $stmt->bind_param("s", $groupName);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function deleteGroup(int $groupID): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("DELETE FROM GROUPTABLE WHERE group_id = ?");
        $stmt->bind_param("i", $groupID);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function getUser(int $userID): ?array {
        $conn = $this->connect();
        if (!$conn) return null;

        $stmt = $conn->prepare("SELECT * FROM STUDENT WHERE user_id = ?");
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        $conn->close();
        return $user ?: null;
    }

    public function addGroupMessage(int $groupID, int $userID, string $messageText): bool {
        $conn = $this->connect();
        if (!$conn) return false;

        $stmt = $conn->prepare("INSERT INTO MESSAGE (group_id, user_id, message_text, time_sent, is_pinned) VALUES (?, ?, ?, NOW(), 0)");
        $stmt->bind_param("iis", $groupID, $userID, $messageText);
        $success = $stmt->execute();
        $stmt->close();
        $conn->close();
        return $success;
    }

    public function getGroupMessages(int $groupID): array {
        $conn = $this->connect();
        if (!$conn) return [];

        $stmt = $conn->prepare("SELECT * FROM MESSAGE WHERE group_id = ? ORDER BY time_sent DESC");
        $stmt->bind_param("i", $groupID);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $conn->close();
        return $messages;
    }
}
?>