<?php
define('DB_HOST', '100.95.34.112');
define('DB_USER', 'user');
define('DB_PASS', 'password');
define('DB_NAME', 'swedb');
?>
