<?php
include_once "../Models/UserDAO.php";
include_once __DIR__ . '/../config.php';

$host = DB_HOST;
$user = DB_USER;
$pass = DB_PASS;
$dbname = DB_NAME;

$threadId = intval($_GET['threadId'] ?? 0);
$groupId = intval($_GET['groupId'] ?? 0);
$lastMessageId = intval($_GET['lastMessageId'] ?? 0);

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userDAO = new UserDAO();
$currentUserId = $_SESSION['user']['user_ID'] ?? null;

if ($threadId !== 0) {
    $stmt = $conn->prepare("SELECT message_id, user_id, message_text, time_sent FROM MESSAGE WHERE thread_id = ? AND message_id > ? ORDER BY time_sent ASC");
    $stmt->bind_param("ii", $threadId, $lastMessageId);
} else {
    $stmt = $conn->prepare("SELECT message_id, user_id, message_text, time_sent FROM MESSAGE WHERE group_id = ? AND message_id > ? ORDER BY time_sent ASC");
    $stmt->bind_param("ii", $groupId, $lastMessageId);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $user = $userDAO->getUser($row['user_id']);
    $username = $user ? $user->getUsername() : 'Unknown';

    $dt = new DateTime($row['time_sent'], new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone('America/Chicago'));
    $formattedTime = $dt->format('M j, Y g:i A');

    $isOwnMessage = ($row['user_id'] == $currentUserId);
    $bubbleClass = $isOwnMessage ? 'bg-primary text-white' : 'bg-light text-dark';
    $justifyClass = $isOwnMessage ? 'justify-content-end' : 'justify-content-start';
    $timestampClass = $isOwnMessage ? 'text-dark' : 'text-secondary';
    $textAlignClass = $isOwnMessage ? 'text-end' : '';

    echo '<div class="d-flex ' . $justifyClass . ' mb-2" data-message-id="' . htmlspecialchars($row['message_id']) . '">';
    echo '<div class="p-2 rounded shadow-sm ' . $bubbleClass . '" style="max-width: 75%; width: fit-content; word-wrap: break-word;">';
    echo '<div class="d-flex mb-1">';
    if ($isOwnMessage) {
        echo '<span class="' . $timestampClass . ' small me-2">' . htmlspecialchars($formattedTime) . '</span>';
        echo '<span class="fw-bold fs-6 text-end ps-3">' . htmlspecialchars($username) . '</span>';
    } else {
        echo '<span class="fw-bold fs-6 me-2">' . htmlspecialchars($username) . '</span>';
        echo '<span class="' . $timestampClass . ' small">' . htmlspecialchars($formattedTime) . '</span>';
    }
    echo '</div>';
    echo '<div class="fs-6 text-break ' . $textAlignClass . '">' . htmlspecialchars($row['message_text']) . '</div>';
    echo '</div>';
    echo '</div>';
}

$stmt->close();
$conn->close();
?>