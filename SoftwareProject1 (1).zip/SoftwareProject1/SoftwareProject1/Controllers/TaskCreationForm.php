<?php
include_once "./Models/TaskDAO.php";
include_once "./Models/Task.php";
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Framework/Controller.php";
include_once "./Models/Group.php";

class TaskCreationForm extends Controller {

    public function performAction() {
        $userData = $_SESSION['user'];

        if (!$userData) {
            header("Location: start.php?action=Login");
            exit;
        }

        $taskDAO = new TaskDAO();
        $userDAO = new UserDAO();

        // Get members and group name from POST (sent from GroupView)
        $groupMembers = $_POST['group_members'] ?? [];
        $groupName = $_POST['group_name'] ?? "Unknown Group";

        $error = null;

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_task'])) {
            $taskName = trim($_POST['task_name'] ?? '');
            $taskDesc = trim($_POST['task_desc'] ?? '');
            $dueDate = $_POST['due_date'] ?? '';
            $dueTime = $_POST['due_time'] ?? '';

            // Combine into proper MySQL datetime
            if (!empty($dueDate) && !empty($dueTime)) {
                $dueDateTime = date('Y-m-d H:i:s', strtotime("$dueDate $dueTime"));
            } elseif (!empty($dueDate)) {
                $dueDateTime = date('Y-m-d H:i:s', strtotime($dueDate));
            } else {
                $dueDateTime = null;
            }

            // Get current timestamp for "date_assigned"
            $dateAssigned = date('Y-m-d H:i:s');

            // Get the selected members from checkboxes
            $selectedMembers = $_POST['assigned_members'] ?? [];

            if (!empty($taskName) && !empty($dueDateTime) && !empty($selectedMembers)) {
                $taskDAO->addTask($taskName, $taskDesc, $dueDateTime, $selectedMembers, $groupName, $dateAssigned);

                header("Location: start.php?action=GroupView");
                exit;
            } else {
                $error = "Please fill out all required fields and select at least one member.";
            }
        }

        // Load full user data for display
        $memberData = [];
        foreach ($groupMembers as $memberID) {
            $member = $userDAO->getUser($memberID);
            if ($member) {
                $memberData[] = $member;
            }
        }

        $this->renderView("TaskCreationForm", [
            "groupName" => $groupName,
            "members" => $memberData,
            "error" => $error
        ]);
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>