<?php
include_once "./Models/EventDAO.php";
include_once "./Models/MapNodeDAO.php";
include_once "./Framework/Controller.php";

class ExistingEvents extends Controller {

    public function performAction() {

        if (empty($_SESSION['user'])) {
            header("Location: start.php?action=Login");
            exit;
        }

        $userID = $_SESSION['user']['user_ID'];
        $isModerator = ($_SESSION['user']['accessLvl'] ?? "user") === "moderator";

        $eventDAO = new EventDAO();
        $mapNodeDAO = new MapNodeDAO();

        // Clean expired events
        $eventDAO->eventCleanup();

        // Click → RSVP page
        if (isset($_GET['event_id'])) {
            $_SESSION["rsvp_events"] = [(int)$_GET["event_id"]];
            header("Location: start.php?action=RSVPView");
            exit;
        }

        // POST actions
        if ($_SERVER["REQUEST_METHOD"] === "POST") {

            $action = $_POST["action_type"] ?? "";
            $selected = $_POST["selected_events"] ?? [];

            // REGISTER / UNREGISTER
            if ($action === "toggle_rsvp" && isset($_POST["event_id"])) {

                $eventID = (int)$_POST["event_id"];
                $event = $eventDAO->getEvent($eventID);
                $rsvp = json_decode($event["rsvp"], true);

                $creatorID = $rsvp[0];

                if ($userID == $creatorID) {
                    // Creator cannot unregister
                } else {
                    if (in_array($userID, $rsvp)) {
                        // unregister
                        $rsvp = array_values(array_filter($rsvp, fn($id) => $id != $userID));
                    } else {
                        // register
                        $rsvp[] = $userID;
                    }
                }

                $eventDAO->updateEventRSVP($eventID, json_encode($rsvp));
                header("Location: start.php?action=ExistingEvents");
                exit;
            }

            // DELETE EVENTS
            if ($action === "delete_selected") {
                foreach ($selected as $eventID) {
                    $eventDAO->deleteEventIfAllowed($eventID, $userID, $isModerator);
                }
                header("Location: start.php?action=ExistingEvents");
                exit;
            }

            // VIEW RSVPs
            if ($action === "rsvp_selected" && !empty($selected)) {
                $_SESSION["rsvp_events"] = $selected;
                header("Location: start.php?action=RSVPView");
                exit;
            }
        }

        // Build event list
        $raw = $eventDAO->getAllEvents();
        $events = [];

        foreach ($raw as $ev) {
            $nodeID = $eventDAO->getNodeIDForEvent($ev["event_id"]);
            $nodeData = $mapNodeDAO->getNode($nodeID);

            $building = $nodeData["node_name"] ?? "Unknown";

            $rsvp = json_decode($ev["rsvp"], true);
            $ev["creator_ID"] = $rsvp[0] ?? null;
            $ev["full_location"] = $building . " - " . $ev["location"];

            $events[] = $ev;
        }

        $this->renderView("ExistingEvents", [
            "events" => $events,
            "userID" => $userID,
            "isModerator" => $isModerator
        ]);
    }

    public function renderView($view, $data = []) {
        include __DIR__ . "/../Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
