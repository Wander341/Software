<?php
include_once "./Models/EventDAO.php";
include_once "./Models/MapNodeDAO.php";
include_once "./Models/MapNode.php";
include_once "./Models/Event.php";
include_once "./Framework/Controller.php";

class EventCreationForm extends Controller {

    public function performAction() {
        if ($_SERVER['REQUEST_METHOD'] == 'GET') {

            if (isset($_GET['node_id'])) {
                $nodeID = intval($_GET['node_id']);
                $mapNodeDAO = new MapNodeDAO();
                $nodeData = $mapNodeDAO->getNode($nodeID);

                if ($nodeData) {
                    $node = new MapNode();
                    $node->load($nodeData);
                    $locations = $node->getLocations();

                    $this->renderView("EventCreationForm", [
                        "node_id" => $nodeID,
                        "location" => $locations,
                        "error" => null
                    ]);
                } else {
                    header("Location: start.php?action=MapView");
                    exit;
                }

            } else {
                header("Location: start.php?action=MapView");
                exit;
            }

        } else {
            if (
                isset($_POST['event_name']) &&
                isset($_POST['event_desc']) &&
                isset($_POST['event_date']) &&
                isset($_POST['start_time']) &&
                isset($_POST['end_time']) &&
                isset($_POST['node_id']) &&
                isset($_POST['location'])
            ) {
                $eventName = trim($_POST['event_name']);
                $eventDescription = trim($_POST['event_desc']);
                $eventDate = trim($_POST['event_date']);
                $startTime = trim($_POST['start_time']);
                $endTime = trim($_POST['end_time']);
                $nodeID = intval($_POST['node_id']);
                $location = trim($_POST['location']);
                $userData = $_SESSION['user'];
                $userID = $userData['user_ID'];

                $startDateTime = date('Y-m-d H:i:s', strtotime("$eventDate $startTime"));
                $endDateTime   = date('Y-m-d H:i:s', strtotime("$eventDate $endTime"));

                $eventDAO = new EventDAO();
                $eventID = $eventDAO->createEvent($eventName, $eventDescription, $startDateTime, $endDateTime, $nodeID, $location, $userID);

                if ($eventID === "event_conflict" || $eventID === "class_conflict") {
                    $mapNodeDAO = new MapNodeDAO();
                    $nodeData = $mapNodeDAO->getNode($nodeID);
                    $node = new MapNode();
                    $node->load($nodeData);
                    $locations = $node->getLocations();

                    $errorMessage = ($eventID === "class_conflict")
                        ? "A class is being held in that room during this time."
                        : "There is already an event scheduled at this location during that time.";

                    $this->renderView("EventCreationForm", [
                        "node_id" => $nodeID,
                        "location" => $locations,
                        "error" => $errorMessage
                    ]);
                    return;
                }

                header("Location: start.php?action=MapView");
                exit;
            } else {
                header("Location: start.php?action=MapView");
                exit;
            }
        }
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>