<?php
include_once "./Framework/Controller.php";
include_once "./Models/TaskDAO.php";
include_once "./Models/Task.php";

class TaskView extends Controller
{
public function performAction() {
    $userData = $_SESSION['user'] ?? null;

    if (!$userData) {
        header("Location: start.php?action=Login");
        exit;
    }

    $taskDAO = new TaskDAO();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['selected_tasks']) && is_array($_POST['selected_tasks'])) {
            $actionType = $_POST['action_type'] ?? null;
            $selectedTasks = $_POST['selected_tasks'] ?? [];

            //Update selected tasks
            if ($actionType === 'Update Task') {
                header("Location: start.php?action=TaskUpdateForm");
                exit;
            }

            //Remove user from selected tasks
            if ($actionType === 'Quit Task') {
                foreach ($selectedTasks as $taskID) {
                    $taskData = $taskDAO->getTask($taskID);
                    $task = new Task();
                    $task->load($taskData);
                    $userData = $_SESSION['user'];
                    $userID = $userData['user_ID'];
                    $taskDAO->removeUserFromTask($userID, $task->getTaskID());
                }
                header("Location: start.php?action=TaskView");
                exit;
            }

            //Delete selected tasks 
            if ($actionType === 'Complete Task') {
                foreach ($selectedTasks as $taskID) {
                    $taskDAO->deleteTask($taskID);
                }

                header("Location: start.php?action=TaskView");
                exit;
            }
        }

        //redirect
        header("Location: start.php?action=TaskView");
        exit;
    }

    $tasks = $taskDAO->getAllTasks([$userData['user_ID']]);
//Render list of existing tasks for the current user
    $this->renderView("TaskView", [
        "task" => $tasks,
        "userID" => $userData['user_ID']
    ]);
}

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
