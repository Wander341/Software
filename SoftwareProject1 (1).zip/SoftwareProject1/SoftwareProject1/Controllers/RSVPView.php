<?php
include_once "./Models/EventDAO.php";
include_once "./Models/Event.php";
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Framework/Controller.php";

class RSVPView extends Controller {

    public function performAction() {

        $eventDAO = new EventDAO();
        $userDAO  = new UserDAO();

        /***********************************************
         * SUPPORT CALENDAR REDIRECT USING ?event_id=
         ***********************************************/
        if (isset($_GET['event_id'])) {
            $eventID = (int)$_GET['event_id'];
            $_SESSION['rsvp_events'] = [$eventID];   // overwrite list with single event
        }

        /***********************************************
         * FALLBACK: SESSION-BASED EVENT LIST
         ***********************************************/
        $selectedEventIDs = $_SESSION['rsvp_events'] ?? [];

        $rsvpData = [];

        foreach ($selectedEventIDs as $eventID) {

            $eventData = $eventDAO->getEvent($eventID);
            if (!$eventData) continue;

            // Build Event object
            $event = new Event();
            $event->load($eventData);

            // Load RSVP users
            $userIDs = $event->getRsvp();
            $attendees = [];

            foreach ($userIDs as $id) {
                $user = $userDAO->getUser($id);
                if ($user) {
                    $attendees[] = $user->getUsername();
                }
            }

            $rsvpData[] = [
                "event"     => $event,
                "attendees" => $attendees
            ];
        }

        /***********************************************
         * RENDER RSVP VIEW TEMPLATE
         ***********************************************/
        $this->renderView("RSVPView", [
            "rsvpData" => $rsvpData
        ]);
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
