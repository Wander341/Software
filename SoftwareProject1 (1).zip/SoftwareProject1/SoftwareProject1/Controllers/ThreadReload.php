<?php
ob_start();
include_once "./Framework/Controller.php";

    class ThreadReload extends Controller {

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }
    public function performAction(){
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['thread_id'])) {
            $threadId = trim($_POST['thread_id']);
        }
        $this->renderView("ThreadView", ['threadId' => $threadId]);
        }
    }
    
?>