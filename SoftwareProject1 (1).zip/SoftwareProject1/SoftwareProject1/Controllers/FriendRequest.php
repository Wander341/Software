<?php
include_once "./Framework/Controller.php";
include_once 'config.php';
class FriendRequest extends Controller {

    public function performAction() {
        $this->renderView("FriendRequest");
        $action = isset($_GET['subaction']) ? $_GET['subaction'] : '';

        if ($action === 'send') {
           $this->sendRequest();
        } else if ($action === 'accept') {
            $this->acceptRequest();
        } else if ($action === 'view') {
            $this->viewRequests();
        } else if ($action === 'viewFriends'){
            $this->viewFriends();
        }

        exit();
    }

    public function getAuth() {
        return "USER";
    }

    private function connectDB() {
        $host = DB_HOST;
        $user = DB_USER;
        $pass = DB_PASS;
        $dbname = DB_NAME;

        $conn = new mysqli($host, $user, $pass, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }

    private function sendRequest() {
        $userId = $_SESSION['user']['user_ID'];
        $friendId = isset($_POST['friend_id']) ? intval($_POST['friend_id']) : 0;

        if ($friendId === 0 || $friendId === $userId) {
            echo "Invalid friend ID.";
            return;
        }

        $conn = $this->connectDB();

        $check = $conn->prepare("SELECT * FROM Friendships WHERE user_id = ? AND friend_id = ?");
        $check->bind_param("ii", $userId, $friendId);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            echo "Friend request already sent or friendship exists.";
            $check->close();
            $conn->close();
            return;
        }
        $check->close();

        $stmt = $conn->prepare("INSERT INTO Friendships (user_id, friend_id, status) VALUES (?, ?, 'pending')");
        $stmt->bind_param("ii", $userId, $friendId);

        if ($stmt->execute()) {
            echo "Friend request sent.";
        } else {
            echo "Error sending request: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }

    private function acceptRequest() {
        $userId = $_SESSION['user']['user_ID'];;
        $friendId = isset($_POST['friend_id']) ? intval($_POST['friend_id']) : 0;

        if ($friendId === 0) {
            echo "Invalid friend ID.";
            return;
        }

        $conn = $this->connectDB();
        $stmt = $conn->prepare("UPDATE Friendships SET status = 'active' WHERE user_id = ? AND friend_id = ? AND status = 'pending'");
        $stmt->bind_param("ii", $friendId, $userId);

        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $reverse = $conn->prepare("INSERT INTO Friendships (user_id, friend_id, status) VALUES (?, ?, 'active')");
            $reverse->bind_param("ii", $userId, $friendId);
            $reverse->execute();
            $reverse->close();

            echo "Friend request accepted.";
        } else {
            echo "No pending request found.";
        }

        $stmt->close();
        $conn->close();
    }

    private function viewRequests() {
        $userId = $_SESSION['user']['user_ID'];

        $conn = $this->connectDB();

        $stmt = $conn->prepare("SELECT user_id FROM Friendships WHERE friend_id = ? AND status = 'pending'");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        $result = $stmt->get_result();

        echo "Pending friend requests:<br>";
        while ($row = $result->fetch_assoc()) {
            echo "User ID: " . htmlspecialchars($row['user_id']) . "<br>";
        }

        $stmt->close();
        $conn->close();
    }


    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }
}
?>
