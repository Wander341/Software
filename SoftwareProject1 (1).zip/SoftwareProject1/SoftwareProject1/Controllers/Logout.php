<?php
include_once "./Framework/Controller.php";

class Logout extends Controller {

    public function performAction() {
        session_unset();
        session_destroy();

        header("Location: start.php?action=Login");
        exit();
    }

    public function getAuth() {
        return "USER";
    }
}
?>
