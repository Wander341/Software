<?php
include_once "./Models/Group.php";
include_once "./Models/FriendDAO.php";
include_once "./Models/UserDAO.php";
include_once "./Framework/Controller.php";

class GroupCreationForm extends Controller {

    public function performAction() {

        $userData = $_SESSION['user'];
        $userID = $userData['user_ID'];

        $friendDAO = new FriendDAO();
        $userDAO = new UserDAO();

        $friendIDs = $friendDAO->getFriendsList($userID);
        $friends = [];
        foreach ($friendIDs as $fid) {
            $friends[] = $userDAO->getUser($fid);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $groupName = trim($_POST['group_name'] ?? "");
            $selectedFriends = $_POST['friends'] ?? [];

            if (empty($groupName)) {
                $this->renderView("GroupCreationForm", [
                    "friends" => $friends,
                    "error" => "Group name cannot be empty."
                ]);
                return;
            }

            $group = new Group();
            try {
                $groupID = $group->createGroup($groupName, $userID, $selectedFriends);
            } catch (Exception $e) {
                $groupID = false;
                error_log("Group creation exception: " . $e->getMessage());
            }

            if ($groupID) {
                header("Location: start.php?action=GroupView");
                exit;
            } else {
                $this->renderView("GroupCreationForm", [
                    "friends" => $friends,
                    "error" => "Failed to create group. Please try again."
                ]);
            }

        } else {
            $this->renderView("GroupCreationForm", [
                "friends" => $friends,
                "error" => null
            ]);
        }
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
