<?php
include_once "./Models/MapNodeDAO.php";
include_once "./Models/MapNode.php";

class MapView extends Controller {

    public function performAction() {
        $mapNodeDAO = new MapNodeDAO();
        $nodes = [];
        $result = $mapNodeDAO->getAllNodes();
        $nodes = $result;

        $this->renderView("MapView", ["nodes" => $nodes]);
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
    return "PRIVATE";
    }
}
?>