<?php
include_once "./Models/EventDAO.php";
include_once "./Models/TaskDAO.php";
include_once "./Models/MapNodeDAO.php";
include_once "./Models/Event.php";
include_once "./Models/Task.php";
include_once "./Models/MapNode.php";
include_once "./Framework/Controller.php";

class CalendarView extends Controller {

    public function performAction() {
        if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'POST') {
            $userID = (int)($_SESSION['user']['user_ID'] ?? 0);

            $eventDAO = new EventDAO();
            $taskDAO = new TaskDAO();
            $mapNodeDAO = new MapNodeDAO();

            $calendarItems = []; // Always define it

            // Set default timezone (adjust if needed)
            date_default_timezone_set('America/New_York');

            // --- EVENTS ---
            $allEvents = $eventDAO->getAllEvents();

            foreach ($allEvents as $eventRow) {
                $event = new Event();
                $event->load($eventRow);

                $rsvpArray = $event->getRsvp();
                if (!is_array($rsvpArray)) {
                    $rsvpArray = json_decode($rsvpArray, true) ?: [];
                }
                $rsvpArray = array_map('intval', $rsvpArray);

                if (in_array($userID, $rsvpArray)) {
                    $nodeID = $eventDAO->getNodeIDForEvent($event->getEventID());
                    $nodeData = $mapNodeDAO->getNode($nodeID);

                    $nodeName = $nodeData['node_name'] ?? '';
                    $rooms = $nodeData['location'] ?? '';
                    $roomString = is_array($rooms) ? implode(', ', $rooms) : $rooms;
                    $location = trim($nodeName . ($roomString ? ' - ' . $roomString : ''), ' -');

                    $calendarItems[] = [
                        'type' => 'event',
                        'id' => $event->getEventID(),
                        'title' => $event->getEventName(),
                        'start' => date('Y-m-d\TH:i:s', strtotime($event->getStartTime())),
                        'end' => date('Y-m-d\TH:i:s', strtotime($event->getEndTime())),
                        'location' => $location
                    ];
                }
            }

            // --- TASKS ---
            $tasks = $taskDAO->getAllTasks([$userID]);

            foreach ($tasks as $taskRow) {
                $due = strtotime($taskRow['due_date']);
                $calendarItems[] = [
                    'type' => 'task',
                    'id' => $taskRow['task_id'],
                    'title' => $taskRow['task_name'] . ' (' . $taskRow['group_name'] . ')',
                    'start' => date('Y-m-d\TH:i:s', $due - 1800),
                    'end' => date('Y-m-d\TH:i:s', $due)
                ];
            }

            // --- SORT CALENDAR ITEMS ---
            usort($calendarItems, fn($a, $b) => strtotime($a['start']) <=> strtotime($b['start']));

            // --- RENDER VIEW ---
            $this->renderView("CalendarView", ['calendarItems' => $calendarItems]);
        }
    }

    public function renderView($view, $data = []) {
        extract($data);
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PRIVATE";
    }
}
?>
