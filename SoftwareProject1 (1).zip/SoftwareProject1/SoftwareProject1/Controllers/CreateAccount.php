<?php
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Framework/Controller.php";

class CreateAccount extends Controller {

    public function performAction() {
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
            $username = trim($_POST['username'] ?? '');
            $password = hash('sha256', trim($_POST['password'] ?? ''));
            $email = trim($_POST['email'] ?? '');
            $uafs_id = trim($_POST['uafs_id'] ?? '');

            if (empty($username) || empty($password) || empty($email) || empty($uafs_id)) {
                $error = "All fields are required.";
            } else {
                $user = new User();
                $user->setUsername($username);
                $user->setPassword($password);
                $user->setEmail($email);
                $user->setUafsID($uafs_id);
                $user->setAccessLevel("user");
                $user->setDescription("");

                $dao = new UserDAO();

                try {
                    // Add the new user to the database
                    $dao->addUser($user);

                    // Retrieve the just-created user from the database
                    $createdUser = $dao->getUserByUsername($username);

                    if ($createdUser) {
                        // Start a session if not already active
                        if (session_status() === PHP_SESSION_NONE) {
                            session_start();
                        }

                        // Store user in session (router checks for this)
                        $_SESSION['user'] = $createdUser;

                        // Optional: also store some individual fields for convenience
                        if (is_array($createdUser)) {
                            $_SESSION['user_id'] = $createdUser['user_id'];
                            $_SESSION['username'] = $createdUser['username'];
                            $_SESSION['access_level'] = $createdUser['access_level'];
                        } elseif (is_object($createdUser)) {
                            $_SESSION['user_id'] = $createdUser->getUserID();
                            $_SESSION['username'] = $createdUser->getUsername();
                            $_SESSION['access_level'] = $createdUser->getAccessLevel();
                        }

                        // Redirect to home after login
                        header("Location: start.php?action=Home");
                        exit();
                    } else {
                        $error = "Account created, but automatic login failed.";
                    }
                } catch (Exception $e) {
                    $error = "Account creation failed: " . $e->getMessage();
                }
            }
        }

        // Render the CreateAccount view with any error message
        $this->renderView("CreateAccount", [
            "error" => $error
        ]);
    }



    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PUBLIC";
    }
}
?>