<?php
ob_start();
include_once "./Framework/Controller.php";

    class GroupReload extends Controller {

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }
    public function performAction() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $groupId = intval($_POST['group_id']);
        $messageText = trim($_POST['message_text'] ?? '');
        $userId = $_SESSION['user']['user_ID'] ?? 0;

        if ($messageText !== '') {
            $sender = new SendMessage();
            $sender->sendGroupMessage($userId, $groupId, $messageText);
        }

        header("Location: start.php?action=GroupView&group_id=$groupId");
        exit;
    }
}
    }
    
?>