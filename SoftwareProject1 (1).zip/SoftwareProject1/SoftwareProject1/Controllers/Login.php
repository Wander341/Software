<?php
include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Framework/Controller.php";

class Login extends Controller {

    public function performAction() {
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['login'])) {
                $username = trim($_POST['username']);
                $password = trim($_POST['password']);

                if (empty($username) || empty($password)) {
                    $error = "Username and password are required.";
                } else {
                    $dao = new UserDAO();
                    $userData = $dao->getUserByUsername($username);

                    if (!$userData) {
                        $error = "Invalid username or password.";
                    } 
                    elseif ($userData['password'] !== hash('sha256', $password)) {
                        $error = "Invalid username or password.";
                    } 
                    else {
                        $userID = $userData['user_ID'];
                        $index = $dao->checkBlacklist($userID);

                        if ($index >= 0) {
                            $error = "This user has been banned from the platform.";
                        } else {
                            $_SESSION['user'] = [
                                'user_ID' => $userData['user_ID'],
                                'username' => $userData['username'],
                                'email' => $userData['email'],
                                'accessLvl' => $userData['accessLvl'],
                                'uafs_id' => $userData['uafs_id'],
                                'userDesc' => $userData['userDesc'],
                                'profile_pic' => $userData['profile_pic']
                            ];
                            header("Location: start.php?action=Home");
                            exit();
                        }
                    }
                }
            }

            if (isset($_POST['create'])) {
                header("Location: start.php?action=CreateAccount");
                exit();
            }
        }

        $this->renderView("Login", ["error" => $error]);
    }

    public function renderView($view, $data = []) {
        include "./Views/$view.php";
    }

    public function getAuth() {
        return "PUBLIC";
    }
}
