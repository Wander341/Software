<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Existing Events</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include './Styles/Stylesheet.php'; ?>


</head>

<body>
    <?php include 'Navbar.php' ?>

    <div class="container my-4">
        <form method="POST">
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php
                require_once './Models/Event.php';
                require_once './Models/EventDAO.php';
                $currentUser = $_SESSION['user']['user_ID'];

                $eventDAO = new EventDAO();
                ?>

                <?php foreach ($data['events'] as $event):
                    $isRegistered = in_array($currentUser,json_decode($event['rsvp'],true));
                    $btnClass = $isRegistered ? 'btn-danger' : 'btn-primary';
                    $btnText = $isRegistered ? 'Unregister' : 'Register';

                ?>
                    <div class="col">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body d-flex flex-column">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="selected_events[]" value="<?= htmlspecialchars($event['event_id']) ?>" id="event<?= $event['event_id'] ?>">
                                    <label class="form-check-label fw-bold" for="event<?= $event['event_id'] ?>">
                                        <?= htmlspecialchars($event['event_name']) ?>
                                    </label>
                                </div>

                                <p class="card-text mb-1"><strong>Details:</strong> <?= htmlspecialchars($event['event_desc']); ?></p>
                                <p class="card-text mb-1"><strong>Location:</strong> <?= htmlspecialchars($event['full_location']); ?></p>
                                <p class="card-text mb-3">
                                    <strong>Time:</strong>
                                    <?= date("m/d/Y, g:iA", strtotime($event['start_time'])) ?>
                                    -
                                    <?= date("g:iA", strtotime($event['end_time'])) ?>
                                </p>

                                <form method="POST">
                                    <button type="submit" name="action_type"
                                            value="<?= $isRegistered ? 'unregister_'.$event['event_id'] : 'register_'.$event['event_id'] ?>"
                                            class="btn <?= $btnClass ?> w-100 mb-2">
                                        <?= $btnText ?>
                                    </button>
                                    <button type="submit" name="action_type" value="rsvp_<?= $event['event_id'] ?>" class="btn btn-success w-100">
                                        View RSVP
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Optional: global buttons for selected events -->
            <div class="d-flex justify-content-center gap-2 mt-3 flex-wrap">


                <button type="submit" name="action_type" value="rsvp_selected" class="btn btn-success rounded-pill px-4">
                    View RSVP for Selected Events
                </button>
            </div>
        </form>
    </div>


    <?php include 'Scripts.php'; ?>
</body>

</html>
