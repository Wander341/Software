<?php
if (!isset($calendarItems)) {
    $calendarItems = [];
}

include_once "./Models/UserDAO.php";
include_once "./Models/User.php";
include_once "./Models/EventDAO.php";
include_once "./Models/Event.php";
include_once "./config.php";

/*
 * |--------------------------------------------------------------------------
 * | LOAD USER BIRTHDAYS (USED FOR PRIVACY-SAFE CALENDAR EVENTS)
 * |--------------------------------------------------------------------------
 */
$userDAO = new UserDAO();
$userBirthdays = $userDAO->getAllUserBirthdays();

$currentUserID = $_SESSION['user']['user_ID'];

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

/*
 * |--------------------------------------------------------------------------
 * | ADD BIRTHDAYS ONLY VISIBLE TO USER OR FRIENDS
 * |--------------------------------------------------------------------------
 */
foreach ($userBirthdays as $bd) {

    $userID = $bd["user_ID"];
    $birthday = $bd["birthday"];

    if (!$birthday || $birthday === "0000-00-00") continue;

    // Always visible to yourself
    $isVisible = ($userID == $currentUserID);

    // Check if friends if not yourself
    if (!$isVisible) {
        $stmt = $conn->prepare("
        SELECT * FROM Friendships
        WHERE
        ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))
        AND status = 'active'
        ");
        $stmt->bind_param("iiii", $currentUserID, $userID, $userID, $currentUserID);
        $stmt->execute();
        $isVisible = $stmt->get_result()->num_rows > 0;
        $stmt->close();
    }

    if (!$isVisible) continue;

    // Birthdays recur yearly → extract month/day
    $monthDay = substr($birthday, 5);

    $calendarItems[] = [
        "id"    => "birthday_" . $userID,
        "title" => "🎂 " . $bd["username"] . "'s Birthday",
        "start" => date("Y") . "-" . $monthDay,
        "color" => "#ff9ecd",
        "display" => "list-item"
    ];
}


/*
 * |--------------------------------------------------------------------------
 * | HOLIDAYS (multi-year generation)
 * |--------------------------------------------------------------------------
 */

function computeEasterDate($year) {
    $a = $year % 19;
    $b = intdiv($year, 100);
    $c = $year % 100;
    $d = intdiv($b, 4);
    $e = $b % 4;
    $f = intdiv($b + 8, 25);
    $g = intdiv($b - $f + 1, 3);
    $h = (19*$a + $b - $d - $g + 15) % 30;
    $i = intdiv($c, 4);
    $k = $c % 4;
    $l = (32 + 2*$e + 2*$i - $h - $k) % 7;
    $m = intdiv($a + 11*$h + 22*$l, 451);
    $month = intdiv($h + $l - 7*$m + 114, 31);
    $day = (($h + $l - 7*$m + 114) % 31) + 1;
    return sprintf("%04d-%02d-%02d", $year, $month, $day);
}

$yearStart = date("Y") - 2;
$yearEnd   = date("Y") + 2;

for ($year = $yearStart; $year <= $yearEnd; $year++) {

    $easter       = computeEasterDate($year);
    $memorialDay  = date("Y-m-d", strtotime("last Monday of May $year"));
    $thanksgiving = date("Y-m-d", strtotime("fourth Thursday of November $year"));
    $fathersDay   = date("Y-m-d", strtotime("third Sunday of June $year"));
    $mothersDay   = date("Y-m-d", strtotime("second Sunday of May $year"));

    $holidays = [
        ["id" => "ny$year", "title" => "🎉 New Year's Day",   "date" => "$year-01-01"],
        ["id" => "vd$year", "title" => "❤️ Valentine's Day",  "date" => "$year-02-14"],
        ["id" => "jt$year", "title" => "🎗 Juneteenth",        "date" => "$year-06-19"],
        ["id" => "id$year", "title" => "🎆 Independence Day", "date" => "$year-07-04"],
        ["id" => "cd$year", "title" => "🎄 Christmas",        "date" => "$year-12-25"],
        ["id" => "md$year", "title" => "🌸 Mother's Day",    "date" => $mothersDay],
        ["id" => "es$year", "title" => "🐣 Easter",          "date" => $easter],
        ["id" => "mm$year", "title" => "🇺🇸 Memorial Day",   "date" => $memorialDay],
        ["id" => "tg$year", "title" => "🦃 Thanksgiving",    "date" => $thanksgiving],
        ["id" => "fd$year", "title" => "👨‍👧 Father's Day",  "date" => $fathersDay],
    ];

    foreach ($holidays as $h) {
        $calendarItems[] = [
            "id"    => "holiday_" . $h["id"],
            "title" => $h["title"],
            "start" => $h["date"],
            "color" => "#8c52ff",
            "display" => "list-item"
        ];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Calendar</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/bootstrap5@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.19/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.19/index.global.min.css" rel="stylesheet">

<?php include './Styles/Stylesheet.php'; ?>

<style>
#calendar {
max-width: 900px;
margin: 50px auto;
}
.fc-daygrid-event {
    margin-top: 18px !important; /* pushes holidays to bottom */
}
</style>

</head>
<body>

<?php include 'Navbar.php'; ?>

<div id="calendar"></div>

<!-- ADD EVENT MODAL -->
<div class="modal fade" id="addEventModal" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Add Event</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<div class="mb-3">
<label>Date</label>
<input type="text" id="eventDate" class="form-control" readonly>
</div>

<div class="mb-3">
<label>Event Name</label>
<input type="text" id="eventName" class="form-control">
</div>

<div class="mb-3">
<label>Description</label>
<textarea id="eventDesc" class="form-control"></textarea>
</div>

<div class="row">
<div class="col">
<label>Start Time</label>
<input type="time" id="startTime" class="form-control">
</div>
<div class="col">
<label>End Time</label>
<input type="time" id="endTime" class="form-control">
</div>
</div>

<div class="mb-3 mt-3">
<label>Location</label>
<input type="text" id="location" class="form-control">
</div>

</div>

<div class="modal-footer">
<button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button class="btn btn-primary" id="saveEventBtn">Save Event</button>
</div>

</div>
</div>
</div>

<!-- HIDDEN FORM FOR ADDING EVENTS -->
<form id="calendarEventForm" method="POST" action="start.php?action=EventCreationForm" style="display:none;">
<input type="hidden" name="event_name">
<input type="hidden" name="event_desc">
<input type="hidden" name="event_date">
<input type="hidden" name="start_time">
<input type="hidden" name="end_time">
<input type="hidden" name="location">
<input type="hidden" name="node_id" value="0">
</form>

<?php include 'Scripts.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/bootstrap5@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@6.1.19/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@6.1.19/index.global.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    var calendarEl = document.getElementById("calendar");

    var calendar = new FullCalendar.Calendar(calendarEl, {

        initialView: "dayGridMonth",
        themeSystem: "bootstrap5",

        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay"
        },

        selectable: true,

        eventClick: function(info) {
            const id = info.event.id;

            if (String(id).startsWith("holiday_")) {
                alert(info.event.title);
                return;
            }

            if (String(id).startsWith("birthday_")) {
                alert(info.event.title);
                return;
            }

            window.location.href = "start.php?action=RSVPView&event_id=" + id;
        },

        dateClick: function(info) {
            document.getElementById("eventDate").value = info.dateStr;
            new bootstrap.Modal(document.getElementById('addEventModal')).show();
        },

        events: <?php echo json_encode($calendarItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>

    });

    calendar.render();

    // Save event from modal → submit form
    document.getElementById("saveEventBtn").onclick = function () {
        let form = document.getElementById("calendarEventForm");

        form.event_name.value = document.getElementById("eventName").value;
        form.event_desc.value = document.getElementById("eventDesc").value;
        form.event_date.value = document.getElementById("eventDate").value;
        form.start_time.value = document.getElementById("startTime").value;
        form.end_time.value = document.getElementById("endTime").value;
        form.location.value = document.getElementById("location").value;
        form.node_id.value = 0;

        form.submit();
    };

});
</script>

</body>
</html>
