<?php
require_once 'Models/Thread.php';
require_once 'Controllers/MessageLoad.php';
require_once 'Models/UserDAO.php';
require_once 'Models/User.php';

$threadModel = new Thread();
$threads = $threadModel->getAllThreads();
$numThreads = count($threads);

if (!empty($data['threadId'])) {
  $selectedThreadId = $data['threadId'];
  foreach ($threads as $thread) {
    if ($selectedThreadId == $thread->getThreadId()) {
      $selectedThreadName = $thread->getThreadName();
      break;
    }
  }
} else if (!empty($threads)) {
  $selectedThreadId = $threads[0]->getThreadId();
  $selectedThreadName = $threads[0]->getThreadName();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_thread'])) {
  $selectedThreadId = htmlspecialchars($_POST['selected_thread']);
  foreach ($threads as $thread) {
    if ($selectedThreadId == $thread->getThreadId()) {
      $selectedThreadName = $thread->getThreadName();
      break;
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include './Styles/Stylesheet.php'; ?>
  <meta charset="UTF-8">
  <title>Thread View</title>
</head>
<body>
<?php include 'Navbar.php'; ?>
<div class="container-fluid">

  <!-- Sidebar Toggle -->
  <button class="btn btn-primary m-2 d-flex align-items-center gap-2" type="button"
          data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas" aria-controls="sidebarOffcanvas">
    <i class="fa-solid fa-arrow-right"></i>
  </button>

  <!-- Sidebar -->
  <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebarOffcanvas" aria-labelledby="sidebarOffcanvasLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="sidebarOffcanvasLabel">Threads</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <h2>Create Thread</h2>
      <form method="POST" action="start.php?action=ThreadView" class="mb-4">
        <input type="text" name="thread_name" class="form-control mb-2" placeholder="Thread name" required>
        <button type="submit" class="btn btn-success w-100">Create</button>
      </form>

      <h2>Threads</h2>
      <?php foreach ($threads as $thread): ?>
        <?php $isActive = ($thread->getThreadId() == $selectedThreadId); ?>
        <form method="POST" action="start.php?action=ThreadView" class="mb-2">
          <input type="hidden" name="selected_thread" value="<?= $thread->getThreadId(); ?>">
          <button type="submit"
                  class="btn <?= $isActive ? 'btn-dark' : 'btn-primary' ?> w-100 text-start">
            <?= htmlspecialchars($thread->getThreadName()); ?>
          </button>
        </form>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Chat Panel -->
  <div class="row mt-3">
    <div class="col-12 col-md-10 col-lg-8 mx-auto">
      <div class="border rounded shadow-sm p-3 d-flex flex-column" style="min-height: 600px; max-height: 80vh;">
        <div class="bg-primary text-white p-2 p-md-3 mb-3 border-bottom fw-bold fs-5 fs-md-4 fs-lg-3 rounded">
          <?= htmlspecialchars($selectedThreadName ?? 'No Thread Selected'); ?>
        </div>

        <div class="flex-grow-1 overflow-auto" style="max-height: 70vh;" id="chatMessages">
          <?php
          $currentUserId = $_SESSION['user']['user_ID'] ?? null;
          if (!empty($selectedThreadId)) {
            $loader = new MessageLoad();
            $messages = $loader->loadMessagesByThreadId($selectedThreadId);

            foreach ($messages as $msg) {
              $userDAO = new UserDAO();
              $user = $userDAO->getUser($msg->user_id);

              $dt = new DateTime($msg->time_sent, new DateTimeZone('UTC'));
              $dt->setTimezone(new DateTimeZone('America/Chicago'));
              $formattedTime = $dt->format('M j, Y g:i A');

              $isOwnMessage = ($msg->user_id == $currentUserId);
              $bubbleClass = $isOwnMessage ? 'bg-primary text-white' : 'bg-light text-dark';
              $justifyClass = $isOwnMessage ? 'justify-content-end' : 'justify-content-start';
              $timestampClass = $isOwnMessage ? 'text-dark' : 'text-secondary';

              echo '<div class="d-flex ' . $justifyClass . ' mb-2" data-message-id="' . $msg->message_id . '">';
              echo '<div class="p-2 rounded shadow-sm ' . $bubbleClass . '" style="max-width: 75%; width: fit-content; word-wrap: break-word;">';
              echo '<div class="d-flex mb-1">';
              if ($isOwnMessage) {
                echo '<span class="' . $timestampClass . ' small me-2">' . htmlspecialchars($formattedTime) . '</span>';
                echo '<span class="fw-bold fs-6 text-end ps-3">' . htmlspecialchars($user->getUsername()) . '</span>';
              } else {
                echo '<span class="fw-bold fs-6 me-2">' . htmlspecialchars($user->getUsername()) . '</span>';
                echo '<span class="' . $timestampClass . ' small">' . htmlspecialchars($formattedTime) . '</span>';
              }
              echo '</div>';
              echo '<div class="fs-6 text-break ' . ($isOwnMessage ? 'text-end' : '') . '">' . htmlspecialchars($msg->message_text) . '</div>';
              echo '</div>';
              echo '</div>';
            }
          }
          ?>
        </div>

        <button id="jump-to-present" class="btn btn-primary mt-2 align-self-end d-none">
          Jump to Present
        </button>
      </div>

      <!-- Chat Input -->
      <form method="POST" action="start.php?action=ThreadReload" class="mt-3 d-flex gap-2">
        <input type="hidden" name="thread_id" value="<?= $selectedThreadId; ?>">
        <input type="text" name="message_text" class="form-control" placeholder="Type a message..." required>
        <button type="submit" class="btn btn-success">Send</button>
      </form>
    </div>
  </div>
</div>

<!-- Auto-refresh and scroll -->
<script>
  let lastMessageId = <?php echo $messages[count($messages) - 1]->message_id ?? 0; ?>;
  const threadId = <?php echo $selectedThreadId; ?>;
  const chatMessages = document.querySelector('#chatMessages');
  const jumpButton = document.getElementById('jump-to-present');

  function isNearBottom() {
    return chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight < 100;
  }

  setInterval(() => {
    fetch(`./Controllers/MessageCheck.php?threadId=${threadId}&lastMessageId=${lastMessageId}`)
      .then(response => response.text())
      .then(html => {
        if (html.trim() !== '') {
          const wasNearBottom = isNearBottom();
          chatMessages.innerHTML += html;

          const newLastId = chatMessages.lastElementChild?.dataset.messageId;
          if (newLastId) lastMessageId = parseInt(newLastId);

          if (wasNearBottom) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
            jumpButton.classList.add('d-none');
          } else {
            jumpButton.classList.remove('d-none');
          }
        }
      });
  }, 1000);

  chatMessages.addEventListener('scroll', () => {
    jumpButton.classList.toggle('d-none', isNearBottom());
  });

  jumpButton.addEventListener('click', () => {
    chatMessages.scrollTop = chatMessages.scrollHeight;
    jumpButton.classList.add('d-none');
  });

  window.addEventListener('load', () => {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  });
</script>

<?php include 'Scripts.php'; ?>
</body>
</html>
