
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include './Styles/Stylesheet.php'; ?>
  <style>
    #content {
      display: flex;
      padding: 20px;
    }
    #event-directions {
      width: 300px;
      height: 450px;
      background-color: #007BFF;
      color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
      margin-right: 20px;
      margin-top: 20px;
    }
    #event-directions h2 {
      text-align: center;
      margin-top: 0;
      margin-bottom: 20px;
    }
    #event-directions p {
      line-height: 1.5;
      text-align: center;
    }
    #event-directions a {
      color: white;
      font-weight: bold;
      text-decoration: underline;
    }
    #map-container {
      flex-grow: 1;
      min-height: 50vh;
      box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
      border-radius: 5px;
      overflow: hidden;
      margin-top: 20px;
    }
    #map {
      height: 100%;
      width: 100%;
    }

    #map {
      cursor: default;
    }
    .leaflet-marker-icon {
      cursor: pointer;
    }
    #map:hover {
      cursor: crosshair;
    }

    #bottom-button-container {
        width: 100%;
        text-align: center;
        padding-top: 30px;
        padding-bottom: 10px;
    }
    #Contact-Btn {
        background-color: #007BFF;
        color: white;
        padding: 15px 30px;
        font-size: 1.2em;
        font-weight: bold;
        border: none;
        border-radius: 50px;
        cursor: pointer;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background-color 0.2s, transform 0.2s;
    }
    #Contact-Btn:hover {
        background-color: #0052ccff;
        transform: translateY(-2px);
    }
    
  </style>
</head>
<body>

  <?php include 'Navbar.php'?>
  <div class="px-4 py-5 my-5 text-center rounded shadow bg-light">
    <h1 class="display-5 fw-bold">About LockedIn</h1>

    <div class="col-md-8 mx-auto my-4">
      <p class="lead mb-0">
        LockedIn is a social media web application created by UAFS Computer Science students,
        for UAFS Computer Science students. It's designed to help students optimize their schedules
        and connect with their peers. With features like an interactive map for scheduling group
        sessions, task management tools for collaboration, and communication threads to socialize
        with all other CS peers, LockedIn makes time management and social interaction easier for
        CS students. Feel free to check out an example of the interactive map below!
      </p>
    </div>

    
  </div>


  <div id="content">
    

    <div id="map-container">
      <div id="map"></div>
    </div>
  </div>

  <div id="bottom-button-container">
        <button id="Contact-Btn" onclick="alert('This resource is Down. Try again never!');">
            Contact us at: CompletelyRealEmail@uafs.edu
        </button>
    </div>
    </div>


  <?php include 'Scripts.php'; ?>
  <script>
    const imageWidth = 1388;
    const imageHeight = 938;
    const bounds = [[0, 0], [imageHeight, imageWidth]];

    const map = L.map('map', {
      crs: L.CRS.Simple,
      minZoom: -2,
      maxZoom: 2,
      zoom: 0,
      center: [imageHeight / 2, imageWidth / 2]
    });
    const imageUrl = './Images/uafsmap.png'; 
    const mapImage = L.imageOverlay(imageUrl, bounds).addTo(map);

    // Error handling for image loading
    mapImage.on('error', function(e) {
        console.error("Failed to load map image. Check the path: " + imageUrl, e);
        L.marker(map.getCenter()).addTo(map).bindPopup("Map Image Failed to Load!").openPopup();
    });

    map.fitBounds(bounds);
    const testNodes = [
      { nodeID: 1, nodeName: "Baldor Building", location: [275, 465] }, // [y, x]
      { nodeID: 2, nodeName: "Math/Science Building", location: [550, 295] },
      { nodeID: 3, nodeName: "Library", location: [655, 665] }
    ];

    testNodes.forEach(node => {
      const latLng = L.latLng(node.location[0], node.location[1]); 
      const marker = L.marker(latLng).addTo(map);
      marker.bindPopup(node.nodeName);
      marker.on('click', () => { });
    });
  </script>
</body>
</html>