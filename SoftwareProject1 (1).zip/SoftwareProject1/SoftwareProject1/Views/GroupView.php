<?php
require_once 'Models/Group.php';
require_once 'Controllers/MessageLoad.php';
require_once 'Models/UserDAO.php';
require_once 'Models/User.php';

$groupModel = new Group();
$userID = $_SESSION['user']['user_ID'];
$groups = $groupModel->getAllGroupsByUser($userID);

// Determine selected group
$selectedGroupId = $_GET['group_id'] ?? (!empty($groups) ? ($groups[0]->getGroupID() ?? 0) : 0);

$selectedGroup = $selectedGroupId ? $groupModel->getGroup($selectedGroupId) : null;
$groupMembers = $selectedGroup ? $selectedGroup->getStudents() : [];
$selectedGroupName = $selectedGroup ? $selectedGroup->getGroupName() : "No groups yet";

// Load messages
$loader = new MessageLoad();
$messages = $selectedGroupId ? $loader->loadMessagesByGroupId($selectedGroupId) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Group View</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include './Styles/Stylesheet.php'; ?>
  <link rel="stylesheet" href="./Styles/group.css">
  <style>
    

  </style>
</head>
<body>

<?php include 'Navbar.php'; 
$groupMessageNotifs = [];

if (!empty($notifications)) {
    foreach ($notifications as $notif) {
        if ($notif['notif_type'] === 'message') {
            $groupMessageNotifs[] = $notif['notif_name'];
        }
    }
}



?>

<div class="container-fluid mt-3 px-5">
  <!-- Responsive Group Name Header -->
  <div class="text-center mb-3">
    <div class="bg-primary text-white fw-bold rounded d-inline-block"
        style="font-size: 2rem; padding: 1rem 2rem; border-bottom: 3px solid #0d6efd;">
      <?= htmlspecialchars($selectedGroupName ?? 'No Group Selected'); ?>
    </div>
  </div>



  <!-- Sidebar Buttons Row -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <!-- Groups Sidebar Button -->
    <button class="btn btn-primary d-flex align-items-center gap-2" type="button"
            data-bs-toggle="offcanvas" data-bs-target="#groupSidebarOffcanvas" aria-controls="groupSidebarOffcanvas">
      <i class="fa-solid fa-arrow-right"></i> Groups
    </button>

    <!-- Members Sidebar Button -->
    <button class="btn btn-outline-secondary d-flex align-items-center gap-2" type="button"
            data-bs-toggle="offcanvas" data-bs-target="#memberSidebarOffcanvas" aria-controls="memberSidebarOffcanvas">
      <i class="fa-solid fa-users"></i> View Members
    </button>
  </div>

  <!-- Chat Panel -->
  <?php if ($selectedGroupId): ?>
    <div class="chat-panel mb-4">
      <div class="chat-header fw-bold fs-5 mb-2">Messages</div>
      <div class="chat-messages d-flex flex-column gap-2">
        <?php foreach ($messages as $msg): ?>
          <?php
            $userDAO = new UserDAO();
            $user = $userDAO->getUser($msg->user_id);
            $dt = new DateTime($msg->time_sent, new DateTimeZone('UTC'));
            $dt->setTimezone(new DateTimeZone('America/Chicago'));
            $formattedTime = $dt->format('M j, Y g:i A');
            $isOwnMessage = ($msg->user_id == $_SESSION['user']['user_ID']);
            $bubbleClass = $isOwnMessage ? 'bg-primary text-white' : 'bg-light text-dark';
            $justifyClass = $isOwnMessage ? 'justify-content-end' : 'justify-content-start';
            $timestampClass = $isOwnMessage ? 'text-dark' : 'text-secondary';
          ?>

          <div class="d-flex <?= $justifyClass ?> mb-2" data-message-id="<?= $msg->message_id; ?>">
            <div class="p-2 rounded shadow-sm <?= $bubbleClass ?>" 
                style="max-width: 75%; width: fit-content; word-wrap: break-word;">
              <div class="d-flex mb-1">
                <?php if ($isOwnMessage): ?>
                  <span class="<?= $timestampClass ?> small me-2"><?= htmlspecialchars($formattedTime); ?></span>
                  <span class="fw-bold fs-6 text-end ps-3"><?= htmlspecialchars($user->getUsername()); ?></span>
                <?php else: ?>
                  <span class="fw-bold fs-6 me-2"><?= htmlspecialchars($user->getUsername()); ?></span>
                  <span class="<?= $timestampClass ?> small"><?= htmlspecialchars($formattedTime); ?></span>
                <?php endif; ?>
              </div>
              <div class="fs-6 text-break <?= $isOwnMessage ? 'text-end' : '' ?>">
                <?= htmlspecialchars($msg->message_text); ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <button id="jump-to-present" class="btn btn-primary mt-2 align-self-end d-none">
          Jump to Present
        </button>
    </div>

    <!-- Chat Input -->
    <form id="group-message-form" method="POST" action="start.php?action=SendMessage" class="d-flex gap-2">
      <input type="hidden" name="group_id" value="<?= $selectedGroupId; ?>">
      <input type="text" name="message_text" class="form-control" placeholder="Type a message..." required>
      <button type="submit" class="btn btn-primary">Send</button>
    </form>
  <?php endif; ?>
</div>

<!-- Groups Offcanvas Sidebar -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="groupSidebarOffcanvas" aria-labelledby="groupSidebarLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="groupSidebarLabel">Your Groups</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <?php if (!empty($groups)): ?>
      <?php foreach ($groups as $group): ?>
        <?php $isActive = ($group->getGroupID() == $selectedGroupId) ? 'active-group' : ''; ?>
        <?php
          $gName = $group->getGroupName();
          $notifText = "You have new messages from " . $gName;
          $hasNotif = in_array($notifText, $groupMessageNotifs);
          ?>

          <a href="start.php?action=GroupView&group_id=<?= $group->getGroupID(); ?>"
            class="group-item <?= $isActive ?> d-block mb-2 text-decoration-none text-white p-2 rounded position-relative"
            style="background-color: #007BFF;">

              <?= htmlspecialchars($gName); ?>

              <?php if ($hasNotif): ?>
              <span class="notif-dot"></span>
              <?php endif; ?>
          </a>
      <?php endforeach; ?>
      <form method="GET" action="start.php" class="mt-3">
        <input type="hidden" name="action" value="GroupCreationForm">
        <button type="submit" class="btn btn-success w-100">+ Create Group</button>
      </form>
    <?php else: ?>
      <p>You’re not part of any groups yet.</p>
      <form method="GET" action="start.php">
        <input type="hidden" name="action" value="GroupCreationForm">
        <button type="submit" class="btn btn-success">Create Your First Group</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<!-- Members Offcanvas Sidebar -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="memberSidebarOffcanvas" aria-labelledby="memberSidebarLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="memberSidebarLabel">Members of <?= htmlspecialchars($selectedGroupName); ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="d-flex flex-column gap-2">
      <?php foreach ($groupMembers as $member): ?>
        <?php $fullUser = (new UserDAO())->getUser($member['user_id']); ?>
        <button class="btn btn-outline-primary d-flex align-items-center gap-2 member-btn"
                data-username="<?= htmlspecialchars($fullUser->getUsername()); ?>"
                data-email="<?= htmlspecialchars($fullUser->getEmail()); ?>"
                data-desc="<?= htmlspecialchars($fullUser->getDescription()); ?>"
                data-profile="<?= htmlspecialchars($fullUser->getProfilePic()); ?>">
          <img src="<?= htmlspecialchars($fullUser->getProfilePic()); ?>" alt="Profile Pic"
               class="rounded-circle" style="width:24px;height:24px;">
          <?= htmlspecialchars($fullUser->getUsername()); ?>
        </button>
      <?php endforeach; ?>
    </div>

    <?php if (!empty($groupMembers)): ?>
      <form action="start.php?action=TaskCreationForm" method="POST" class="mt-4">
        <input type="hidden" name="group_name" value="<?= htmlspecialchars($selectedGroupName); ?>">
        <?php foreach ($groupMembers as $member): ?>
          <input type="hidden" name="group_members[]" value="<?= $member['user_id']; ?>">
        <?php endforeach; ?>
        <button type="submit" class="btn btn-success w-100">Assign Task</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<!-- Member Profile Panel (optional) -->
<div id="member-panel" class="position-fixed bg-white border p-3 shadow" style="top: 20px; right: -350px; width: 300px; transition: right 0.3s;">
  <button id="close-member-panel" class="btn-close float-end"></button>
  <img id="panel-profile" src="" alt="Profile Picture" class="rounded-circle mb-3" style="width:80px;height:80px;">
  <h5 id="panel-username"></h5>
  <p><strong>Email:</strong> <span id="panel-email"></span></p>
  <p><strong>About Me:</strong> <span id="panel-desc"></span></p>
</div>

<script>
  let lastMessageId = <?php echo $messages[count($messages)-1]->message_id ?? 0; ?>;
    let groupId = <?php echo $selectedGroupId; ?>;
    const chatContainer = document.querySelector('.chat-messages');
    const messageForm = document.getElementById('group-message-form');
    const messageInput = messageForm.querySelector('input[name="message_text"]');

    // Polling messages
    setInterval(() => {
        fetch(`./Controllers/MessageCheck.php?groupId=${groupId}&lastMessageId=${lastMessageId}`)
            .then(res => res.text())
            .then(html => {
                if (html.trim() !== '') {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = html;
                    const newMsg = tempDiv.firstElementChild;
                    if (newMsg) {
                      const msgId = parseInt(newMsg.dataset.messageId);
                      const alreadyExists = chatContainer.querySelector(`[data-message-id="${msgId}"]`);

                      if (msgId > lastMessageId && !alreadyExists) {
                        // Check if the message already has a bubble
                        const hasBubble = newMsg.querySelector('.rounded.shadow-sm');

                        if (!hasBubble) {
                          const bubble = document.createElement('div');
                          bubble.className = 'p-2 rounded shadow-sm bg-light text-dark';
                          bubble.style.maxWidth = '75%';
                          bubble.style.wordWrap = 'break-word';
                          bubble.innerHTML = newMsg.innerHTML;
                          newMsg.innerHTML = '';
                          newMsg.appendChild(bubble);
                        }

                        newMsg.classList.add('d-flex', 'justify-content-start', 'mb-2');
                        chatContainer.appendChild(newMsg);
                        lastMessageId = msgId;
                        chatContainer.scrollTop = chatContainer.scrollHeight;
                      }
                    }
                }
            });
    }, 1000);

    // Send message
    messageForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        await fetch(this.action, { method: 'POST', body: formData });

        messageInput.value = '';
        location.reload();
    });

  // Member panel logic
  const memberBtns = document.querySelectorAll('.member-btn');
  const memberPanel = document.getElementById('member-panel');
  const panelUsername = document.getElementById('panel-username');
  const panelEmail = document.getElementById('panel-email');
  const panelDesc = document.getElementById('panel-desc');
  const panelProfile = document.getElementById('panel-profile');
  const closePanelBtn = document.getElementById('close-member-panel');

  memberBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      panelUsername.textContent = btn.dataset.username;
      panelEmail.textContent = btn.dataset.email;
      panelDesc.textContent = btn.dataset.desc;
      panelProfile.src = btn.dataset.profile;
      memberPanel.style.right = '20px';
    });
  });

  closePanelBtn.addEventListener('click', () => {
    memberPanel.style.right = '-350px';
  });

  const jumpButton = document.getElementById('jump-to-present');
  function isNearBottom() {
    return chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight < 100;
  }
  chatContainer.addEventListener('scroll', () => {
    jumpButton.classList.toggle('d-none', isNearBottom());
  });

  jumpButton.addEventListener('click', () => {
    chatContainer.scrollTop = chatContainer.scrollHeight;
    jumpButton.classList.add('d-none');
  });

  window.addEventListener('load', () => {
    chatContainer.scrollTop = chatContainer.scrollHeight;
  });
</script>

<?php include 'Scripts.php'; ?>
</body>
</html>