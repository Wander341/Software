<?php
include_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Profile</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="./Styles/profile.css">
<?php include './Styles/Stylesheet.php'; ?>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

<?php include 'Navbar.php'; ?>

<div class="container">
<div class="row justify-content-center">

<!-- LEFT SIDEBAR -->
<div class="col-lg-3 col-md-4 pt-4">
<div class="p-4 border rounded shadow-sm">

<!-- PROFILE PICTURE -->
<form action="start.php?action=ProfileView" method="POST" enctype="multipart/form-data" id="profilePicForm" class="mb-3 text-center">
<div class="position-relative d-inline-block">
<img src="<?= htmlspecialchars($data['user']->getProfilePic()); ?>"
class="img-fluid rounded-circle mb-2"
style="width:150px; height:150px; object-fit:cover;">

<label for="profilepicInput"
class="position-absolute bottom-0 end-0 bg-white rounded-circle p-1 shadow"
style="cursor:pointer;">
<i class="fas fa-pencil-alt"></i>
</label>

<input type="file" name="profilepic" id="profilepicInput"
style="display:none;"
onchange="document.getElementById('profilePicForm').submit();">
</div>
</form>

<!-- USERNAME -->
<h4 class="text-center mb-3 pb-3">
<?= htmlspecialchars($data['user']->getUsername()) ?>#<?= htmlspecialchars($data['user']->getUserID()) ?>
</h4>

<!-- NAVIGATION BUTTONS -->
<div class="d-grid gap-2 pt-3">
<form action="start.php?action=ProfileView" method="POST"><button class="btn btn-primary w-100">Profile</button></form>
<form action="start.php?action=TaskView" method="POST"><button class="btn btn-primary w-100">Tasks</button></form>
<form action="start.php?action=CalendarView" method="POST"><button class="btn btn-primary w-100">Calendar</button></form>
<form action="start.php?action=FriendRequest" method="POST"><button class="btn btn-primary w-100">Add Friends</button></form>
</div>

<!-- FRIENDS DROPDOWN -->
<div class="mt-3">
<button type="button" class="btn btn-secondary w-100" onclick="toggleFriends()">Friends</button>

<div id="friendsDropdown" class="mt-2" style="display:none;">
<?php
$currentUser = $_SESSION['user']['user_ID'];
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

$stmt = $conn->prepare("
SELECT u.username
FROM Friendships f
JOIN USER u ON u.user_ID = f.friend_id
WHERE f.user_id = ? AND f.status = 'active'
");
$stmt->bind_param("i", $currentUser);
$stmt->execute();
$result = $stmt->get_result();

echo "<ul class='list-unstyled ps-3'>";
while ($row = $result->fetch_assoc()) {
  echo "<li>" . htmlspecialchars($row['username']) . "</li>";
}
echo "</ul>";

$stmt->close();
$conn->close();
?>
</div>
</div>

<!-- ⭐ MODERATOR BUTTON (only if user is a moderator) -->
<?php if (isset($_SESSION['user']['accessLvl']) && strtolower($_SESSION['user']['accessLvl']) === 'moderator'): ?>
<div class="mt-3">
<form action="start.php?action=ModeratorView" method="POST">
<button type="submit" class="btn btn-warning w-100">Moderator Page</button>
</form>
</div>
<?php endif; ?>

</div>
</div>

<!-- MAIN PROFILE CONTENT -->
<div class="col-lg-6 col-md-8">
<div class="profile-container p-4 border rounded shadow-sm">

<h2 class="mb-3">User Profile</h2>

<!-- ALERTS -->
<?php if (!empty($data['error'])): ?>
<div class="alert alert-danger"><?= htmlspecialchars($data['error']); ?></div>
<?php endif; ?>

<?php if (!empty($data['success'])): ?>
<div class="alert alert-success"><?= htmlspecialchars($data['success']); ?></div>
<?php endif; ?>

<!-- USER DETAILS -->
<?php if (!empty($data['user'])): ?>

<div class="mb-3">

<div class="row mb-2">
<div class="col-4 text-secondary">Username:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getUsername()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary">Email:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getEmail()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary">Access Level:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getAccessLevel()); ?></div>
</div>

<div class="row mb-2">
<div class="col-4 text-secondary">UAFS ID:</div>
<div class="col-8"><?= htmlspecialchars($data['user']->getUafsID()); ?></div>
</div>

<!-- BIRTHDAY (Private unless friends) -->
<?php if ($data['birthdayVisible']): ?>
<div class="row mb-2">
<div class="col-4 text-secondary">Birthday:</div>
<div class="col-8"><?= htmlspecialchars($data['birthdayFormatted']); ?></div>
</div>
<?php else: ?>
<div class="row mb-2">
<div class="col-4 text-secondary">Birthday:</div>
<div class="col-8 text-muted fst-italic">Visible to friends only</div>
</div>
<?php endif; ?>

<!-- Birthday Update -->
<form action="start.php?action=ProfileView" method="POST" class="mb-3">
<label class="form-label fw-bold">Update Birthday</label>
<input type="date" name="birthday" class="form-control mb-2"
value="<?= htmlspecialchars($data['user']->getBirthday()) ?>">
<input type="hidden" name="updateBirthday" value="1">
<button class="btn btn-primary btn-sm">Save Birthday</button>
</form>

</div>

<!-- ABOUT ME -->
<div class="mt-4">
<h5 class="fw-bold mb-2">About Me</h5>

<div class="p-3 mb-3 border rounded bg-light">
<?php if (trim($data['user']->getDescription()) !== ""): ?>
<p class="mb-0"><?= nl2br(htmlspecialchars($data['user']->getDescription())); ?></p>
<?php else: ?>
<p class="text-muted fst-italic mb-0">No bio written yet.</p>
<?php endif; ?>
</div>

<form action="start.php?action=ProfileView" method="POST">
<label for="userDesc" class="form-label">Edit Bio</label>
<textarea name="userDesc" id="userDesc" rows="5" class="form-control mb-2">
<?= htmlspecialchars($data['user']->getDescription()); ?>
</textarea>
<input type="hidden" name="updateDesc" value="1">
<button type="submit" class="btn btn-primary">Save Changes</button>
</form>
</div>

<?php endif; ?>

<!-- LOGOUT BUTTON -->
<form action="start.php?action=Logout" method="POST" class="mt-4">
<button class="btn btn-outline-danger">Logout</button>
</form>

</div>
</div>

</div>
</div>

<script>
function toggleFriends() {
  const dropdown = document.getElementById('friendsDropdown');
  dropdown.style.display = (dropdown.style.display === 'none') ? 'block' : 'none';
}
</script>

<?php include 'Scripts.php'; ?>
</body>
</html>
