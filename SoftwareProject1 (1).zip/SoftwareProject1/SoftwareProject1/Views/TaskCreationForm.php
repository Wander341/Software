<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create Task</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include './Styles/Stylesheet.php'; ?>

    <style>
        body {
            background-color: #f4f6fb;
            font-family: 'Segoe UI', sans-serif;
        }

        .task-container {
            max-width: 800px;
            margin: 40px auto;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h1 {
            text-align: center;
            color: #1e90ff;
            margin-bottom: 25px;
        }

        .form-label {
            font-weight: 600;
        }

        .member-list {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            max-height: 250px;
            overflow-y: auto;
        }

        .member-item {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
        }

        .member-item img {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .btn-submit {
            display: block;
            margin: 25px auto 0;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 25px;
            font-size: 1.1rem;
            transition: 0.2s;
        }

        .btn-submit:hover {
            background-color: #218838;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <?php include 'Navbar.php' ?>

    <div class="task-container">
        <h1>Create a Task for <?= htmlspecialchars($data['groupName']) ?></h1>

        <?php if (!empty($data['error'])): ?>
            <div class="error-message"><?= htmlspecialchars($data['error']) ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="group_name" value="<?= htmlspecialchars($data['groupName']) ?>">

            <div class="mb-3">
                <label class="form-label">Task Name</label>
                <input type="text" name="task_name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Task Description</label>
                <textarea name="task_desc" class="form-control" rows="3"></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Due Date</label>
                <input type="datetime-local" name="due_date" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Assign to Members</label>
                <div class="member-list">
                    <?php foreach ($data['members'] as $member): ?>
                        <div class="member-item">
                            <input type="checkbox" name="assigned_members[]"
                                value="<?= htmlspecialchars($member->getUserID()) ?>">
                            <img src="<?= htmlspecialchars($member->getProfilePic()) ?>" alt="Profile">
                            <span><?= htmlspecialchars($member->getUsername()) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <button type="submit" name="create_task" class="btn-submit">Create Task</button>
        </form>
    </div>
    <?php include 'Scripts.php'; ?>
</body>

</html>