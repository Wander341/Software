<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Event Form</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<?php include './Styles/Stylesheet.php'; ?>

<style>
.form-label {
    font-size: 1.3rem;
    font-weight: 500;
    color: #1e90ff;
    text-shadow: 0 0 2px rgba(0,0,0,0.1);
}
.form-control, .form-select {
    background-color: #eae6ee;
    border: none;
    box-shadow: inset 0 0 2px rgba(0,0,0,0.1);
}
.btn-create {
    background-color: #36a3ff;
    color: white;
    font-size: 1.2rem;
    padding: 10px 25px;
    border-radius: 50px;
    transition: 0.2s;
}
.btn-create:hover {
    background-color: #1e8be6;
}
.btn-cancel {
    background-color: #ff3c3c;
    color: white;
    font-size: 1.2rem;
    padding: 10px 25px;
    border-radius: 50px;
    transition: 0.2s;
}
.btn-cancel:hover {
    background-color: #e02c2c;
}
.form-section {
    max-width: 900px;
    margin: 0 auto;
    background-color: white;
    border-radius: 20px;
    padding: 30px 50px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
.error-box {
    background-color: #ffe6e6;
    color: #b30000;
    padding: 10px 15px;
    border-radius: 10px;
    margin-top: 15px;
    text-align: center;
}
</style>
</head>

<body>

<?php include 'Navbar.php'; ?>

<div class="form-section">
<form method="POST" action="start.php?action=EventCreationForm">

<!-- FIXED: Safe node_id handling (NULL = no node) -->
<input type="hidden"
name="node_id"
value="<?php echo (isset($data['node_id']) && is_numeric($data['node_id'])) ? intval($data['node_id']) : ''; ?>">

<div class="row mb-4 align-items-center">
<div class="col-md-4 text-end">
<label class="form-label" for="event_name">Event Name:</label>
</div>
<div class="col-md-8">
<input type="text" name="event_name" id="event_name" class="form-control" placeholder="Type Here..." required>
</div>
</div>

<div class="row mb-4 align-items-start">
<div class="col-md-4 text-end">
<label class="form-label" for="event_desc">Event Description:</label>
</div>
<div class="col-md-8">
<textarea name="event_desc" id="event_desc" class="form-control" rows="4" placeholder="Type Here..."></textarea>
</div>
</div>

<div class="row mb-4 align-items-center">
<div class="col-md-4 text-end">
<label class="form-label" for="event_date">Event Date:</label>
</div>
<div class="col-md-8">
<input type="date" name="event_date" id="event_date" class="form-control" required>
</div>
</div>

<div class="row mb-4 align-items-center">
<div class="col-md-4 text-end">
<label class="form-label" for="start_time">Start Time:</label>
</div>
<div class="col-md-4">
<input type="time" name="start_time" id="start_time" class="form-control" step="60" required>
</div>
</div>

<div class="row mb-4 align-items-center">
<div class="col-md-4 text-end">
<label class="form-label" for="end_time">End Time:</label>
</div>
<div class="col-md-4">
<input type="time" name="end_time" id="end_time" class="form-control" step="60" required>
</div>
</div>

<div class="row mb-4 align-items-center">
<div class="col-md-4 text-end">
<label class="form-label" for="location">Event Location:</label>
</div>
<div class="col-md-8">
<select name="location" id="location" class="form-select" required>
<?php foreach ($data['location'] as $loc): ?>
<option value="<?php echo htmlspecialchars($loc); ?>">
<?php echo htmlspecialchars($loc); ?>
</option>
<?php endforeach; ?>
</select>
</div>
</div>

<?php if (!empty($data['error'])): ?>
<div class="error-box">
<?php echo htmlspecialchars($data['error']); ?>
</div>
<?php endif; ?>

<div class="d-flex justify-content-center mt-4 gap-3">
<button type="submit" class="btn btn-create">Create Event</button>
<a href="start.php?action=MapView" class="btn btn-cancel">Cancel</a>
</div>

</form>
</div>

<?php include 'Scripts.php'; ?>

<script>
document.querySelector('form').addEventListener('submit', function (e) {

    const date = document.getElementById('event_date').value;
    const start = new Date(`${date}T${document.getElementById('start_time').value}`);
    const end = new Date(`${date}T${document.getElementById('end_time').value}`);

    if (end <= start) {
        e.preventDefault();
        alert('End time must be after start time.');
    }

    // Prevent invalid node_id from being submitted
    const nodeIdInput = document.querySelector('input[name="node_id"]');
    if (!nodeIdInput.value || isNaN(nodeIdInput.value)) {
        nodeIdInput.value = ""; // send blank = no node assignment
    }

});
</script>

</body>
</html>
