<?php
$active = $_GET['action'] ?? 'Home'; // Default to 'Home' if not set
?>

<div id="header">
  <a href="start.php?action=Home">
    <img src="./Images/LockedIn_logo.png" alt="Logo" id="site-logo"/>
  </a>

  <?php if ($active !== 'ProfileView'): ?>
    <?php include 'ProfileIcon.php'; ?>
    
  <?php endif; ?>
</div>



<div id="navbar">
  <div class="nav-item <?= $active === 'Home' ? 'active' : '' ?>" onclick="window.location.href='start.php?action=Home'">
    <i class="fa-solid fa-house"></i>
    <span>Home</span>
  </div>
  <div class="nav-item <?= $active === 'MapView' ? 'active' : '' ?>" onclick="window.location.href='start.php?action=MapView'">
    <i class="fa-solid fa-map-location-dot"></i>
    <span>Map</span>
  </div>
  <div class="nav-item <?= $active === 'ThreadView' ? 'active' : '' ?>" onclick="window.location.href='start.php?action=ThreadView'">
    <i class="fa-solid fa-list-ul"></i>
    <span>Threads</span>
  </div>
  <div class="nav-item <?= $active === 'GroupView' ? 'active' : '' ?>" onclick="window.location.href='start.php?action=GroupView'">
    <i class="fa-solid fa-users"></i>
    <span>Groups</span>
  </div>
</div>