<?php
include_once "./Models/UserDAO.php";

$user = null;
if (isset($_SESSION['user']['user_ID'])) {
    $dao = new UserDAO();
    $user = $dao->getUser($_SESSION['user']['user_ID']);
}
?>

<div id="profile-icon-container">
    <?php if ($user): ?>
        <img src="<?= htmlspecialchars($user->getProfilePic()) ?>" alt="Profile Picture" id="profile-pic" onclick="toggleDropdown()" />
        <div id="profile-username"><?= htmlspecialchars($user->getUsername()) ?></div>
        <div id="profile-icon-dropdown">
            <span class="tag">
                <?= htmlspecialchars($user->getUsername()) ?>#<?= htmlspecialchars($user->getUserID()) ?>
            </span>
            <a href="start.php?action=ProfileView">View Profile</a>
            <form action="start.php?action=Logout" method="POST" style="margin: 0;">
                <input type="submit" value="Log Out" class="dropdown-link-button" />
            </form>
        </div>

    <?php else: ?>
        <a href="start.php?action=Login" class="login-button">Log In</a>
    <?php endif; ?>
</div>