<?php
include_once './Models/UserDAO.php';
$userDAO = new UserDAO();
$users = $userDAO->getAllUsers();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Moderator View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./Styles/navbar.css">
    <script src="https://kit.fontawesome.com/a2e0f1f6d8.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .table-container {
            background-color: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        h3 {
            font-weight: 600;
            color: #007bff;
        }

        .btn {
            border-radius: 10px;
            padding: 10px 20px;
            margin: 5px;
            font-weight: 500;
            transition: 0.2s ease-in-out;
        }

        .btn-ban {
            background-color: #dc3545;
            color: white;
        }

        .btn-ban:hover {
            background-color: #b02a37;
        }

        .btn-unban {
            background-color: #007bff
        }

        .btn-unban:hover {
            background-color: #3e8fe7ff
        }

        .btn-access {
            background-color: #ffc107;
            color: black;
        }

        .btn-access:hover {
            background-color: #e0a800;
        }

        .table thead th {
            background-color: #007bff;
            color: white;
            text-align: center;
        }

        .task-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .table {
            table-layout: fixed;
            width: 100%;
        }

        .table {
            table-layout: fixed;
            width: 100%;
        }

        .task-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .task-buttons form {
            margin: 0;
            padding: 0;
        }
    </style>
</head>

<body>

    <?php include 'Navbar.php'; ?>

    <div class="container table-container">
        <h3>User Management</h3>
        <table class="table table-striped table-hover mt-3">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Access Level</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user->getUsername()); ?></td>
                        <td><?= htmlspecialchars($user->getEmail()); ?></td>
                        <td><?= htmlspecialchars($user->getAccessLevel()); ?></td>
                        <td>
                            <div class="task-buttons">
                                <!-- Ban button -->
                                <form method="POST" action="start.php?action=ModeratorView">
                                    <input type="hidden" name="user_ID" value="<?= $user->getUserID(); ?>">
                                    <input type="hidden" name="user_action" value="ban">
                                    <button type="submit" class="btn btn-ban" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Ban user">
                                        <i class="fas fa-ban"></i>
                                    </button>
                                </form>

                                <!-- Unban button -->
                                <form method="POST" action="start.php?action=ModeratorView">
                                    <input type="hidden" name="user_ID" value="<?= $user->getUserID(); ?>">
                                    <input type="hidden" name="user_action" value="unban">
                                    <button type="submit" class="btn btn-unban" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Unban user">
                                        <i class="fas fa-user-check"></i>
                                    </button>
                                </form>

                                <!-- Change Access Level button -->
                                <form method="POST" action="start.php?action=ModeratorView">
                                    <input type="hidden" name="user_ID" value="<?= $user->getUserID(); ?>">
                                    <input type="hidden" name="user_action" value="change_access">
                                    <button type="submit" class="btn btn-access" data-bs-toggle="tooltip"
                                        data-bs-placement="top" title="Change user's access level">
                                        <i class="fas fa-user-cog"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php include 'Scripts.php'; ?>
</body>

</html>