<?php
include_once "./Models/NotificationDAO.php";

$active = $_GET['action'] ?? 'Home'; // Default to 'Home' if not set

$notifications = [];
$notifCount = 0;

// Only load notifications if user is logged in
$userId = $_SESSION['user']['user_ID'] ?? null;

if ($userId) {
   $notifDAO = new NotificationDAO();
   $notifications = $notifDAO->getNotifications($_SESSION['user']['user_ID']);
   $notifCount = count($notifications);
}
?>
<nav class="navbar navbar-expand-lg bg-light border-bottom">
  <div class="container-fluid">
    <!-- Left: Brand / Logo -->
    <a class="navbar-brand" href="start.php?action=Home">
      <img src="./Images/LockedIn_favicon2.png" alt="Logo" width="50" height="50" class="d-inline-block align-text-center">
    </a>

    <!-- Toggler button -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
      aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Collapsible links (LEFT SIDE) -->
    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?= $active === 'Home' ? 'active' : '' ?>" href="start.php?action=Home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active === 'MapView' ? 'active' : '' ?>" href="start.php?action=MapView">Map</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active === 'ExistingEvents' ? 'active' : '' ?>" href="start.php?action=ExistingEvents">Events</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active === 'ThreadView' ? 'active' : '' ?>" href="start.php?action=ThreadView">Threads</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $active === 'GroupView' ? 'active' : '' ?>" href="start.php?action=GroupView">Groups</a>
        </li>
      </ul>
    </div>

<div class="d-flex align-items-center ms-auto">
      <!-- Notifications -->
      <a href="start.php?action=CalendarView"
        class="nav-link <?= $active === 'CalendarView' ? 'active' : '' ?> text-dark me-3 px-2"
        title="Calendar">
          <i class="bi bi-calendar-event" style="font-size: 1.4rem;"></i>
      </a>

      <li class="nav-item dropdown list-unstyled me-3">
        <a class="nav-link dropdown-toggle p-2" href="#" role="button" data-bs-toggle="dropdown">

            <!-- Wrap bell icon in a relative container -->
            <span class="position-relative">
                <i class="fa-solid fa-bell fs-4" ></i>

                <!-- Notification badge positioned INSIDE padding -->
                <?php if ($notifCount > 0): ?>
                    <span class="badge bg-danger rounded-pill position-absolute"
                          style="top: -6px; right: -6px; font-size: 0.65rem;">
                        <?= $notifCount ?>
                    </span>
                <?php endif; ?>
            </span>

        </a>

        <!-- Dropdown content -->
        <ul class="dropdown-menu dropdown-menu-end" style="max-height: 300px; overflow-y: auto;">
            <?php if ($notifCount === 0): ?>
                <li><span class="dropdown-item-text text-muted">No notifications</span></li>
            <?php else: ?>
                <?php foreach ($notifications as $notif): ?>
                    <li>
                        <span class="dropdown-item">
                            <strong><?= htmlspecialchars($notif['notif_type']); ?>: <?= htmlspecialchars($notif['notif_name']); ?></strong><br>
                            <small class="text-muted"><?= $notif['time_sent']; ?></small>
                        </span>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                <?php endforeach; ?>

                <!-- CLEAR BUTTON -->
                <li>
                  <div class="text-center">
                    <button type="button" class="btn btn-danger btn-sm fw-bold"
                            onclick="clearNotifications()">
                        Clear Notifications
                    </button>
                  </div>
                </li>
            <?php endif; ?>
        </ul>
    </li>


      <!-- Profile icon -->
      <div class="d-lg-flex">
        <?php include 'ProfileIcon.php'; ?>
      </div>
  </div>
  </div>
</nav>
<script>
function clearNotifications() {
    fetch('./Views/ClearNotifs.php', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Reload the page to update the notifications
                location.reload();
            } else {
                alert("Failed to clear notifications");
            }
        })
        .catch(err => {
            console.error(err);
            Console.log(err);
            alert("Error clearing notifications");
        });
}
</script>