<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Group</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include './Styles/Stylesheet.php'; ?>

    <style>
        body {
            background-color: #f4f4f9;
        }
        .form-section {
            max-width: 800px;
            margin: 50px auto;
            background-color: white;
            border-radius: 20px;
            padding: 30px 50px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #1e90ff;
            text-shadow: 0 0 2px rgba(0,0,0,0.1);
        }
        .form-label {
            font-size: 1.2rem;
            font-weight: 500;
            color: #1e90ff;
        }
        .form-control {
            background-color: #eae6ee;
            border: none;
            box-shadow: inset 0 0 2px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .checkbox-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .checkbox-item {
            background-color: #f0f0f5;
            padding: 10px 15px;
            border-radius: 10px;
            box-shadow: inset 0 0 2px rgba(0,0,0,0.05);
        }
        .checkbox-item input {
            margin-right: 8px;
            transform: scale(1.2);
        }
        .btn-create {
            background-color: #36a3ff;
            color: white;
            font-size: 1.2rem;
            padding: 10px 25px;
            border-radius: 50px;
            transition: 0.2s;
        }
        .btn-create:hover {
            background-color: #1e8be6;
        }
        .btn-cancel {
            background-color: #ff3c3c;
            color: white;
            font-size: 1.2rem;
            padding: 10px 25px;
            border-radius: 50px;
            transition: 0.2s;
        }
        .btn-cancel:hover {
            background-color: #e02c2c;
        }
        .error-box {
            background-color: #ffe6e6;
            color: #b30000;
            padding: 10px 15px;
            border-radius: 10px;
            margin-top: 15px;
            text-align: center;
        }
    </style>
</head>
<body>


<?php include 'Navbar.php'?>

<div class="form-section">
    <form method="POST" action="start.php?action=GroupCreationForm">
        <div class="row mb-4 align-items-center">
            <div class="col-md-4 text-end">
                <label class="form-label" for="group_name">Group Name:</label>
            </div>
            <div class="col-md-8">
                <input type="text" name="group_name" id="group_name" class="form-control" placeholder="Enter group name..." required>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-4 text-end">
                <label class="form-label">Select Friends:</label>
            </div>
            <div class="col-md-8">
                <div class="checkbox-container">
                    <?php if (!empty($data['friends'])): ?>
                        <?php foreach ($data['friends'] as $friend): ?>
                            <div class="checkbox-item">
                                <input type="checkbox" name="friends[]" value="<?php echo $friend->getUserID(); ?>" id="friend_<?php echo $friend->getUserID(); ?>">
                                <label for="friend_<?php echo $friend->getUserID(); ?>"><?php echo htmlspecialchars($friend->getUsername()); ?></label>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>You have no friends to add.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (!empty($data['error'])): ?>
            <div class="error-box">
                <?php echo htmlspecialchars($data['error']); ?>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-center mt-4 gap-3">
            <button type="submit" class="btn btn-create">Create Group</button>
            <a href="start.php?action=GroupView" class="btn btn-cancel">Cancel</a>
        </div>
    </form>
</div>
<?php include 'Scripts.php'; ?>
</body>
</html>