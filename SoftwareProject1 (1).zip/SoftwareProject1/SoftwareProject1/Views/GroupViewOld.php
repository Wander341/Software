<?php
require_once 'Models/Group.php';
require_once 'Controllers/MessageLoad.php';
require_once 'Models/UserDAO.php';
require_once 'Models/User.php';

$groupModel = new Group();
$userID = $_SESSION['user']['user_ID'];
$groups = $groupModel->getAllGroupsByUser($userID);

// Determine selected group
$selectedGroupId = $_GET['group_id'] ?? (!empty($groups) ? ($groups[0]->getGroupID() ?? 0) : 0);

$selectedGroup = $selectedGroupId ? $groupModel->getGroup($selectedGroupId) : null;
$groupMembers = $selectedGroup ? $selectedGroup->getStudents() : [];
$selectedGroupName = $selectedGroup ? $selectedGroup->getGroupName() : "No groups yet";

// Load messages
$loader = new MessageLoad();
$messages = $selectedGroupId ? $loader->loadMessagesByGroupId($selectedGroupId) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Group View</title>
    <?php include './Styles/Stylesheet.php'; ?>
    
    <link rel="stylesheet" href="./Styles/group.css">
</head>
<body>
    

    <?php include 'Navbar.php'?>

    <div class="content">
<button class="btn btn-primary m-2 d-flex align-items-center gap-2" type="button"
        data-bs-toggle="offcanvas" data-bs-target="#groupSidebarOffcanvas" aria-controls="groupSidebarOffcanvas">
  <i class="fa-solid fa-arrow-right"></i>
</button>

<div class="offcanvas offcanvas-start" tabindex="-1" id="groupSidebarOffcanvas" aria-labelledby="groupSidebarLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="groupSidebarLabel">Your Groups</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="group-list">
      <?php if (!empty($groups)): ?>
        <?php foreach ($groups as $group): ?>
          <?php $isActive = ($group->getGroupID() == $selectedGroupId) ? 'active-group' : ''; ?>
          <a href="start.php?action=GroupView&group_id=<?= $group->getGroupID(); ?>"
             class="group-item <?= $isActive ?> d-block mb-2 text-decoration-none text-white p-2 rounded"
             style="background-color: #007BFF;">
            <?= htmlspecialchars($group->getGroupName()); ?>
          </a>
        <?php endforeach; ?>

        <div class="create-group mt-3">
          <form method="GET" action="start.php">
            <input type="hidden" name="action" value="GroupCreationForm">
            <button type="submit" class="btn btn-success w-100">+ Create Group</button>
          </form>
        </div>
      <?php else: ?>
        <div class="no-groups">
          <p>You’re not part of any groups yet.</p>
          <form method="GET" action="start.php">
            <input type="hidden" name="action" value="GroupCreationForm">
            <button type="submit" class="btn btn-success">Create Your First Group</button>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

        <div class="main-panel">
            <div class="group-members">
            <strong>Members of <?php echo htmlspecialchars($selectedGroupName); ?>:</strong>
            <div class="member-buttons">
                <?php 
                $userDAO = new UserDAO();
                $memberIDs = [];
                foreach ($groupMembers as $member):
                    $fullUser = $userDAO->getUser($member['user_id']);
                    $memberIDs[] = $fullUser->getUserID();
                ?>
                    <button class="member-btn"
                        data-username="<?php echo htmlspecialchars($fullUser->getUsername()); ?>"
                        data-email="<?php echo htmlspecialchars($fullUser->getEmail()); ?>"
                        data-desc="<?php echo htmlspecialchars($fullUser->getDescription()); ?>"
                        data-profile="<?php echo htmlspecialchars($fullUser->getProfilePic()); ?>">
                        <img src="<?php echo htmlspecialchars($fullUser->getProfilePic()); ?>" 
                            alt="Profile Pic" style="width:24px;height:24px;border-radius:50%;margin-right:5px;">
                        <?php echo htmlspecialchars($fullUser->getUsername()); ?>
                    </button>
                <?php endforeach; ?>

                <?php if (!empty($memberIDs)): ?>
                    <form action="start.php?action=TaskCreationForm" method="POST" style="margin-top: 10px; width: 100%;">

                        <input type="hidden" name="group_name" value="<?php echo htmlspecialchars($selectedGroupName); ?>">

                        <?php foreach ($memberIDs as $id): ?>
                            <input type="hidden" name="group_members[]" value="<?php echo $id; ?>">
                        <?php endforeach; ?>

                        <button type="submit" style="
                            background: #4CAF50;
                            color: white;
                            border: none;
                            border-radius: 4px;
                            padding: 8px 12px;
                            cursor: pointer;
                            width: 100%;
                        ">
                            Assign Task
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

            <?php if ($selectedGroupId): ?>
                <div class="chat-panel">
                    <div class="chat-header">Messages</div>
                    <div class="chat-messages">
                        <?php foreach ($messages as $msg): ?>
                            <div class="message" data-message-id="<?php echo $msg->message_id; ?>">
                                <?php
                                $userDAO = new UserDAO();
                                $user = $userDAO->getUser($msg->user_id);

                                $dt = new DateTime($msg->time_sent, new DateTimeZone('UTC'));
                                $dt->setTimezone(new DateTimeZone('America/Chicago'));
                                $formattedTime = $dt->format('M j, Y g:i A');

                                echo '<span class="sender">' . htmlspecialchars($user->getUsername()) . ':</span> ';
                                echo '<span class="timestamp" style="color: #888; font-size: 0.9em; margin-left: 8px;">' . htmlspecialchars($formattedTime) . '</span><br>';
                                echo htmlspecialchars($msg->message_text);
                                ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="chat-input">
                    <form id="group-message-form" method="POST" action="start.php?action=SendMessage">
                        <input type="hidden" name="group_id" value="<?php echo $selectedGroupId; ?>">
                        <input type="text" name="message_text" placeholder="Type a message..." required>
                        <button type="submit">Send</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div id="member-panel" class="member-panel">
        <button id="close-member-panel">×</button>
        <img id="panel-profile" src="" alt="Profile Picture" style="width:80px;height:80px;border-radius:50%;margin-bottom:10px;">
        <h3 id="panel-username"></h3>
        <p><strong>Email:</strong> <span id="panel-email"></span></p>
        <p><strong>About Me:</strong> <span id="panel-desc"></span></p>
    </div>

<script>
    let lastMessageId = <?php echo $messages[count($messages)-1]->message_id ?? 0; ?>;
    let groupId = <?php echo $selectedGroupId; ?>;
    const chatContainer = document.querySelector('.chat-messages');
    const messageForm = document.getElementById('group-message-form');
    const messageInput = messageForm.querySelector('input[name="message_text"]');

    // Polling messages
    setInterval(() => {
        fetch(`./Controllers/MessageCheck.php?groupId=${groupId}&lastMessageId=${lastMessageId}`)
            .then(res => res.text())
            .then(html => {
                if (html.trim() !== '') {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = html;
                    const newMsg = tempDiv.firstElementChild;
                    if (newMsg) {
                        const msgId = parseInt(newMsg.dataset.messageId);
                        if (msgId > lastMessageId) {
                            chatContainer.appendChild(newMsg);
                            lastMessageId = msgId;
                            chatContainer.scrollTop = chatContainer.scrollHeight;
                        }
                    }
                }
            });
    }, 1000);

    // Send message
    messageForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        await fetch(this.action, { method: 'POST', body: formData });

        messageInput.value = '';
        location.reload();
    });

    // Member panel
    const memberBtns = document.querySelectorAll('.member-btn');
    const memberPanel = document.getElementById('member-panel');
    const panelUsername = document.getElementById('panel-username');
    const panelEmail = document.getElementById('panel-email');
    const panelDesc = document.getElementById('panel-desc');
    const closePanelBtn = document.getElementById('close-member-panel');

    memberBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('panel-profile').src = btn.dataset.profile;
            panelUsername.textContent = btn.dataset.username;
            panelEmail.textContent = btn.dataset.email;
            panelDesc.textContent = btn.dataset.desc;
            memberPanel.style.right = '0';
        });
    });

    closePanelBtn.addEventListener('click', () => {
        memberPanel.style.right = '-350px';
    });
</script>
<?php include 'Scripts.php'; ?>
</body>
</html>