<?php
$nodes = $data['nodes']; 
?>
<!DOCTYPE html>
<html>
<head>
  <title>UAFS Event Map</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=1.0">

  <?php include './Styles/Stylesheet.php'; ?>
  
  <style>
    #content {
      display: flex;
      padding: 20px;
    }
    #event-directions {
      width: 300px;
      height: 450px;
      background-color: #007BFF;
      color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
      margin-right: 20px;
      margin-top: 20px;
    }
    #event-directions h2 {
      text-align: center;
      margin-top: 0;
      margin-bottom: 20px;
    }
    #event-directions p {
      line-height: 1.5;
      text-align: center;
    }
    #event-directions a {
      color: white;
      font-weight: bold;
      text-decoration: underline;
    }
    #map-container {
      flex-grow: 1;
      min-height: 50vh;
      box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
      border-radius: 5px;
      overflow: hidden;
      margin-top: 20px;
    }
    #map {
      height: 100%;
      width: 100%;
    }

    #map {
      cursor: default;
    }
    .leaflet-marker-icon {
      cursor: pointer;
    }
    #map:hover {
      cursor: crosshair;
    }
  </style>
</head>
<body>

  

  <?php include 'Navbar.php'?>
  <div class="px-4 py-5 my-5 text-center rounded shadow bg-light">
    <h2 class="fw-bold">Event Directions</h2>

    <div class="col-md-8 mx-auto my-4">
      <p class="lead mb-0">
        Click on a node to see the building name. Double click on the node to create an event in that building.
        When you double click a node, you’ll need to fill out 
        the Event Creation Form, where you can enter event details and view available rooms for that building. 
        You’ll also be able to see the names of all users who have registered for a given event by viewing 
        the event’s RSVP List.
      </p>
    </div>
    <a href="start.php?action=ExistingEvents" class="btn btn-primary btn-lg">Upcoming Events</a>
  </div>
  <div id="content">
    


    <div id="map-container">
      <div id="map"></div>
    </div>
  </div>
  
  <?php include 'Scripts.php'; ?>
  <script>
    
    const imageWidth = 1388;
    const imageHeight = 938;
    const bounds = [[0, 0], [imageHeight, imageWidth]];

    const map = L.map('map', {
      crs: L.CRS.Simple,
      minZoom: -2,
      maxZoom: 2,
      zoom: 0,
      center: [imageHeight / 2, imageWidth / 2]
    });

    const imageUrl = './Images/uafsmap.png';
    L.imageOverlay(imageUrl, bounds).addTo(map);
    map.fitBounds(bounds);

    const nodes = <?php echo json_encode($nodes); ?>;

    nodes.forEach(node => {
      const x = node.x; 
      const y = node.y;
      const nodeID = node.node_id; 
      const nodeName = node.node_name;

      const latLng = L.latLng(y, x);
      const marker = L.marker(latLng).addTo(map);

      marker.bindPopup(`<strong>${nodeName}</strong>`);

      let lastClickTime = 0;

      marker.on('click', function() {
        const now = Date.now();

        // If clicked again within 1 second, redirect
        if (now - lastClickTime < 1000) {
          window.location.href = `start.php?action=EventCreationForm&node_id=${nodeID}`;
        } else {
          marker.openPopup();
        }

        lastClickTime = now;
      });
    });



</script>
</body>
</html>