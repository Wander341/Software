<?php
include_once 'config.php';
$currentUser = $_SESSION['user']['user_ID'];

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <?php include './Styles/Stylesheet.php'; ?>
  <link rel="stylesheet" href="./Styles/friendreq.css">
  <meta charset="UTF-8">
  <title>Friend Requests</title>
  
</head>


  <?php include 'Navbar.php'?>
<body>
<div class="friend-body">
  <h2>Send a Friend Request</h2>
  <form class="form-inline" action="start.php?action=FriendRequest&subaction=send" method="POST">
    <input type="hidden" name="subaction" value="send">
    <label for="friend_id">Friend's User ID:</label>
    <input type="number" name="friend_id" required>
    <input type="submit" value="Send Request" class="send-request-btn">
  </form>

  <h2>Pending Friend Requests</h2>
  <?php
  $pendingQuery = "
    SELECT u.user_ID, u.username 
    FROM Friendships f
    JOIN USER u ON u.user_ID = f.user_id
    WHERE f.friend_id = ? AND f.status = 'pending'
  ";
  $pendingStmt = $conn->prepare($pendingQuery);
  $pendingStmt->bind_param("i", $currentUser);
  $pendingStmt->execute();
  $pendingResult = $pendingStmt->get_result();

  if ($pendingResult->num_rows > 0): ?>
    <table>
      <tr><th>Username</th><th>Action</th></tr>
      <?php while ($row = $pendingResult->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['username']); ?></td>
          <td>
            <form action="start.php?action=FriendRequest&subaction=accept" method="POST">
              <input type="hidden" name="subaction" value="accept">
              <input type="hidden" name="friend_id" value="<?php echo $row['user_ID']; ?>">
              <input type="submit" value="Accept">
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php else: ?>
    <p>No pending requests.</p>
  <?php endif;
  $pendingStmt->close();
  ?>
</div>
<?php include 'Scripts.php'; ?>
</body>
</html>
