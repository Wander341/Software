<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Existing Events</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.event-row { cursor:pointer; transition:0.15s; }
.event-row:hover { background:#eef6ff; }
.register-btn.active { background:#28a745 !important; color:white; }
.unregister-btn.active { background:#dc3545 !important; color:white; }
</style>

<?php include './Styles/Stylesheet.php'; ?>
</head>

<body>
<?php include 'Navbar.php'; ?>

<div class="container my-4">

<div class="d-flex justify-content-end mb-3">
<a href="start.php?action=EventCreationForm&node_id=0" class="btn btn-primary rounded-pill px-4">
+ Add Event
</a>
</div>

<form method="POST">

<div class="table-responsive">
<table class="table table-sm table-bordered">
<thead class="table-primary">
<tr>
<th>Select</th>
<th>Event</th>
<th>Description</th>
<th>Location</th>
<th>Time</th>
<th>Creator</th>
<th>RSVP</th>
</tr>
</thead>

<tbody class="small">
<?php foreach ($data['events'] as $event): ?>
<?php
$rsvp = json_decode($event["rsvp"], true);
$isRegistered = in_array($data['userID'], $rsvp);
$isCreator = ($event["creator_ID"] == $data['userID']);
?>
<tr class="event-row"
onclick="window.location='start.php?action=ExistingEvents&event_id=<?= $event['event_id'] ?>'">

<td onclick="event.stopPropagation();">
<input type="checkbox" name="selected_events[]" value="<?= $event['event_id'] ?>">
</td>

<td><?= htmlspecialchars($event['event_name']) ?></td>
<td><?= htmlspecialchars($event['event_desc']) ?></td>
<td><?= htmlspecialchars($event['full_location']) ?></td>

<td>
<?= date("m/d/Y g:iA", strtotime($event['start_time'])) ?> -
<?= date("g:iA", strtotime($event['end_time'])) ?>
</td>

<td><?= htmlspecialchars($event['creator_ID']) ?></td>

<td onclick="event.stopPropagation();">
<form method="POST">
<input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">
<button
name="action_type"
value="toggle_rsvp"
class="btn <?= $isRegistered ? 'btn-danger unregister-btn active' : 'btn-success register-btn active' ?>">

<?= $isRegistered ? "Unregister" : "Register" ?>
</button>
</form>
</td>

</tr>
<?php endforeach; ?>
</tbody>

</table>
</div>

<div class="d-flex justify-content-center mt-3 gap-2">

<button type="submit" name="action_type" value="rsvp_selected"
class="btn btn-success rounded-pill px-4">
View RSVP
</button>

<button type="submit" name="action_type" value="delete_selected"
class="btn btn-danger rounded-pill px-4"
onclick="return confirm('Delete selected events?')">
Delete Selected
</button>

</div>

</form>

<?php include 'Scripts.php'; ?>
</body>
</html>
