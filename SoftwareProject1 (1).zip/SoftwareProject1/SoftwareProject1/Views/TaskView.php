<?php
// Ensure $data['task'] exists
if (!isset($data['task'])) {
    $data['task'] = [];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Tasks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./Styles/navbar.css">
    <script src="https://kit.fontawesome.com/a2e0f1f6d8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .table-container {
            background-color: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        .btn {
            border-radius: 10px;
            padding: 12px 20px;
            font-size: 20px;
            transition: 0.2s ease-in-out;
        }

        .btn-quit {
            background-color: #dc3545;
            color: white;
        }

        .btn-quit:hover {
            background-color: #b02a37;
        }

        .btn-complete {
            background-color: #007bff
        }

        .btn-complete:hover {
            background-color: #3e8fe7ff
        }

        .btn-update {
            background-color: #ffc107;
            color: black;
        }

        .btn-update:hover {
            background-color: #e0a800;
        }

        .task-button-row {
            margin-top: 25px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .table-header th {
            background-color: #007bff !important;
            color: white !important;
        }
    </style>
</head>

<body>

    <?php include 'Navbar.php' ?>

    <div class="container mt-5">
        <form method="POST" id="taskForm" action="start.php?action=TaskView">

            <div class="table-container">
                <h3 class="text-center mb-4 text-primary">Your Tasks</h3>

                <table class="table table-striped table-hover text-center align-middle">
                    <thead class="table-header">
                        <tr>
                            <th>Select</th>
                            <th>Task Name</th>
                            <th>Task Description</th>
                            <th>Due Date</th>
                            <th>Date Assigned</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (!empty($data['task'])): ?>
                            <?php foreach ($data['task'] as $task): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_tasks[]"
                                            value="<?= htmlspecialchars($task['task_id']) ?>"></td>
                                    <td><?= htmlspecialchars($task['task_name']) ?></td>
                                    <td><?= htmlspecialchars($task['task_desc']) ?></td>
                                    <td><?= htmlspecialchars(date('Y-m-d g:iA', strtotime($task['due_date']))) ?></td>
                                    <td><?= htmlspecialchars(date('Y-m-d g:iA', strtotime($task['date_assigned']))) ?></td>
                                    <td><?= htmlspecialchars($task['status']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-muted">No tasks found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="task-button-row">

                    <button type="submit" name="action_type" value="Quit Task" class="btn btn-quit"
                        data-bs-toggle="tooltip" title="Quit Task">
                        <i class="fa-solid fa-ban"></i>
                    </button>

                    <button type="submit" name="action_type" value="Complete Task" class="btn btn-complete"
                        data-bs-toggle="tooltip" title="Complete Task">
                        <i class="fa-solid fa-check"></i>
                    </button>

                    <button type="button" id="updateTaskBtn" class="btn btn-update" data-bs-toggle="tooltip"
                        title="Update Task">
                        <i class="fa-solid fa-pen"></i>
                    </button>

                </div>

            </div>
        </form>
    </div>

    <script>

        document.getElementById('updateTaskBtn').addEventListener('click', function () {
            const selected = document.querySelector('input[name="selected_tasks[]"]:checked');
            if (!selected) {
                alert('Please select a task to update.');
                return;
            }
            window.location.href = `start.php?action=TaskUpdateForm&task_id=${encodeURIComponent(selected.value)}`;
        });

        document.addEventListener("DOMContentLoaded", function () {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(t => new bootstrap.Tooltip(t));
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'Scripts.php'; ?>

</body>

</html>